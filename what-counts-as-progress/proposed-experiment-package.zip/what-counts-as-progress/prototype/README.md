# Interactive research demonstration

**What Counts as Progress? · Version 0.1 · 3 October 2026**

Open `index.html` in a browser. It is a self-contained local file with no installation, external assets, analytics, or persistent storage. JavaScript must be enabled for the interactions. Refreshing the page clears the practice history.

## What is included

- **A fictional dashboard comparison:** the same platform activity appears in an activity view and an activity-plus-assessment view. Three synthetic records illustrate why recorded interactions, prior assessment performance, and unknown assessment evidence should remain distinct. The prior-mark display is explicitly retrospective: the research dataset does not establish live grade availability. The unassessed example illustrates an interface state and is explicitly outside the primary research cohort’s prior-mark requirement.
- **A transparent scoring demonstration:** one in-memory action history supplies both counters. All-correct credit awards one point for every correct answer, including repeats. Distinct-item credit awards one point for an item’s first correct answer. Incorrect answers and explanation views earn no points in either counter.
- **An original counts-versus-rates mini lesson:** two familiar practice items and two new applications, with correct-answer explanations. The visitor can repeat any item or choose another.
- **An independent, unscored teaching check:** a new cancellation-rate scenario changes neither practice counter. It is a demonstration item, not a validated transfer measure.

No learner example is an observed OULAD record. No participant experiment, behavioral finding, mastery measure, or learning benefit is claimed.

## A two-minute walkthrough

1. Compare the two views for Learner A. Select Learner B and then the example without assessment evidence. Notice that the activity numbers remain identical between views and an unknown mark never becomes zero.
2. In practice item 1, choose Tuesday and check the answer twice. The all-correct counter becomes 2; the distinct-item counter remains 1.
3. Select item 3, submit its first response, then read the explanation. Both actions leave the counters unchanged. Answer correctly next: the counters become 3 and 2.
4. Try the separate teaching check. Its feedback leaves both practice totals unchanged.
5. Reset practice or load the four-action example history. The example supplies two correct answers to the first item, one incorrect answer to the third item, and one explanation view; its totals are 2 and 1.

## Verification completed

Direct JavaScript checks passed for initialization, missing selections, first correct answers, correct repeats, incorrect answers, explanation views, explanation-before-correct behavior, all four answer keys, both resets, example-history replacement, synchronized scenario numbers, unknown marks, and the independence of the teaching check from practice points. There were **17 checks**, using a lightweight document stub rather than a browser.

Static HTML checks confirmed that all 30 element IDs are unique and that the page has no external assets or frames. JavaScript syntax parsed successfully. The source uses semantic headings and forms, explicit radio labels, keyboard-operable native controls, visible focus styles, feedback status regions, a skip link, reduced-motion support, and a narrow-screen single-column layout.

**Browser walkthrough completed:** after network permission was granted for a localhost preview, the demonstration was checked in the in-app browser. Desktop and 390-pixel layouts were inspected; the narrow layout had no horizontal overflow. Scenario changes kept both dashboards synchronized. Two correct repeats produced counters of 2 and 1; an incorrect answer, explanation view and unscored check left those totals unchanged. The example-history control restored the documented sequence. A basic keyboard check moved focus from Check answer to Read explanation. `preview.png` shows the inspected example state.

**Verification limitation:** this is not a comprehensive accessibility, screen-reader, keyboard-navigation or participant usability evaluation. Those checks remain outstanding. Browser tests verify interface behavior, not learning efficacy.

## Boundary of this artifact

This is a portfolio demonstration of a measurement argument and a scoring contrast. It is not the 20–25-minute participant study instrument. It contains no recruitment, consent, random assignment, participant identifiers, timestamps, event export, or research data collection. Both policies are visible together for inspection; a future randomized study would show only the assigned policy while keeping the learning task and feedback consistent.

The page can motivate a future test. It cannot show whether either policy changes practice choices, attention, motives, or learning.
