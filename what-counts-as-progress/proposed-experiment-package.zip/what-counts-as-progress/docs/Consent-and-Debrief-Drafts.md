# Consent and debrief drafts

**Nicholai Chasseau · 3 October 2026 · Proposed protocol 0.1.0-draft**

These are drafts for review. They are **not approved consent documents**, do not authorize recruitment, and must not be presented as institutionally approved. No participant collection is enabled in the current local instrument. Final researcher/review contacts, recruitment population, compensation, private return channel, storage/retention and withdrawal arrangements depend on a future reviewed study and are intentionally not invented here. The [protocol](Proposed-Experiment-Protocol.md) and [materials](Study-Materials.md) define the task.

## Current development-demo acknowledgment

The public local tool should distinguish an acknowledgment of a technical demonstration from research consent:

> This is an unpiloted development demonstration of a proposed study, not an active participant study. It uses fictional teaching scenarios and an assigned scoring rule so the procedure can be inspected. The current code keeps this run's answers, choices and relative timing in browser memory. No information is sent to a research server, and participant collection is disabled.
>
> You can stop this development run at any time. Stopping tags the run withdrawn and excludes it from analytic outcome estimates; its in-memory technical history remains available for optional inspection. Resetting or refreshing clears that history. Export is optional and downloads a clearly labeled development JSON file to your device. It does not upload or submit the file. A downloaded file remains on your device until you delete it yourself. Please keep any export private; do not put it in the public project repository.
>
> I understand that I am inspecting a development demonstration and that this acknowledgment is not consent to an approved research study.

The acknowledgment event is `demo_acknowledged` with `research_consent: false`. Current exports are labeled `development_demo` or `synthetic`, never participant findings. The local tool does not collect names, contact details or IP addresses, and its timing fields are relative elapsed milliseconds. The session label describes a technical run, not an authenticated person.

## Future participant information sheet — review draft

**Study title:** Practice scoring rules and application of a short numerical lesson.

**Researcher:** Nicholai Chasseau and any approved study collaborators. **Study/review contact:** [insert the reviewed study contact and independent review contact before use]. No current institutional sponsorship or approval is implied.

**Purpose.** We want to understand how different accurate practice-scoring rules relate to practice choices and performance on unfamiliar examples. You will be assigned one of two rules by chance. The lesson and questions are the same in both groups. The practice points describe answers under the assigned rule; they are not a diagnosis or validated measure of ability.

**Who can take part.** The proposed first study is for adults aged 18 or older who can read the English materials and use the browser. [Insert the final recruited population, accessibility arrangements and entry process.] Participation is voluntary, and you should take part in only one study session.

**What happens.** The session is expected to take about 20–25 minutes. You will answer four baseline questions without feedback, read a brief lesson, complete a guided warmup, see your assigned practice-scoring rule and answer a rule-comprehension question. You will have eight minutes to choose practice actions, followed by six questions in new contexts and optional ratings about your goals and experience. All numerical scenarios are fictional. You may stop at any time; understanding the rule incorrectly is not a reason for removing your record or changing your assigned group.

**Choice and possible inconvenience.** You may find some questions difficult or the score distracting. You may leave without penalty and may skip the optional ratings. The final study must state how any compensation or credit is handled if you stop; neither practice points nor correctness will determine it. [Insert the actual approved compensation arrangement. There is no funded recruitment arrangement at present.] No personal learning benefit is promised.

**What is recorded.** The proposed record contains an anonymous study code, assigned rule, answers, practice selections, explanation views, optional ratings, completion/stop markers and relative event timing. It contains no names or contact details in the analytic record. The approved recruitment process may need separate contact/eligibility information; [describe that separately, who can access it and whether it can be connected to the study code]. We will not describe these records as fully anonymous if a study code can still connect them to recruitment information.

**Local recording and providing a file.** The proposed local instrument has no automatic research upload or account. Its working record stays in browser memory. If the approved study asks you to export and privately provide a file, exporting first saves a JSON file on your own device; it does not send the file to the researcher. [Insert the private reviewed return channel and instructions before launch.] Refreshing/resetting may lose an unexported record. A saved file remains on your device until you delete it yourself. Do not post your file publicly.

**Storage, use and sharing.** [Insert secure storage location, approved access, retention period and deletion procedure.] Reports may describe group results. This draft proposes sharing code/materials and aggregate results, not participant-level records by default. Any participant-level sharing would require its own reviewed disclosure-risk and consent basis. The public software repository is not a collection channel.

**Leaving and deletion.** Before you provide a file, you can stop, clear the local record and choose not to provide it. The current development stop button retains a flagged technical trace until reset/refresh; it must not be mistaken for a fully implemented future participant-deletion procedure. A future participant mode must implement and explain the approved withdrawal behavior. After privately providing a file, [insert how to request deletion using the study code, the relevant time limit, and any honest limit after nonidentifiable aggregate results have been released]. Anonymous enrollment/arm totals may be retained after withdrawal only if the final review and consent permit; no withdrawn answers may be used in outcome estimates.

**Questions.** [Insert researcher contact for the task and independent review contact for participation rights.] Ask before proceeding if anything is unclear. You may decline without giving a reason.

## Future consent statements — review draft

Only use a finalized version after the review and recruitment gates are met. Suggested statements are:

- I am aged 18 or older and have read the information sheet.
- I understand the activities, approximate duration, assigned scoring rule and recorded fields.
- I understand participation is voluntary and know how to stop or request deletion under the explained arrangements.
- I understand exporting a file does not automatically submit it, and I understand the private return procedure if I choose to provide it.
- I understand the compensation/storage/sharing arrangements explained in the final information sheet.
- I agree to take part in this reviewed study.

Allow a clear decline/exit. Do not precheck consent, infer it from visiting the page, require endorsement of optional ratings, or imply that a development acknowledgment is research consent.

## Debrief text — draft for the proposed study

> Thank you for considering this task. The study compares two accurate scoring rules. Under all-correct credit, every correct practice answer earns a point, including a correct repetition. Under distinct-item credit, each item earns one point when first answered correctly; another correct answer to that item adds no point. Both groups use the same teaching and begin with one point for the guided warmup.
>
> We are interested in whether the rule changes the first practice action people choose and how they perform on new examples afterward. We ask separately about goals, interest, enjoyment, competence and pressure. Choosing a repeat does not establish that someone was wasting effort or deliberately pursuing points instead of learning. Repetition can be useful, and reported goals can coexist.
>
> The later questions do not earn practice points. They are original, unvalidated assessment items, not a diagnosis, verified mastery score or established measure of learning gain. A difference between scoring rules would apply to this task and comparison; it would not by itself show that all digital metrics help or harm motivation.
>
> All teaching scenarios were fictional. No false performance benchmark or fabricated comparison with other people was used. If you wish to review the numerical explanations after finishing, the study materials provide them. [Insert the final study contact, private return instructions, withdrawal/deletion process and where group results will be available.] No participant result exists in the current development package.

## Conditions before these drafts can be used

Finalize participant-facing language with the actual research-review route; identify a real accessible population and collection/return process; pilot the task where permitted; specify compensation, storage and withdrawal; and freeze/register the final protocol before its randomized sample. Local browser tests and synthetic sessions do not satisfy participant piloting, ethical review or informed-consent validation.
