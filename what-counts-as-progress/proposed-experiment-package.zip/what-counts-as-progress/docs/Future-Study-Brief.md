# What Counts as Progress?

**Supporting future experiment: scoring rules, practice choices, and independent learning**  
Prepared for Nicholai Chasseau · 3 October 2026 · Fall 2027 PhD preparation

**Historical design brief:** The current operational development draft is [Proposed-Experiment-Protocol.md](Proposed-Experiment-Protocol.md), aligned with the [psychological argument](Psychological-Argument.md), original materials and instrument. It makes first practice action the primary outcome and keeps repeat proportions secondary. This brief preserves the initial design discussion; the current protocol governs the proposed experiment. Neither document is an external preregistration.

**Status:** supporting design brief for a later participant experiment. See the [current recommended portfolio project](Research-Report.md), adapted to 40 hours/week, no budget, and no participant access. The public-data analysis and fictional companion demonstration are complete. The participant experiment, participant-study instrument, external preregistration and participant findings remain proposed.

## Recommendation and purpose

Build a small browser-based learning experiment that tests one concrete product decision: whether correctly repeating the same practice question earns another point. The portfolio piece should connect a dashboard rule to observable choices and an assessment of learning outside the dashboard.

This directly develops your proposed research on digital measures supporting meaningful goals or becoming goals themselves. Your existing Psychology MA thesis, quantitative analyses, independent survey, and AlerTT prototype already demonstrate substantial preparation. This project would add evidence of experimental design, behavioral measurement, and evaluation of an interface. That is a useful addition to your application narrative; it does not establish an admissions probability.

You selected the educational setting and can devote **40 hours/week**, with **no participant budget or access**. Keep this experiment as the next study within the portfolio project; the immediate empirical work should use existing open learning data. Participant work described below requires a future review and recruitment pathway, and is not required to complete the current portfolio piece.

## Research question

**Does awarding points for correctly repeating an already successful practice item change learners’ practice choices and their ability to apply the lesson to unfamiliar problems?**

The predicted behavioral effect is greater repetition when repeats earn points. The learning effect is an open, two-sided question: repetition could support learning, have little effect, or crowd out useful practice.

Treat this as a focused extension of existing work, with a reusable experimental instrument. Do not claim that digital measurement harms learning generally or that this is the first study of metric–goal conflict.

## Experimental contrast

Randomly assign participants to one of two scoring policies after a common pretest, lesson, and warm-up.

| Component | All-correct credit | Distinct-item credit |
|---|---|---|
| First correct answer to an item | +1 point | +1 point |
| Correct repetition of that exact item | +1 point | No additional point |
| Incorrect answer or explanation view | No point | No point |
| Rule displayed to the learner | “Each correct answer earns one point. Repeated questions also count.” | “Each question earns one point when first answered correctly. Repeated questions do not add points.” |

Use the same interface layout, lesson, item bank, practice menu, answer explanations, time allowance, and learning-goal instruction. Compensation, if offered, should be the same and independent of points or performance. Avoid adding rankings, streaks, adaptive prompts, or different visual emphasis in this first experiment.

The second policy measures breadth of successful item attempts. **It is not a validated measure of mastery.** Display it as “Practice points,” with the rule clearly visible. Record identical underlying events in both conditions. Raw point totals are not comparable evidence of performance because the rules differ.

The causal comparison is between these two scoring policies. It does not estimate the effect of having a dashboard versus having no dashboard, or identify a particular psychological mechanism.

## Learning task and participant experience

Use a compact statistical-reasoning lesson, provisionally **interpreting counts versus rates**. This uses your existing quantitative strengths and provides a bridge from prior risk/data work to research on feedback. Develop original, clearly fictional examples rather than reproducing published test items or presenting fabricated real-world statistics.

Start with one or two learning objectives and write the independent assessment before designing the dashboard. Example objective: distinguish a change in event counts from a change in risk when population sizes differ, then apply that distinction in a new context.

An initial session can target roughly 20–25 minutes; pilot the actual timing:

1. **Consent and baseline assessment:** short original problems assessing prior knowledge.
2. **Common lesson and guided warm-up:** identical explanations and answer feedback. Ensure the practice menu can offer at least one previously correct item without imposing a post-randomization eligibility rule.
3. **Random assignment and rule explanation:** show the assigned scoring policy accurately. Check comprehension and repeat the explanation when necessary. Record comprehension; do not discard randomized participants afterward just because they misunderstand the rule.
4. **Approximately eight minutes of voluntary practice:** choose an exact repeat of a previously correct question, review an explanation, or attempt a new application problem. Keep the resources and menu ordering identical across groups.
5. **Independent transfer assessment:** unfamiliar scenarios testing the same principles, with no practice points and no access to the dashboard or lesson.
6. **Brief interpretation questions and debrief:** ask what influenced choices and what the participant thought the score measured. Ask these after practice to avoid prompting metric-focused behavior beforehand.

Use adults for the initial study. If the sample is not students, describe it as adult online learning; do not generalize it to university coursework. A delayed test is a later extension, not a requirement for the first piece.

## Outcomes and analysis

**Primary behavioral outcome:** each participant’s proportion of voluntary question selections that are exact repeats of items previously answered correctly. Define eligibility at the moment of selection using the event history. Count new questions and retries of previously incorrect questions in the denominator, but not explanation views; report explanation use separately. Specify the treatment of participants with no voluntary question selections before collection—for example, primary estimates among participants with defined proportions alongside a separate report of nonparticipation and a prespecified sensitivity analysis. Avoid silently treating no practice as zero repetition.

Report the between-group difference and its uncertainty. Participants are the independent experimental units: hundreds of click records do not create hundreds of independent participants. First voluntary choice can be a prespecified secondary behavioral measure with a simpler denominator.

**Key secondary educational outcome:** score on the independent transfer assessment, comparing conditions while adjusting for baseline knowledge. Use a two-sided estimate. Pilot difficulty, item ambiguity, and floor/ceiling effects; describe this as a purpose-built assessment rather than a validated scale.

**Exploratory outcomes:** number of practice selections, explanation use, event sequences, perceived pressure, and reasons for choices. Browser timestamps are measures of recorded activity, not direct measures of attention. Custom self-report questions should be reported as individual items unless there is a justified measurement model. Mediation and subgroup analyses would be exploratory and likely too imprecise in a small pilot.

Keep the first analysis within your existing R skills: documented event cleaning, participant-level summaries, an appropriate group comparison, baseline-adjusted transfer analysis, and clear plots. More elaborate modeling is useful only if the question or data require it.

Before collection, specify the outcome definitions, randomization, stopping rule, sample-size rationale, exclusions, missing-data handling, and analysis. Register the frozen plan before the randomized study; distinguish any earlier development pilots from the registered sample. An OSF preregistration is a time-stamped study plan, not peer review or proof that the methods are sound. [OSF guidance](https://help.osf.io/article/330-welcome-to-registrations)

## How to interpret the results

| Observed pattern | Defensible interpretation |
|---|---|
| Repeat credit increases repetition | The scoring policy changed practice allocation. This alone does not show wasted effort or deliberate metric optimization. |
| More repetition and poorer transfer under repeat credit | Evidence consistent with score–learning misalignment in this particular task and comparison. Mechanism and broader generalization remain open. |
| More repetition and better transfer | Repetition may support the educational goal in this setting; revisit the concern that it displaces learning. |
| More repetition and an uncertain transfer difference | Behavioral responsiveness is clearer than the learning consequence. An imprecise or nonsignificant estimate is not evidence of equivalence. |
| No clear behavioral difference | Check rule comprehension, availability of meaningful choices, score salience, ceiling effects, and precision. Report the uncertainty rather than declaring that metrics do not matter. |

The report should distinguish behavior, learning, and participants’ stated motives. None is an automatic substitute for the others.

## Feasible stages and schedule

Finish a credible research package before relying on a participant result for applications. Recruitment and review may take longer than the build schedule.

| Target period | Work and reviewable output |
|---|---|
| 5–11 October | Focused literature map; exact question; learning objectives; draft pretest, practice items, transfer test, and scoring rules. Identify available research review and recruitment routes. |
| 12–18 October | Minimal prototype; event dictionary; randomization and scoring checks; technical walkthroughs; reproducible analysis using explicitly simulated records. |
| 19–25 October | If an appropriate review pathway permits participant work, use roughly 5–8 development participants to check comprehension, difficulty, choice availability, and timing. Revise and freeze materials. Otherwise, complete the protocol and technical verification. |
| 26 October–1 November | Portfolio case study, working demonstration, analysis materials, and study-plan draft. Register a real upcoming study only once the protocol and collection plan are settled. |
| Early to mid-November, if feasible | Run a separately registered randomized feasibility pilot and add an honest preliminary report. Protect time needed for application materials. |

Approximately **40–60 participants total** can be a provisional feasibility-pilot scope if recruitment and budget permit. This is not a power calculation. Use it to examine comprehension, completion, logging, variation in choices, and preliminary estimates with uncertainty. Do not promise sensitivity to small learning effects. A larger effect-testing study needs a sample-size calculation based on a justified meaningful effect and the planned analysis; do not choose its target from the apparent effect in a tiny pilot.

Before recruiting anyone, establish the appropriate ethics/review requirements with a suitable institution or research mentor. Development interviews also involve participants. Include informed consent, voluntary withdrawal, minimal personal data, and appropriate storage. If that pathway or recruitment is unavailable, finish a **research-ready prototype and protocol** with clearly labeled simulated analysis; describe its status accurately. Simulated data verify software and analysis, not the research hypothesis.

## Finished portfolio package

- **Working demonstration:** a visitor can inspect both scoring policies and complete a short example. Mark demonstration records and sample scores clearly.
- **Concise case study:** question, theoretical rationale, design decisions, measurement rationale, development evidence, and current findings/status. Approximately 4–6 pages is a useful target.
- **Study materials:** item bank, answer key, independent transfer assessment, consent/debrief drafts, event dictionary, and dated protocol or registration link when available.
- **Reproducible R report:** cleaning decisions, outcome construction, plots, estimates, uncertainty, and limitations. Keep synthetic and observed data clearly separated; share participant data only when consent and disclosure risk permit.

Lead the portfolio page with the research question and your specific contribution. Identify assistance with coding or drafting when material, and make clear which scientific decisions you made and can defend. Include a short walkthrough so a faculty reader can grasp the experiment quickly.

This is particularly coherent with your existing SFU statement. Hatala’s current description emphasizes theoretical and experimental dashboard research and explicitly lists a project report or portfolio as possible evidence of research potential. This supports relevance, not guaranteed supervision or admission. [SFU research and applicant guidance](https://www.sfu.ca/~mhatala/index.html)

## CV language at different stages

These are templates to use **only after the stated work exists**.

**After the prototype and protocol are completed:**

> Designed a browser-based learning experiment and study protocol testing how repeat-credit scoring rules affect practice choices and independent learning; implemented event logging and verified an R analysis pipeline with labeled simulated data.

**After a real randomized pilot is completed:**

> Designed and conducted a [preregistered, if applicable] randomized pilot (N = [actual sample]) comparing repeat-credit policies; analyzed practice choices and an independent transfer assessment in R and published study materials with documented limitations.

Keep the project under independent research or research projects. Use “in development” while appropriate; do not list a design brief as a completed experiment or a preregistration as a publication.

## Focused evidence map

The targeted literature check supports the project’s rationale while showing substantial adjacent work. It is not an exhaustive novelty review.

| Source | What it establishes and how the proposed piece differs |
|---|---|
| [Etkin (2016), The Hidden Cost of Personal Quantification](https://academic.oup.com/jcr/article-abstract/42/6/967/2358309) | Personal measurement can increase activity while changing enjoyment. It does not establish that quantification necessarily impairs learning. The proposed piece explicitly measures transfer. |
| [Silverman & Barasch (2023), On or Off Track](https://doi.org/10.1093/jcr/ucac029) | Logged streaks can become goals and affect subsequent engagement. Streak preservation is established adjacent work; the first portfolio study uses scoring rules rather than another streak comparison. |
| [Hatala & Nazeri (2024), dashboard standing and following behavior](https://learning-analytics.info/index.php/JLA/article/view/8547) | Dashboard standing is associated with subsequent discussion behavior. The proposed piece randomizes a specific rule and assesses learning separately. |
| [Gallagher et al. (2024), Reference Frames for Learning Analytics Dashboards](https://doi.org/10.1111/jcal.12912) | Personal-progress versus social-comparison reference frames already have an experimental precedent. That comparison alone is not the proposed contribution. |
| [Kratochvíl et al. (2025), Gamified Goal-Setting](https://www.muni.cz/en/research/publications/2495997) | Leaderboard effects on quantitative output and qualitative performance can differ. Quantity–quality divergence is not an untouched question; this piece examines a particular repeat-credit policy and learning transfer. |
| [Zheng, Hatala & Ahrar (2026), immediate and retrospective emotion–motivation profiles](https://www.sfu.ca/~mhatala/lak2026-77.pdf) | Closely related work examines dashboard responses over time. Its individual-comparison condition uses selected peers, not a learner’s own prior progress. The portfolio question concerns practice allocation and independently assessed learning. |

## First concrete step

Write the learning objective and **8–10 candidate transfer questions**, with an answer key and explanations of what each item tests. Then design practice activities that prepare learners for those questions. This makes the educational goal explicit before choosing what the dashboard counts.
