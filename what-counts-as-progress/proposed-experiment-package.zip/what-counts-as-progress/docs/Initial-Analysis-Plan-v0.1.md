# Initial analysis plan

**What Counts as Progress? · Version 0.1 · 3 October 2026**  
**Status:** specified after a schedule and availability audit, before inspecting activity–mark relationships. This is a local dated plan, not an external preregistration.

**Question.** How much information do recorded platform activity counts add about later assessed performance beyond prior assessed performance and course context?

**Data and unit.** The official UCI OULAD release, with its acquisition checksum recorded. One observation is a learner’s registration in a module offering. Learners can appear in multiple offerings; their records stay together in the evaluation split and uncertainty calculation.

**Why change the proposed cutoff?** A common 14-day activity window needs an assessment submitted before that window. At a day-28 cutoff, the strict schedule rule supports only one offering; day42 supports 14. Day56 supports 19 offerings across six modules and is earlier than day70, which gives the same course coverage. This decision uses schedules and availability, not estimated relationships or model performance.

**Cohort.** Require a known registration date before day56 and no withdrawal before day56. Select the latest scheduled tutor-marked assessment (TMA) due before day42 as the prior assessment; require a nonbanked, observed valid score and submission before day42. Select the first positive-weight TMA due after day56 as the target. Exclude banked target credit and targets submitted before day56. Retain learners without a target record or mark to describe missingness. Resolve any schedule-date ties by the smallest assessment identifier.

**Window and indicators.** Use days42–55 inclusive. Total clicks is the sum of recorded interactions in that interval. Active days is the number of those14 days with positive recorded interactions. Absence of a recorded interaction contributes zero recorded activity; it does not establish absence of study. Raw records and original identifiers are kept outside the public-facing outputs.

**Outcome.** The selected later TMA’s score, on the0–100 scale, among eligible learners with an observed nonbanked submission on or after day56. Missing marks remain missing. Separately report submission and mark availability for the entire eligible cohort. The unavailability of grade-release dates means prior-score adjustment is retrospective; it is not a claim that a live dashboard knew that score before day42.

**Primary comparison.** Fit a reference linear model with prior score and module-offering fixed effects. Compare it with the same model plus `log1p(total_clicks)`. The primary result is reduction in held-out mean absolute error, in mark points. The active-day model is secondary; a model containing both indicators is a secondary comparison. Do not select a preferred indicator based on training performance or change the primary result after looking at outcomes.

**Evaluation and uncertainty.** Reserve approximately20% of learners using the documented deterministic student-level partition; all their offerings stay in the same partition. Fit models and any learned preprocessing on development records only. Obtain paired student-cluster bootstrap intervals for held-out error differences,2,000 replicates with seed20261003; this reflects evaluation-sample uncertainty conditional on the fitted development models. Report course-specific comparisons. Check that the development sample contains all course-offering levels before fitting. A later-offering generalization analysis must use transferable module-level effects, not an unestimable new offering coefficient.

**Planned checks.** Validate table keys, join cardinalities, score ranges, chronology, banked-credit exclusions, and no learner overlap between partitions. Report a cohort flow and module-offering coverage. Planned sensitivities cover a28-day window, day70 cutoff, zero-weight prior assessments, same-day withdrawal, and simple quadratic terms. Keep each population change explicit. Describe submission selection and unobserved offline study; adjustment cannot establish that missingness is ignorable.

**Interpretation.** Estimates concern the usefulness of activity indicators for this recorded assessment criterion. They do not identify effort, mastery, score-seeking motives, or a causal effect of dashboards. Positive, negligible, heterogeneous, or negative predictive contributions are all legitimate outcomes.

**Next step.** Prepare the cohort and activity summaries using these frozen definitions, then run the specified comparisons. Changes require a versioned amendment with a reason and an explicit statement of whether outcome relationships had been inspected.
