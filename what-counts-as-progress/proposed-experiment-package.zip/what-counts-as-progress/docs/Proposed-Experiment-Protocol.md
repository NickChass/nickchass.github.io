# Proposed experiment protocol

**Nicholai Chasseau · 3 October 2026 · Protocol and item bank 0.1.0-draft · Event schema 1.0.0-draft**

**Status:** complete design draft for review, not an approved or externally preregistered study. The item bank, assessment and motivation questions are unpiloted. No participants have been recruited and no participant findings exist. The current local instrument supports development demonstrations and synthetic technical checks only. It is separate from the completed OULAD analysis and the original dual-policy dashboard demonstration.

Study identifier: `repeat-credit-counts-rates`. The machine-readable contract is [proposed-experiment.json](../config/proposed-experiment.json); teaching content, items and keys are in [Study Materials](Study-Materials.md); participant-facing language is in [Consent and Debrief Drafts](Consent-and-Debrief-Drafts.md). The [Psychological Argument](Psychological-Argument.md) distinguishes the motivational claims and alternative explanations.

## Question, contrast and estimands

Does giving an additional point for correctly repeating an already successful item change which practice action a learner initiates? A separate question asks whether the two policies differ on a new-context assessment after practice.

Randomize independently with probability 0.5 to `all_correct` or `distinct_item`, after the same baseline assessment, lesson and successful warmup. The all-correct policy gives one point for every correct practice answer. The distinct-item policy gives one point for an item's first correct answer across warmup and practice, and zero for further correct answers to that item. Incorrect answers and explanation views give zero under both policies. Both arms begin at one point for the same correctly completed warmup item P1. Baseline and transfer responses never affect practice points.

Hold lesson, item bank, menu layout/order, explanations, permitted resources, eight-minute opportunity, starting information and learning-goal instruction constant. Only the assigned scoring policy and the truthful corresponding score trajectory differ. Display one policy, not both, in the proposed experiment. Points buy nothing and do not determine compensation. Do not add streaks, rankings, adaptive prompts, social benchmarks, progress percentages or differential incentives.

The primary estimand is the probability difference, **all-correct minus distinct-item**, that the first practice action is selection of a previously correctly answered item for repetition during a fixed eight-minute window. This is a repeat-initiation outcome, not correctness of the new answer. No initiation counts as not initiating a repeat when a complete observation window is confirmed. The contrast estimates the effect of these two policy packages; it does not isolate a psychological mediator, the effect of having any metric, or a dashboard-versus-no-dashboard effect.

The directional behavioral prediction is greater repeat initiation under all-correct credit. Report a two-sided 95% interval. The educational comparison is two-sided: repetition could help, have little effect, or displace useful practice. Repetition alone does not establish waste, intentional gaming, or goal displacement.

## Population, entry and assignment

The proposed initial population is adults aged 18 or older who can read the English materials and use the browser controls. A real recruitment population, accessible alternatives, permitted resource policy and compensation arrangements must be specified with the review/recruitment route before collection. There is currently no funded or available recruitment route. Do not generalize an adult convenience sample to university students without corresponding recruitment.

A future approved study must prevent multiple randomized sessions from one person through its recruitment process; this local tool does not establish unique people or authenticate a session. Use an anonymous study code rather than contact details in analytic files. No demographics are needed for the current question.

People may leave before assignment. These are pre-randomization nonentries, reported separately where the approved process permits. The four baseline answers are required before teaching. The common warmup repeats P1, with identical explanations and a clear hint, until the participant submits its correct option. Anyone who leaves before successful warmup is not randomized. This guarantees at least one eligible successful-item repeat option **before** assignment without a post-treatment eligibility exclusion. Guided warmup success is not evidence of mastery.

Use a browser cryptographic random bit for independent 1:1 assignment in the current technical instrument; expected arm sizes need not be exactly equal. The browser obtains an unsigned 32-bit cryptographic draw and uses its high bit for the arm. Record the allocation method, raw draw and assigned arm once and keep that arm throughout the session. The cryptographic draw is not a PRNG seed; `assignment_seed` is null for this path. Synthetic seeded fixtures or explicit development arm overrides identify those methods separately. Future collection requires review of the allocation implementation and recruitment process; a fresh page visit must not be treated as another person.

## Procedure and timing

Target approximately 20–25 minutes overall, subject to permitted development piloting. Only the eight-minute practice opportunity is fixed in this draft.

| Stage | Procedure | Approximate time and records |
|---|---|---|
| Entry | Current tool acknowledges development-demo status. A real study would present approved information/consent and eligibility before beginning. | 1–2 minutes; no participant collection currently enabled |
| Baseline | B1–B4, one submitted answer per item, no correctness feedback or points. | 2–3 minutes; response events and baseline total 0–4 |
| Common teaching | Identical lesson about counts, proportions, relevant denominators and pooling groups. | 2–3 minutes; lesson completion |
| Common warmup | P1 with feedback; hint and retries until correct before allocation. | Approximately 1 minute; each attempt and eventual success |
| Assigned rule | Allocate once, show accurate rule, ask what a correct P1 repeat earns, then explain the correct rule. Rereading is available. | Approximately 1 minute; response and comprehension correctness |
| Voluntary practice | Start at one point. First menu is repeat P1, new P2, or review P1's explanation, in that fixed order. Practice lasts 480,000 elapsed milliseconds. | Eight minutes; menu actions, submitted answers, explanations and completion marker |
| Independent assessment | T1–T6 in fixed order, one submitted answer per item; no lesson/dashboard, feedback or practice points. | Approximately 4–5 minutes; responses and completion |
| Motivation questions | Six separate custom ratings after transfer. Skipping is allowed. | Approximately 1 minute; optional ratings |
| Debrief | Explain the policy comparison and what has not been established. For a future study, explain the approved export/return and withdrawal process. | Approximately 1 minute |

After a comprehension error, provide the truthful assigned-rule explanation and retain the randomized session. Do not exclude, change arm or silently discard someone for misunderstanding. Record comprehension to diagnose the instrument and report it descriptively, not to redefine the primary cohort after randomization.

During later practice, `new` presents the next unseen item P2–P6 in fixed order; `repeat` selects an encountered item already answered correctly; `review` opens an encountered item's worked explanation. A `retry` option becomes available only for encountered, not-yet-correct items. It is absent from the first menu and is not a successful-item repeat. The initial first-choice comparison therefore has identical choices in both arms. Later availability follows each session's actual history and is part of the policy's consequences, not a matched-exposure mechanism test.

Allow one submitted answer per question selection. Repeatedly pressing the same answer button must not produce additional points. A further answer requires a new menu action. The timer begins when the practice menu appears and uses monotonic elapsed time. At the deadline, practice controls stop earning points. Log a completion marker with the observed duration. Browser/background delays are a technical limitation to examine in piloting; elapsed time does not measure attention or active study.

## Outcomes and planned analysis

### Primary repeat-initiation outcome

Use the earliest valid `practice_menu_choice` within the window. Its explicit category is `repeat`, `new`, `review`, or `none`. A repeat must reference an item already correct before selection; P1 is available for everyone at the first menu. Unexpected initial retry choices or invalid item histories invalidate the export for this outcome rather than creating an alternative category.

| Observed record | Category | Binary outcome |
|---|---|---:|
| First valid menu choice is repeat | repeat | 1 |
| First valid menu choice is new | new | 0 |
| First valid menu choice is review | review | 0 |
| Complete eight-minute window logged, with zero menu choices | none | 0 |
| Zero choices and window not fully observed, or invalid/corrupt export | unavailable | Missing |
| Explicit withdrawal | withdrawn | Missing/removed according to consent |

A later incomplete stage does not erase an already observed first choice. A confirmed full window with no choice also remains observed if transfer is subsequently incomplete. A short or unobserved window with no actions is **not** evidence of no-choice. Accelerating the development clock is software inspection, not eight minutes of observed practice: a zero-choice accelerated development demonstration is unavailable, not `none`. Synthetic full-window fixtures may exercise the no-choice rule but do not establish a human observation. A withdrawal overrides availability; data designated for deletion must not be analyzed.

With complete primary ascertainment, compare the arm proportions over all randomized participants whose data can ethically be retained. Report the unadjusted risk difference and a Newcombe interval from separate Wilson 95% arm intervals without continuity correction. Show randomized/available/missing counts by arm and the four first-choice categories. No-choice is visible and is not described as choosing a new item or review.

If primary outcomes are unavailable, the available-outcome point comparison requires a selection assumption and is not automatically the all-randomized intention-to-treat effect. Report worst-case ascertainment bounds when arm enrollment totals are known: if an arm has `s` observed repeats, `m` unavailable outcomes and `N` randomized participants, its risk is between `s/N` and `(s+m)/N`; subtract the opposing arm bounds. These are identification bounds, not sampling-confidence intervals. Approved aggregate enrollment/withdrawal accounting is needed to establish `N`; an analyzer cannot recover unexported sessions from the local files.

The primary interval method is fixed for this draft; do not select a model after inspecting a real result. A future preregistration must finalize any baseline-adjusted sensitivity, missingness strategy and stopping rules before collection. Hundreds of event rows do not create hundreds of participants.

### Key secondary assessment outcome

T1–T6 measure application in new fictional contexts, including one pooled-proportion problem. Score each first submitted response using the fixed bank. A complete total is 0–6. If any item is absent, report item availability and set the total missing; do not convert an unattempted assessment into six wrong answers. Baseline total B1–B4 is 0–4 and is complete before assignment.

Estimate the mean transfer-total difference with OLS `transfer_total ~ arm + pretest_total`, coding distinct-item as the reference and reporting all-correct minus distinct-item with HC2 uncertainty. This is secondary; the transfer comparison is not promoted to primary after a favorable result. It concerns assessed performance after the session, not a validated latent learning construct or learning gain. Pretest and transfer are not parallel, calibrated forms and their raw difference is not a gain score.

Report complete-transfer rates by arm. Complete-case adjustment cannot remove informative attrition. As a bounded-score sensitivity, report unadjusted arm mean bounds assigning unavailable totals their permitted extremes 0 and 6, using valid enrollment counts. Do not call that a missing-data correction or an adjusted-effect interval. If either arm has insufficient outcomes or the regression is unidentified, report the limitation instead of an estimate.

### Exploratory outcomes

Report the six custom post-transfer items individually: score-goal endorsement, learning-goal endorsement, interest, enjoyment, perceived competence and point-related pressure. The two goal items ask whether each aim was one of the person's goals, not its priority relative to other goals or whether it displaced learning. These are new unvalidated items, not a validated motivation scale or a justified combined index. Their postpractice timing reduces advance prompting but permits recall and transfer-performance influences. They neither establish motive from behavior nor identify causal mediation.

Later practice counts, explanations, retries, successful-item repetitions, assessment-item accuracy and rule comprehension are exploratory/descriptive. Keep explanation views and incorrect-item retries distinct from successful-item repeats. Do not use these records for a post hoc preferred subgroup, mediation claim or mechanism conclusion. Secondary/exploratory intervals, if shown, have no multiplicity adjustment in this draft and must retain that label.

## Sample size, attrition and stopping

No sample has been collected and no sample size is currently recruitable by assumption. A **provisional precision candidate is 400 randomized participants**, approximately 200 per arm, because a balanced worst-case binary risk-difference interval has a normal-approximation 95% half-width of about 0.098 before attrition. The approximation is `1.96 × sqrt(0.25/n_arm + 0.25/n_arm)` and is a planning aid, not a power calculation or guarantee of the Newcombe interval's realized width.

| Total randomized, balanced and fully observed | Approximate worst-case 95% half-width |
|---:|---:|
| 40 | 0.310 |
| 60 | 0.253 |
| 100 | 0.196 |
| 200 | 0.139 |
| 400 | 0.098 |

At 400 randomized, 10% unavailable primary outcomes would leave approximately 180 observed per arm and a sampling half-width near 0.103; at 20%, approximately 160 per arm and 0.110. Attrition also creates selection uncertainty that these width calculations omit; missingness bounds are needed regardless of a narrow available-case interval. Independent people and roughly balanced ascertainment are assumptions, not properties established by synthetic sessions.

A 40–60-person randomized **feasibility** pilot would mainly examine completion, comprehension, logging, usable choices and assessment distributions. It does not support sensitivity to small policy effects, equivalence or a reliable mediator analysis. A preceding approximately 5–8-person permitted development pilot could identify confusing items and timing failures, but would not validate the assessment. These are possible future stages, not scheduled recruitment commitments.

Before a real confirmatory registration, select a substantively justified meaningful difference and decide whether precision or power is the goal; finalize the target with anticipated attrition and the actual accessible population. Fix a total-randomized stopping target and a calendar closure date before launch. Do not keep replacing participants until a desired number of favorable complete outcomes appears, inspect outcomes to stop early, or treat a tiny pilot effect as a stable power-calculation input. Any revised target requires a prospective amendment; the current draft contains no collection dates.

## Data, withdrawal and exclusions

The current tool has no server, analytics or research submission. A development demonstration keeps its event history in browser memory. Its Stop control marks the run withdrawn and excludes it from analytic outcomes while retaining a technical history for optional inspection/export. Reset or refresh clears that in-memory history. An explicit local export can create a file on the user's device; nothing is sent to the researcher by that button, and a saved file remains until its owner deletes it. No names, contact details, IP addresses or absolute timestamps are part of the event schema; session labels and relative timing still require careful handling if a future person provides a file.

A future approved study needs a private return channel, secure storage, retention/deletion period, named contacts, compensation policy and a process for identifying a file for withdrawal. These must be settled before recruitment. Participants may leave without penalty. Before export, the future participant procedure must offer clearing the local history and choosing not to provide a file; this is distinct from the current technical Stop control. After provision to a future study team, the approved information sheet must explain how to request deletion using the study code and any honest limit once anonymized aggregates have been released. Retaining anonymous enrollment/arm counts after withdrawal requires the final review/consent basis; never use withdrawn responses. Synthetic test records can exercise count-based bounds without establishing that retention is permitted for people. Do not upload participant exports to the public repository.

Pre-randomization eligibility and nonentry rules are separate from analytic exclusions. After assignment, retain assigned arm for outcomes that remain usable. Exclude demonstrably invalid exports, duplicates under a prespecified recruitment rule, and records requiring withdrawal/deletion; report reasons without selecting on performance. Comprehension errors, low scores, repetition, no-choice, or incomplete transfer are not reasons to discard an observed primary outcome. Conflicting or tampered event histories are technical-invalid cases, not scored failures. Log and report technical losses separately.

## Event and analysis contract

Session envelopes identify `study_id`, `protocol_version`, `item_bank_version`, `schema_version`, `session_kind`, a technical `session_label`, `participant_collection_enabled: false`, `arm`, `assignment_method`, `assignment_seed`, `assignment_draw_raw`, `status` (`completed`, `withdrawn` or `incomplete`), `events`, `state_snapshot` and a development/synthetic `notice`. Current session kinds are only `development_demo` and `synthetic`; the label is not an authenticated participant identifier. The state snapshot is for inspection; an analyzer recomputes outcomes from the ordered events. Adding a real-participant mode requires the review/pilot gates, not changing a label on an existing demo export.

Each event has consecutive `sequence` numbering starting at 1, `type`, nonnegative nondecreasing relative `elapsed_ms`, and a `payload`. Essential ordered events are acknowledgment; B1–B4 responses; lesson; P1 warmup responses with eventual correct success; condition assignment; comprehension; practice start; voluntary choices/responses/explanations; observed window completion; transfer responses/completion; optional ratings; completion or withdrawal. Some later events may be absent in incomplete sessions. Do not fabricate missing milestones.

Minimum event payloads:

| Event | Required content |
|---|---|
| `session_started` | `session_kind`, `participant_mode_enabled: false` |
| `demo_acknowledged` | `research_consent: false`; development-only acknowledgment |
| `baseline_response`, `warmup_response`, `transfer_response` | `item_id`, `response_option`, `correct`; analysis independently checks the key |
| `baseline_completed` | `answered`, `score`, `possible: 4`; verify four responses |
| `lesson_viewed`, `warmup_completed` | Lesson version; P1 correct success before allocation |
| `condition_assigned` | `arm`, `assignment_method`, `assignment_seed`, `assignment_draw_raw`, normalized `assignment_draw`, `initial_points: 1`, `eligible_correct_repeat_item_id: P1` |
| `rule_comprehension_response` | `response_option`, `response_points`, `correct`, `expected_points`, `exclusion: false` |
| `practice_started` | `duration_ms: 480000`, `initial_points: 1` |
| `practice_menu_choice` | `choice`, `item_id`, `previously_correct`, `previously_encountered`; verify history and timer |
| `practice_response` | `item_id`, `response_option`, `correct`, `previously_correct`, `points_awarded`, `total_points_after`; one response per selection |
| `explanation_viewed` | `item_id`, `points_awarded: 0` |
| `development_clock_advanced` | `added_ms`, technical-inspection purpose; not observed practice time |
| `practice_window_completed` | `duration_ms`, `observed_elapsed_ms`, `reason`, `first_choice_category`, `final_points`; verify a genuine full window for zero-choice development records |
| `transfer_completed` | `answered`, `possible: 6`, `score`, `complete`, `missing_not_zero`; verify against response events |
| `session_completed` | `transfer_complete`; later completion does not override individual outcome availability |
| `motivation_response` | `item_id`, value 1–7 or explicit missing/skip |
| `session_withdrawn` | `stage_at_stop`, `analytic_use: false`; no withdrawn responses analyzed |
| `development_export_requested` | `opt_in: true`, `no_remote_upload: true`; optional local file creation |

Technical checks must recompute correctness, score transitions and outcome availability from event order rather than trusting a displayed total. They should cover both arms, correct repetitions, wrong answers, review, retry, confirmed no-choice, early technical loss, incomplete transfer, withdrawal, incompatible versions and invalid histories. Synthetic results test implementation and missingness handling; they are not an effect estimate from participants.

## Gates before participant work

1. Author review: reproduce the existing public-data result, understand this policy estimand and independently inspect every draft item/key and analysis rule.
2. Establish a suitable research/institutional review route, actual adult recruitment access and approved consent/data-management process. Development interviews are also participant work and need the appropriate route.
3. Conduct permitted development piloting for item ambiguity, baseline/transfer floor and ceiling effects, timing, comprehension, meaningful choice availability, accessibility and event accuracy. The current package does not establish these properties.
4. Revise versions together, freeze materials/config/instrument/analysis, justify sample size and attrition, and prospectively register the real study before its separately recruited randomized sample. The local dated draft is not external preregistration.

Application wording may describe a completed proposed experimental package and verified synthetic analysis once the actual files/checks exist. It must not describe a conducted experiment, validated assessment, approved ethics protocol, participant finding or demonstrated learning benefit.
