# Plan amendments

**3 October 2026 · Before any activity–mark relationships or models were inspected**

Version 0.1 fixed the cohort, activity window, indicators, primary comparison and evaluation split after a schedule/availability audit. Its original plan and configuration are preserved beside the current versions.

Version 0.2 adds one robustness encoding: collapse exact full-row repetitions within the defined activity window before summing interactions. The integrity audit found repeated activity records. The source documentation does not establish whether they are distinct observations or an export artifact. Every official row remains in the primary interaction count; the alternative is a sensitivity analysis, not a claimed correction. Active-day counts are unaffected by exact repetitions.

No primary question, cohort rule, snapshot, target assessment, evaluation split, or outcome definition changed. The analysis-lock record preserves the previous and current configuration checksums. No inferential results informed this amendment.
