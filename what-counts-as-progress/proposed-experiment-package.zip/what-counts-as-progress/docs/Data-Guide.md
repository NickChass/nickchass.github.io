# Data guide

**What Counts as Progress? · 3 October 2026**

The official archive contains seven CSV tables. The table roles and fields were checked against the original codebook and the acquired files. All dates are relative to the start of the corresponding module offering; day 0 is its start. The exports use `?`, empty strings and `NA` as recognized missing-value tokens.

| Table | Actual rows | Role |
|---|---:|---|
| courses | 22 | Module-offering calendar |
| assessments | 206 | Assessment type, deadline and weight |
| studentRegistration | 32,593 | Registration and withdrawal |
| studentInfo | 32,593 | Enrollment context and final outcome |
| studentAssessment | 173,912 | Submitted work and recorded marks |
| vle | 6,364 | Learning-platform resource definitions |
| studentVle | 10,655,280 | Resource interaction records |

**Units and joining.** A course offering is `code_module + code_presentation`; a learner enrollment adds `id_student`. An assessment joins by `id_assessment`, and a resource joins by module, presentation and `id_site`. All small-table keys and tested foreign keys pass. Learner identifiers repeat across enrollments, so rows are not independent people.

## Fields used in the initial study

| Field | Use |
|---|---|
| code_module, code_presentation | Identify course context |
| id_student | Group a learner’s enrollments and evaluation partition |
| assessment_type | Select tutor-marked coursework (`TMA`) |
| assessments.date | Scheduled deadline; not actual submission |
| weight | Require a positive-weight target assessment |
| date_submitted | Separate earlier work and later outcomes |
| is_banked | Exclude credit carried from an earlier offering |
| score | Recorded0–100 assessment mark |
| date_registration | Determine registration before the cutoff |
| date_unregistration | Determine withdrawal before the cutoff |
| studentVle.date | Allocate activity to the observation window |
| sum_click | Count source-reported interactions |
| id_site | Identify resource/day repetitions |

The exported course-length field is `module_presentation_length`; the accompanying older codebook calls it `length`. The imported header is authoritative for the pipeline. The codebook also contains inconsistent enrollment totals; the actual verified table counts above are used in this project.

## Missingness and repeated activity

Missing assessment rows and rows with missing marks are different. In the eligible cohort, 3,393 enrollment records have no selected target submission record and 29 have a future target record without a mark. Neither is assigned a zero score.

The activity table is not unique at the learner/resource/day level. Within the eligible 14-day window, 684,147 source rows include 51,964 exact full-row repetitions beyond their first occurrence. Daily keys also occur with differing counts. Their origin is not established by the codebook. The primary count sums all official records; exact-row collapse is a planned robustness encoding. Global full-file uniqueness has not been certified; global duplicate counts within the defined eligible window have been computed.

## Interpretation limits

Activity records provide no dwell time, within-day action sequence, question correctness, or displayed-dashboard exposure. Marks have no recorded grade-release timestamp. Earlier marks support retrospective adjustment, but their availability to a live dashboard at the cutoff is unknown. Marks indicate assessed performance; they do not directly measure learning gain or transfer. Offline study is unobserved.

Full machine-readable column types and missing counts are in `audit/schema_missingness.csv`. Sources: [original dataset paper/codebook](https://pmc.ncbi.nlm.nih.gov/articles/PMC5704676/) and [official UCI release/license](https://archive.ics.uci.edu/dataset/349/open+university+learning+analytics+dataset).
