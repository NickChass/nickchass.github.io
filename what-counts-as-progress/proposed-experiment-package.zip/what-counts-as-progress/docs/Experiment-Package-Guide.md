# Proposed Experiment Package

**What Counts as Progress? · Development draft 0.1.0 · 3 October 2026**

This package turns the psychological question into an inspectable study design: does credit for correctly repeating an item change the first practice choice, compared with credit for distinct correctly answered items? The independent application assessment asks a separate educational question. The current package contains original draft materials, a development walkthrough and an analysis implementation. It contains no participant findings.

## Start here

1. Read the [psychological argument](Psychological-Argument.md) and [primary-source literature map](Literature-Map.md). They separate behavioral responsiveness, reported goal endorsement, enjoyment, perceived competence and assessed application.
2. Read the [proposed protocol](Proposed-Experiment-Protocol.md) for the operational contrast, outcome definitions, missingness handling, sampling rationale and decisions still requiring review.
3. Inspect the [original study materials](Study-Materials.md) and [consent/debrief drafts](Consent-and-Debrief-Drafts.md). The item bank is an unpiloted purpose-built assessment, not a validated scale.
4. Open [the development instrument](../experiment/index.html), or its [live walkthrough](https://nickchass.github.io/what-counts-as-progress/experiment/). The page is explicitly a development demonstration. It does not recruit participants or send responses to a research server.
5. Read the [instrument and analysis instructions](../experiment/README.md), then reproduce the technical checks and explicitly synthetic examples.

The [portfolio case study](https://nickchass.github.io/case-studies/what-counts-as-progress.html) explains how this proposed experiment follows the completed OULAD analysis. The [original dashboard demonstration](../prototype/index.html) lets readers compare both counters on the same fictional history. It remains a separate teaching demonstration, rather than the randomized study instrument.

## What is held constant

Both proposed conditions use the same learning goal, counts-versus-rates lesson, baseline questions, correctly completed warm-up, practice menu, item bank, explanations, eight-minute window and independent application assessment. Both begin with one practice point and a correctly answered warm-up item available for repetition. Only repeat credit differs: a further correct answer earns another point under all-correct credit and no extra point under distinct-item credit.

The primary outcome is repeat initiation: whether the first menu selection is a previously correct item for repetition during the fixed window. New-item choices, explanation review and a confirmed complete window with no action are recorded as distinct categories and count as zero for that specifically defined binary outcome. Withdrawal, missing exports and unobserved practice windows remain missing. Advancing the development clock without a choice does not confirm observed no-choice. Later repeat proportions are secondary and have their own denominator and availability limitations.

Neither the practice-point total nor a repetition count is a measure of mastery or evidence of an adopted score goal. A randomized policy difference could establish responsiveness to the policy package in the eventual sample; it would not by itself identify a psychological mechanism. Assessment performance and exploratory self-reports must remain separately interpretable.

## Record and analysis boundaries

The [study configuration](../config/proposed-experiment.json) identifies the draft protocol, item bank and event-schema versions. These versions describe the proposed study and do not amend the completed OULAD analysis configuration.

Manual walkthrough exports are labeled `development_demo`. Program-generated example records are labeled `synthetic`. Both are technical development records. They must never be presented as recruited participants, an observed treatment effect, a learning benefit or a completed pilot. The participant collection mode is disabled.

The [proposed analysis implementation](../scripts/09_analyze_proposed_experiment.py) summarizes outcomes at session level, keeps missing outcomes visible and demonstrates the specified comparisons. Its synthetic outputs verify implementation. Any sample-size simulation or precision calculation depends on declared assumptions and does not supply an empirical effect size or prove that a proposed sample is recruitable.

No raw or derived OULAD learner records, fitted models or résumé files are part of this package. Do not place future participant records in the public repository. The current walkthrough keeps answers in memory, with any local export initiated explicitly by the person reviewing it; it does not establish an approved future storage or consent procedure.

## Decisions before an actual study

The next scientific work is author and methods review, permitted development piloting, and revision of the materials. Check whether the questions measure the intended objectives, whether the practice choices are understandable, whether the assessment avoids floor and ceiling effects, and whether the interface is accessible. Technical correctness cannot establish these properties.

Before collection, establish the appropriate research review, recruitment and data-management route; resolve the contact and consent details; justify the meaningful effect or precision target and attrition allowance; remove development controls from the participant interface; and freeze and prospectively register the revised study plan. Neither the locally dated draft nor the current code is an external preregistration.

The candidate larger-study precision target in the protocol is a planning proposal, not a commitment to recruit with the current zero-budget/no-access constraints. A feasibility pilot would answer questions about comprehension and operation; it would not establish small educational effects or validate the complete measurement model.

## Author ownership and assistance

AI assistance supported literature retrieval, drafting, implementation and technical checking. Before using this package in applications, Nicholai Chasseau should independently reproduce the central OULAD result, review the primary papers and original items, and explain the experiment's estimand and limitations. Record any subsequent human review and revisions honestly. The application contribution is a completed analysis with a proposed experimental extension; no peer-reviewed publication or conducted participant experiment is claimed.

## Companion manuscript

[Digital Learning Metrics and Study Choices: Predictive Evidence and a Proposed Repeat-Credit Experiment](Manuscript.md) and its [PDF](Manuscript.pdf) integrate the completed analysis, psychological argument, and proposed experiment. This is an independent author-review draft, not a journal publication or participant-results paper.
