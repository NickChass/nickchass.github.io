# When a Progress Score Becomes a Goal

**Psychological rationale for the proposed repeat-credit experiment**

Nicholai Chasseau · 3 October 2026 · Protocol alignment: v0.1.0-draft

**Status:** Proposed participant research. The OULAD analysis and fictional demonstration are completed components; no participant experiment, validated custom instrument, external preregistration, or participant findings are claimed here.

## The psychological question

A learner can want to understand a lesson and also want to increase the score shown beside it. Those aims may support the same action, or they may favor different actions. This project asks whether changing what earns a practice point changes the learner's next study choice, and whether the resulting practice allocation is accompanied by differences in independently assessed performance.

The concrete contrast is **all-correct credit**, which awards a point for each correct response including exact repetitions, versus **distinct-item credit**, which awards a point only when an item is first answered correctly. Both policies are described honestly as practice points. Neither is presented as mastery. The proposed prediction is that allowing repeat credit increases the probability that the first voluntary practice choice is a previously successful item. The direction of the transfer-assessment difference remains open.

This is a question about motivation and self-regulation because it concerns the selection of an action among competing ways to use study time. The interface supplies a visible consequence of each action. The psychological issue is how people interpret and respond to that consequence, rather than whether a counter can be made to increase engagement.

## What prior experiments support

**Measurement can separate activity from enjoyment.** Etkin's six experiments measured coloring, walking, and reading. Tracking output increased the amount done while sometimes reducing enjoyment and subsequent engagement. In the reading-framing experiment, describing reading as useful work attenuated the enjoyment difference. This supports measuring experience separately from amount; it does not predict that the present learning task will be less enjoyable or that measurement necessarily damages learning. [Etkin, 2016, author manuscript](https://marketing.wharton.upenn.edu/wp-content/uploads/2016/10/Etkin-Jordan-11-12-15-Hidden-Cost.pdf)

**A recorded pattern can itself become an objective.** Silverman and Barasch examined logged streaks in seven studies involving exercise, language questions, and games. Their language-task Study 4 directly asked about streak maintenance as an active goal and analyzed its relationship with subsequent engagement. Their manipulation concerns intact versus broken streaks, not repeat-credit rules, and the language choices are not independent tests of learning transfer. The present study draws a related hypothesis about a score without treating streak findings as proof of the proposed mechanism. [Silverman & Barasch, 2023, accepted manuscript](https://udspace.udel.edu/server/api/core/bitstreams/7e3e3b64-8bf2-4527-ac93-94a160358165/content)

**More output does not establish greater intrinsic motivation.** Mekler and colleagues' online image-annotation experiment compared points, levels, and leaderboards with a control and assessed tag quantity, quality, competence, and intrinsic motivation. The game elements increased output quantity without statistically significant differences in competence or intrinsic motivation. A null test is not proof of equality, and image annotation is not learning transfer. The study nevertheless gives a direct precedent for keeping behavioral output and subjective motivation separate. [Mekler et al., 2017, authors' institutional record](https://research.aalto.fi/en/publications/towards-understanding-the-effects-of-individual-gamification-elem/)

**Progress information can carry different psychological meanings.** Koo and Fishbach's four studies examined completed versus remaining goal actions and commitment certainty. Their academic Study 1 measured stated study-time and effort intentions in an exam scenario, rather than actual exam learning. Their results motivate asking what a display means to a learner: evidence of commitment, a remaining discrepancy, or a locally valuable score. The proposed experiment does not manipulate commitment certainty or completed-versus-remaining framing. [Koo & Fishbach, 2008, author-hosted paper](https://faculty.chicagobooth.edu/-/media/faculty/ayelet-fishbach/research/kf_jpsp08.pdf)

**Feedback may be experienced as information or pressure.** Ryan's experiment compared informational and controlling feedback and found lower intrinsic motivation under controlling feedback. That distinction motivates competing explanations involving perceived competence or pressure. The present policies do not directly randomize those experiences, so their effects cannot be attributed to either process from the policy comparison alone. [Ryan, 1982, author-associated archive](https://selfdeterminationtheory.org/SDT/documents/1982_Ryan_ControlandInfo_JPSP.pdf)

These are substantial precedents. This focused review does not establish original novelty. The intended contribution is a transparent, bounded comparison of two correct-answer credit policies in a learning task, with observable practice choices, explicit measurement boundaries, and an assessment outside the points system.

## The claim the experiment can test

In the development protocol, everyone receives the same counts-versus-rates lesson and completes the same warm-up item, P1, correctly before randomization. Both conditions begin with one point. The first practice menu offers repeating P1, attempting new item P2, or reviewing the explanation. The layout, item bank, answer feedback, menu order, and eight-minute allowance are held constant. Only the rule for crediting repeated correct answers changes.

The proposed primary outcome is the **intention-to-treat difference in the probability of choosing the repeat option first**. Repeat is coded 1; a new-item choice, explanation review, or an explicitly recorded no-choice timeout is coded 0. Those categories are also reported separately. Withdrawal and corrupt or unavailable exports remain missing rather than being interpreted as no choice. If primary outcomes are unavailable, an available-outcome comparison requires a selection assumption and is not automatically the all-randomized effect; availability and planned missing-outcome bounds must accompany it. This outcome concerns the first decision, before different earned-score trajectories accumulate. It does not measure all later practice allocation; later sequences are secondary evidence.

Randomization can support a causal estimate of the assigned scoring-policy package on this outcome in the eventual studied sample. That package changes both the availability of repeat credit and the subsequent visible score trajectory. It does not isolate a pure reward mechanism, a framing mechanism, or the effect of having a metric versus having none. Both conditions contain points.

The completed OULAD result supplies a complementary measurement argument: recorded activity added modest predictive information about later coursework marks. It cannot show how anyone responded to a display, because dashboard assignment and exposure were not recorded. It also contains no item-level correctness with which to test the repeat-credit contrast. The observational analysis and proposed experiment answer different questions. [Completed analysis](Research-Report.md)

## Four outcomes that must remain distinct

| Construct | Proposed evidence | Interpretation boundary |
|---|---|---|
| **Study choice** | First menu selection; later logged selections summarized at participant level | Shows allocation of an opportunity, not motive, irrationality, or wasted study |
| **Stated goal endorsement** | Separate post-transfer questions about increasing the score and applying the lesson being among the learner's goals | Retrospective self-report; the two aims can coexist; these items do not measure relative priority or displacement and are unvalidated |
| **Interest, enjoyment and perceived competence** | Separate post-transfer questions about interest, enjoyment, and perceived capability | Subjective experience, not inferred from clicks, points, persistence, or test performance |
| **Assessed application** | Independent T1–T6 unfamiliar problems without practice points, analyzed with baseline knowledge considered | Performance on purpose-built items; neither a validated mastery scale nor a measured learning gain |

The current package uses six original exploratory self-report items: score-goal endorsement, learning-goal endorsement, interest, enjoyment, perceived competence, and point-related pressure. They are reported individually, without an automatic combined motivation index. Before collection, a researcher could instead select a documented interest/enjoyment subscale from the Intrinsic Motivation Inventory, justify any adaptations, and fix its scoring. The inventory's official guidance distinguishes enjoyment from competence, effort, perceived choice, and pressure; it cautions that self-report and behavior need interpretation. Merely borrowing this vocabulary does not validate the current custom questions. [Official IMI documentation](https://selfdeterminationtheory.org/intrinsic-motivation-inventory/)

Self-reports occur after the independent assessment to avoid asking participants to focus on points before the practice choice. This sequencing has a cost: assessment experience and recall can influence those answers. Associations between reported score-goal endorsement and repetition would therefore be exploratory. A mediation calculation would not establish that adopting a score goal caused the behavioral difference.

## Competing explanations

| Explanation | What it could produce | What the present experiment cannot resolve |
|---|---|---|
| **Priority given to the displayed score** | More repeat choices when the familiar correct answer can earn another point | A repeat choice alone cannot establish an adopted score goal or displacement of the learning goal |
| **Reasonable interpretation of the task** | Participants follow what they believe the study or interface values | Clear instructions and comprehension checks reduce ambiguity but do not eliminate demand effects |
| **Confidence or avoidance of difficulty** | A familiar answer feels safer than an unfamiliar item, with or without score interest | Perceived-competence reports do not independently identify this cause |
| **Useful rehearsal** | Repeating a successful item consolidates a rule and can improve later application | Repetition must not be classified as harmful before its consequences are examined |
| **Preference for familiar or enjoyable activity** | Repetition reflects what the participant likes doing rather than score pursuit | Enjoyment can coexist with score interest, and retrospective ratings do not establish the ordering of causes |

The study is stronger when these alternatives are visible before data collection. It should preserve equal access to new problems, show both scoring rules accurately, keep compensation independent of points, and avoid rankings or streaks. It should also record comprehension without excluding randomized participants merely because they misunderstand the rule. Those decisions support interpretation; they do not prove a mechanism.

## How findings would change the argument

More repetition would support behavioral responsiveness to repeat credit. More repetition together with poorer independent application would be consistent with a misalignment between the scoring policy and this task's educational objective. It would still leave the motive and causal pathway unresolved. More repetition together with better application would challenge the assumption that repeat credit displaces useful learning. An uncertain assessment difference would require a precision statement, not a claim that learning was unaffected.

An eventual claim about goal displacement requires more than a higher count: an explicit educational objective, evidence that the policies alter allocation, and evidence about whether that allocation serves the objective. A stronger mechanism study could separately manipulate score-goal instructions or feedback meaning, or examine choices after points are removed. Those are future extensions, not hidden additional claims in this two-condition design.

For a Psychology PhD portfolio, the present package demonstrates a tractable motivational question, competing explanations, distinct outcomes, and a design whose claims can be checked. Its current evidence consists of completed public-data analysis and technical development work. The participant protocol, self-report instrument, and application assessment still require review, piloting, a justified sample-size plan, and prospective specification before an experiment can produce findings.

See the [primary-source literature map](Literature-Map.md) and [current proposed protocol](Proposed-Experiment-Protocol.md) for the operational definitions. The [initial future-study brief](Future-Study-Brief.md) preserves the earlier design stage. AI assistance supported source retrieval and drafting; the applicant must verify the argument and defend the scientific decisions.
