# Publication notes

The publication copy preserves the frozen analysis configuration and numerical results. Absolute workspace paths in two fingerprint tables were replaced by repository-relative script/config labels and logical `PRIVATE_DERIVED_DIR` / `PRIVATE_MODEL_DIR` source labels. These private-directory labels identify input roles, not a required local directory name. The exporters in scripts 05 and 08 received a metadata-only change so future runs also use these labels while hashing the actual local input files.

The current fingerprint tables preserve each original executed-script MD5 as `script_at_analysis_execution`, with an `ANALYSIS_EXECUTION/` label identifying that historical source snapshot. A separate `published_script` row fingerprints the current script after the metadata-only exporter edit. The differing hashes do not indicate a new model run. Configuration, private input and fitted-model fingerprints are unchanged, and no estimates or frozen analysis rules were modified. The publication manifest fingerprints the current distributed files; historical run records describe the original completed execution. A future rerun will record the script actually executed and reuse the same reserved evaluation data.

The original locally dated plans retain their pre-analysis status. Execution records document completed evaluation. The later-offering check's exact implementation was specified after inspecting primary estimates and uses a subset of the same reserved learners.

No raw or derived enrollment records, fitted model objects, resumes or account credentials are included in this repository. Missing outcomes remain missing. The original OULAD release is separately downloadable and attributed in the README and report.
