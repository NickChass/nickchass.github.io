# Study materials and original item bank

**Nicholai Chasseau · 3 October 2026 · Protocol/item bank 0.1.0-draft · Schema 1.0.0-draft**

These are original, fictional, **unpiloted and unvalidated** materials for the proposed repeat-credit experiment. No participant results exist. All event counts describe invented teaching scenarios, not real organizations or people. The bank and exact keys are also in [proposed-experiment.json](../config/proposed-experiment.json); the procedure and analyses are in the [protocol](Proposed-Experiment-Protocol.md).

This document is a researcher-facing package and includes answer keys. In the proposed session, baseline and transfer keys/explanations are withheld until the assessment is complete. The public development artifact is inspectable and is not a secure or validated testing service.

## Common participant instruction

> Your task is to learn how to compare counts and proportions and apply the lesson to unfamiliar examples. During practice you may repeat a successful item, try a new item, or review an explanation. You will see the scoring rule assigned to this session. Practice points describe answers under that rule; they are not a measure of mastery. A later set of questions will not earn practice points.

The future study must standardize permitted resources before registration. The current draft needs no special software or paid tools. Browser, reading and arithmetic demands need accessibility and difficulty review; do not assume a low score identifies low motivation.

## Learning objectives
1. Distinguish a raw number of events from the proportion of relevant opportunities with that event, and compare proportions using the appropriate denominator.
2. Combine groups by adding event counts and denominators, rather than taking an unweighted average of group percentages.

The baseline covers denominator comparisons, change, missing information and equality. It does not calibrate all transfer skills, particularly pooled proportions. Baseline and transfer are different forms; do not subtract their raw totals and call the difference learning gain.

## Common lesson — shown identically in both arms

### Counts and proportions answer different questions

A count tells you how many events or people were recorded. A proportion tells you what share of the relevant group or opportunities had that event: event count divided by total opportunities. Multiply by 100 to express the proportion as a percentage. In this exercise, rate means this percentage, not events per unit of time.

### Compare like denominators

In a fictional example, 8 of 40 forms at one office are incomplete (20%), while 9 of 60 at another are incomplete (15%). The second office has more incomplete forms, but a smaller proportion. If only the incomplete-form counts are known, the proportions cannot be compared without the totals. A larger count can coexist with a smaller, equal or larger proportion.

### Combine groups using their totals

If one group has 6 successful attempts out of 10 and another has 12 out of 40, the combined share is (6 + 12) / (10 + 40) = 18/50 = 36%. Averaging 60% and 30% would give 45% and would incorrectly give the two different-sized groups equal weight.

### Keep the claim narrow

These records describe the examples shown. They do not explain why a difference occurred or guarantee the same result in the future. The practice score counts answers under the stated rule; it does not establish mastery. Your task is to learn to apply the lesson to unfamiliar examples.

## Warmup and scoring instructions

P1 below is the common warmup and the exact repeat available at the first practice menu. Show its correct explanation after each submission, and if necessary show this hint:

> Week A has 30/100 = 30%; Week B has 40/200 = 20%. Choose Week A, the higher proportion. You may reread this explanation and try again before the assigned scoring rule begins.

Require a correct submitted P1 answer **before allocation**. Leaving before that point is a pre-randomization nonentry. Guided success guarantees an available previously successful item; it does not establish independent understanding. Both assigned policies start with one point and P1 already in the successful-item history.

| Assigned arm | Exact displayed rule |
|---|---|
| `all_correct` | Each correct answer earns one point. Repeated questions also count. |
| `distinct_item` | Each question earns one point when first answered correctly. Repeated questions do not add points. |

An incorrect response or explanation view earns no point under either rule. No points are earned by baseline or independent assessment answers, and no payment or reward depends on the points.

### Assigned-rule comprehension question

You answered the warmup question correctly. Under your assigned rule, what happens to your points if you choose that same question and answer it correctly again?

- **A.** I earn one more point.
- **B.** I earn no additional point.

**Key:** A under all-correct credit; B under distinct-item credit. Give an accurate assigned-rule explanation after the answer, with rereading available. Record correctness; do not exclude or reassign participants for an incorrect comprehension answer.

## First practice menu and later choices

The first menu is identical in both arms:

1. **Repeat a successful item:** P1, the exact warmup question.
2. **Try a new item:** P2, the first unseen application.
3. **Review an explanation:** P1's worked explanation, without answering or earning points.

During the eight-minute window, new items appear in the fixed order P2–P6. Later successful-item repetition and explanation review use encountered items. A separate retry category is available only after an item was attempted incorrectly and has not yet been answered correctly; it is absent from the initial menu. One menu selection allows one submitted answer. A further answer requires another selection, preventing repeated presses from creating points.

A repeat means the item was successful **before it was selected**, regardless of whether the next answer is correct. A retry of an incorrect item is distinct. After all new items are encountered, repetition, retry where eligible, and review remain available until the window ends. Choosing nothing is allowed and remains distinguishable from a technical loss or withdrawal.

## Baseline assessment B1–B4

Administer before the lesson. Require one answer to each item before allocation. No correctness feedback and no points during baseline.

### B1

In a fictional work exercise, Team Red leaves 9 of 30 jobs unfinished and Team Blue leaves 12 of 60 unfinished. Which team has the higher fraction of unfinished jobs?

- **A.** Team Blue
- **B.** The fractions are equal
- **C.** Team Red
- **D.** The fractions cannot be compared from these numbers

**Key:** C. **Explanation:** Red: 9/30 = 30%; Blue: 12/60 = 20%. Red has the higher fraction despite the smaller unfinished-job count.

**Draft rationale:** Compare proportions; resist numerator-only comparison.

### B2

A fictional warehouse records damage to 10 of 50 packages last week and 12 of 80 this week. Compared with last week, this week's damaged-package proportion is:

- **A.** Lower
- **B.** Higher
- **C.** The same
- **D.** Impossible to calculate

**Key:** A. **Explanation:** 10/50 = 20%; 12/80 = 15%. The count rose but the proportion fell.

**Draft rationale:** Distinguish change in count from change in proportion.

### B3

Two fictional campaigns each report 20 people donating. What additional information is needed to compare the share of contacted people who donated?

- **A.** The total amount donated
- **B.** The event duration
- **C.** The campaign names
- **D.** The number of people contacted by each campaign

**Key:** D. **Explanation:** The contacted-person total is the denominator. Equal donation counts alone do not establish equal proportions.

**Draft rationale:** Identify the relevant missing denominator.

### B4

At fictional Site A, 6 of 30 forms are incomplete. At Site B, 10 of 50 are incomplete. Which statement is correct?

- **A.** Site A has the higher incomplete-form proportion
- **B.** The incomplete-form proportions are equal
- **C.** Site B has the higher incomplete-form proportion
- **D.** There is not enough information

**Key:** B. **Explanation:** 6/30 and 10/50 are both 20%, despite different counts.

**Draft rationale:** Recognize equal proportions across different group sizes.

## Practice bank P1–P6

P1 is also the guided common warmup. During voluntary practice, every submitted answer receives the same correct-answer explanation in both arms; only the assigned credit rule changes.

### P1

At a fictional library, 30 of 100 visitors in Week A borrowed an e-book. In Week B, 40 of 200 visitors borrowed an e-book. Which week has the higher proportion of visitors borrowing an e-book?

- **A.** Week B
- **B.** Week A
- **C.** The proportions are equal
- **D.** The proportions cannot be compared

**Key:** B. **Explanation:** Week A: 30/100 = 30%; Week B: 40/200 = 20%. Week A has the higher proportion. The larger borrowing count in Week B does not establish a larger share.

**Draft rationale:** Common warmup and exact-repeat item; compare proportions.

### P2

In a fictional club exercise, 4 of 20 members of Club A miss a meeting and 6 of 40 members of Club B miss it. Which club has the higher missing-meeting proportion?

- **A.** Club B
- **B.** The proportions are equal
- **C.** Club A
- **D.** There is not enough information

**Key:** C. **Explanation:** Club A: 4/20 = 20%; Club B: 6/40 = 15%. Club A has the higher proportion, even though fewer members missed the meeting.

**Draft rationale:** First new application; numerator and proportion point in different directions.

### P3

Fictional Town X finds litter at 12 of 60 inspected locations; Town Y finds it at 18 of 120. Which statement describes the higher observed litter proportion?

- **A.** Town X has the higher proportion
- **B.** Town Y has the higher proportion
- **C.** The proportions are equal
- **D.** The proportions cannot be calculated

**Key:** A. **Explanation:** X: 12/60 = 20%; Y: 18/120 = 15%. X has the higher observed proportion. These descriptions do not identify a causal explanation.

**Draft rationale:** Compare proportions in a new setting.

### P4

In a fictional inspection, bicycles with a fault increase from 10 of 50 inspected to 15 of 100 inspected. Which summary is correct?

- **A.** Both the fault count and proportion increased
- **B.** The fault proportion stayed the same
- **C.** The fault proportion cannot be calculated
- **D.** The fault count increased while the proportion decreased

**Key:** D. **Explanation:** The count rose from 10 to 15, while 10/50 = 20% fell to 15/100 = 15%.

**Draft rationale:** Interpret count and proportion changes together.

### P5

A fictional delivery service has 18 late deliveries out of 90 in March. In April, 25% of 120 deliveries are late. Which month has the higher late-delivery proportion?

- **A.** March
- **B.** April
- **C.** The proportions are equal
- **D.** A percentage cannot be compared with a fraction

**Key:** B. **Explanation:** March: 18/90 = 20%; April: 25%. April has the higher proportion. Percentages and fractions can express the same quantity.

**Draft rationale:** Compare fraction and percentage representations.

### P6

In a fictional workshop, Group A completes 9 of 10 tasks successfully and Group B completes 12 of 30 successfully. What is the successful-task proportion across both groups combined?

- **A.** 65%
- **B.** 90%
- **C.** 52.5%
- **D.** 40%

**Key:** C. **Explanation:** Add counts and totals: (9 + 12)/(10 + 30) = 21/40 = 52.5%. Averaging 90% and 40% would incorrectly give unequal-sized groups equal weight.

**Draft rationale:** Pool groups using event counts and denominators.

## Independent new-context assessment T1–T6

Administer after practice, with no practice dashboard or lesson visible. One submitted answer per item; no feedback or practice points. Keys below are for researcher inspection, not shown during the assessment.

### T1

In a fictional appointment service, East records 24 missed appointments out of 120 scheduled; West records 30 out of 200. Which service has the higher observed missed-appointment proportion?

- **A.** West, because it has more missed appointments
- **B.** The proportions are equal
- **C.** There is not enough information
- **D.** East

**Key:** D. **Explanation:** East: 24/120 = 20%; West: 30/200 = 15%. East has the higher proportion.

**Draft rationale:** Unfamiliar context; comparison despite a misleading count.

### T2

In fictional water-quality checks, 12 of 80 samples fail in May and 20 of 200 fail in June. Which report is correct?

- **A.** Both the failed-sample count and proportion increased
- **B.** The failed-sample count increased while the proportion decreased
- **C.** The failed-sample count decreased while the proportion increased
- **D.** Both the failed-sample count and proportion decreased

**Key:** B. **Explanation:** The count rose from 12 to 20; the proportion fell from 12/80 = 15% to 20/200 = 10%.

**Draft rationale:** New context and values; interpret joint changes.

### T3

On one fictional school day, North records 40 absent students and South records 25. Enrollment totals are not provided. What can you conclude?

- **A.** North has more recorded absent students, but the absence proportions cannot be compared
- **B.** North must have the higher absence proportion
- **C.** South must have the higher absence proportion
- **D.** The absence proportions must be equal

**Key:** A. **Explanation:** 40 is a larger count than 25, but each school's relevant enrollment total is needed to compare proportions.

**Draft rationale:** Recognize what a count-only display does and does not establish.

### T4

Fictional Supplier A delivers 8% of 250 arrivals late. Supplier B delivers 15 of 100 arrivals late. Which supplier has the higher late-arrival proportion?

- **A.** The proportions are equal
- **B.** Supplier A
- **C.** Supplier B
- **D.** Percentages and fractions cannot be compared

**Key:** C. **Explanation:** A has 8%; B has 15/100 = 15%. B has the higher proportion even though A's late-arrival count is 20.

**Draft rationale:** Apply percentage/fraction equivalence with misleading counts.

### T5

A fictional food bank wants to describe which pilot has the lower parcel-loss proportion. Pilot A loses 8 of 40 parcels; Pilot B loses 12 of 100. Which has the lower observed loss proportion?

- **A.** Pilot A, because it loses fewer parcels
- **B.** Pilot A, because 20% is smaller than 12%
- **C.** The proportions are equal
- **D.** Pilot B

**Key:** D. **Explanation:** A: 8/40 = 20%; B: 12/100 = 12%. B has the lower observed loss proportion. This does not establish why the pilots differ or guarantee future performance.

**Draft rationale:** Match the stated criterion to the denominator; avoid causal overstatement.

### T6

In a fictional training assessment, 20 of 25 people in Group 1 pass and 30 of 75 in Group 2 pass. What share passes across both groups combined?

- **A.** 50%
- **B.** 60%
- **C.** 80%
- **D.** 40%

**Key:** A. **Explanation:** (20 + 30)/(25 + 75) = 50/100 = 50%. The unweighted mean of 80% and 40% is 60%, which gives the unequal groups equal weight.

**Draft rationale:** New pooled context; combine counts rather than average group percentages.

## Assessment blueprint and scoring

| Evidence | Items | Maximum | What it currently represents |
|---|---|---:|---|
| Baseline | B1–B4 | 4 | Earlier performance on these four original questions |
| Common successful item | P1 | One shared starting practice point | Guided correctness and a guaranteed repeat option |
| Practice history | P1–P6 | Policy-dependent points | Correct answer events or distinct successful items; raw point totals are not comparable performance outcomes |
| Independent assessment | T1–T6 | 6 | Performance on new fictional examples; not validated mastery, calibrated transfer or measured learning gain |

T1 and T4 concern proportions despite misleading counts; T2 concerns joint changes; T3 concerns missing denominators; T5 aligns a stated descriptive criterion with the correct comparison; T6 pools unequal groups. New contexts and values reduce exact answer repetition, but several items retain close mathematical structures. This is mainly a new-context application assessment, not established far transfer. All six items have four response options; guessing, arithmetic fluency and reading can affect scores.

The complete baseline total is the number correct, 0–4. The complete independent-assessment total is the number correct, 0–6. Missing transfer items create a missing total, with available responses and missingness reported separately; they are not filled with incorrect answers. These totals are draft task scores rather than validated scales. Item ambiguity, difficulty, floor/ceiling effects, meaningful learning opportunity and scoring reliability need appropriate development review and participant piloting before collection.

## Six optional post-transfer motivation items

Present only after the independent assessment. Use the same ordered anchors for every item: **1 Strongly disagree; 2 Disagree; 3 Somewhat disagree; 4 Neither agree nor disagree; 5 Somewhat agree; 6 Agree; 7 Strongly agree.** Allow an explicit skip/no response.

- **M_score_goal:** During practice, increasing my practice-point total was one of my goals. **Draft description:** Reported score-goal endorsement/adoption, not relative goal priority; custom unvalidated item.
- **M_learning_goal:** During practice, learning to apply the lesson to unfamiliar examples was one of my goals. **Draft description:** Reported learning-goal endorsement/adoption, not relative goal priority; custom unvalidated item.
- **M_interest:** I found the practice activity interesting. **Draft description:** Reported interest; custom unvalidated item, not a validated intrinsic-motivation scale.
- **M_enjoyment:** I enjoyed the practice activity. **Draft description:** Reported enjoyment; separate custom unvalidated item, not a validated intrinsic-motivation scale.
- **M_competence:** During practice, I felt capable of applying the lesson to new examples. **Draft description:** Perceived competence; custom unvalidated item.
- **M_pressure:** During practice, I felt pressure to increase my practice-point total. **Draft description:** Reported point-related pressure; custom unvalidated item.

Report each item separately as exploratory. Endorsing score and learning goals simultaneously is possible. These items do not rank the goals relative to each other or establish that one displaced the other. Interest and enjoyment are separate questions; neither single item is a validated intrinsic-motivation instrument. Post-transfer ratings may reflect recall, perceived performance and task expectations. No combined motivation index, causal mediation or motive inferred from repetition is proposed.

## Review and change control

The exact item text/options/keys in the configuration and browser bank must agree. Change wording or keys only with a jointly revised item-bank/protocol version before real collection, retaining prior versions. The current version has received technical answer-key/arithmetic inspection, not participant validation or independent psychometric review. Future piloting must evaluate comprehension, meaningful menu choices, timing, accessibility and assessment distributions before freezing a real study registration.
