# Execution Status

**Updated: 3 October 2026, client date.** The first version of the public-data analysis and working learning-dashboard prototype is complete. This document records execution separately from the frozen analysis configuration.

## Completed first version

- Acquired the official OULAD release, verified archive integrity and table checksums, and audited schemas, schedules, missingness, keys, and chronology.
- Prepared 20,441 eligible enrollments across 19 offerings, with 17,019 observed target marks. The reserved evaluation portion contains 3,399 observed enrollments from 3,197 learners; learner records do not overlap development and evaluation.
- Executed the four fixed models and six planned sensitivity comparisons. Primary click volume reduced held-out MAE from 11.621 to 11.302 mark points: **0.319 points, 95% interval 0.207–0.426**. Active-days and combined models are secondary comparisons against the reference.
- Exported aggregate results, missing-outcome diagnostics, learner-cluster uncertainty, source fingerprints, session records, PNG charts, and SVG vector companions.
- Independently reconstructed 32 model MAEs, including the additional offering check, with NumPy least squares. Differences from the R values were below `1e-8`; this verification does not independently reconstruct bootstrap intervals.
- Built the scoring-rule dashboard prototype. No participant experiment or efficacy evaluation has been completed.

The primary result measures additional predictive information for a later assessed mark. It does not identify an effect of dashboard design, activity, or points, and does not establish learning gain, transfer, or metric-seeking behavior. Missing target marks remain a selection limitation, not zero scores.

## Additional secondary check

Script 08 and its `latest-offering-*` outputs now exist. The check fits module-level models using represented earlier development offerings and evaluates reserved learners in the latest represented offering. Its broad purpose was anticipated, but **the exact implementation was fixed after primary-result inspection**. The execution record preserves that distinction. It is additional secondary work, with author/methods review pending; it neither replaces the primary comparison nor supplies a fresh reserved sample.

## Reproducibility and storage

The [README](../README.md) contains commands for acquisition, auditing, cohort preparation, verification, the main analysis (05), timing sensitivities (06), optional independent metric reconstruction (07), and the additional offering check (08).

The prepared timing configurations are `config/window28-sensitivity.json` and `config/cutoff70-sensitivity.json`. The longer-window configuration preserves primary assessment selection but requires the prior submission to precede the longer window. The day-70 configuration reapplies the selection rules and can change assessments. Comparisons retain their own populations; their error reductions are not a search for the best cutoff.

Raw tables, derived enrollment records, reserved outcome files, and fitted model objects remain outside the public project package. Model objects are saved in the local working-data `models/` folder. Public result and audit files contain aggregates; the prototype is separate from learner records.

The frozen configuration's `analysis_not_run: true` describes its pre-analysis state and remains unchanged. `results/run-record.csv`, timing records, and the additional-check record document executed work. Repeated execution uses the same reserved learners and is reproduction of the fixed comparison, not new validation or renewed protection against evaluation-driven tuning.

## CV line

**Independent research project — Digital Learning Metrics and Study Choices** Built a reproducible R/Python study of 20,441 course enrollments with learner-separated evaluation and sensitivity analyses, plus a learning-dashboard prototype for a future randomized study.

## Next scientific step

The psychology extension includes a sharper theoretical argument, original proposed study materials, a development instrument, and analysis checks with simulated records. See the [experimental package guide](Experiment-Package-Guide.md). These are reviewable development artifacts; no participant study, validated assessment, or external preregistration has been completed. The primary OULAD estimates and frozen configuration remain unchanged.

Before using this project in PhD applications, complete author review and methods comprehension: reproduce the central result, explain the enrollment-level estimand and learner-cluster uncertainty, distinguish prediction from intervention effects, and account for missing outcomes, course context, and the historical data. Seek a qualified methods review and revise the report where that review identifies a problem.

A future participant study needs participant access, instrument piloting, and an appropriate review route before collection. It would test the scoring-rule intervention using behavioral choices and an independent learning outcome. The present public-data analysis and prototype do not establish its efficacy.
