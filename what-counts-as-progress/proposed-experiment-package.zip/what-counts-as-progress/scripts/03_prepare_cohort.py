#!/usr/bin/env python3
"""Build the prespecified cohort and activity summaries without relationship analysis."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path

MISSING = {"", "?", "NA"}

def numeric(value):
    return None if value in MISSING else float(value)

def rows(path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        yield from csv.DictReader(handle)

def save_csv(path, values, columns=None):
    values = list(values)
    if columns is None:
        columns = list(values[0]) if values else []
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(values)

def keyed_unique(values, key):
    result = {}
    for value in values:
        identifier = key(value)
        if identifier in result:
            raise ValueError(f"Ambiguous duplicate key in small input table: {identifier}")
        result[identifier] = value
    return result

def partition(student, salt):
    digest = hashlib.sha256(f"{salt}:{student}".encode()).digest()
    return "evaluation" if int.from_bytes(digest[:8], "big") / 2**64 < 0.20 else "development"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--derived-dir", required=True, type=Path)
    parser.add_argument("--audit-dir", required=True, type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    start, cutoff = config["activity_start_day"], config["cutoff_day"]
    prior_schedule_cutoff = config.get("prior_schedule_cutoff_day", start)
    assert config["activity_end_day_exclusive"] == cutoff and cutoff > start
    for folder in [args.derived_dir, args.audit_dir]:
        folder.mkdir(parents=True, exist_ok=True)
    assessments = list(rows(args.raw_dir / "assessments.csv"))
    keyed_unique(assessments, lambda row: row["id_assessment"])
    registration = list(rows(args.raw_dir / "studentRegistration.csv"))
    keyed_unique(registration, lambda row: (row["code_module"], row["code_presentation"], row["id_student"]))
    submissions = keyed_unique(rows(args.raw_dir / "studentAssessment.csv"),
                               lambda row: (row["id_student"], row["id_assessment"]))
    schedules = defaultdict(list)
    for assessment in assessments:
        if assessment["assessment_type"] == "TMA" and numeric(assessment["date"]) is not None:
            schedules[(assessment["code_module"], assessment["code_presentation"])].append(assessment)
    pairs = {}
    for offering, schedule in schedules.items():
        earlier = [row for row in schedule if numeric(row["date"]) < prior_schedule_cutoff]
        later = [row for row in schedule if numeric(row["date"]) > cutoff
                 and numeric(row["weight"]) is not None and numeric(row["weight"]) > 0]
        if earlier and later:
            prior = min(earlier, key=lambda row: (-numeric(row["date"]), int(row["id_assessment"])))
            target = min(later, key=lambda row: (numeric(row["date"]), int(row["id_assessment"])))
            pairs[offering] = (prior, target)
    flow = Counter()
    cohort = {}
    exclusions = Counter()
    for registered in registration:
        flow["all_registration_records"] += 1
        offering = (registered["code_module"], registered["code_presentation"])
        if offering not in pairs:
            exclusions["unsupported_assessment_schedule"] += 1
            continue
        flow["supported_schedule"] += 1
        registration_day, withdrawal_day = numeric(registered["date_registration"]), numeric(registered["date_unregistration"])
        if registration_day is None:
            exclusions["missing_registration_date"] += 1; continue
        if registration_day >= cutoff:
            exclusions["not_registered_before_cutoff"] += 1; continue
        if withdrawal_day is not None and withdrawal_day < cutoff:
            exclusions["withdrawn_before_cutoff"] += 1; continue
        flow["registered_not_withdrawn_before_cutoff"] += 1
        prior, target = pairs[offering]
        before = submissions.get((registered["id_student"], prior["id_assessment"]))
        after = submissions.get((registered["id_student"], target["id_assessment"]))
        if before is None:
            exclusions["selected_prior_record_absent"] += 1; continue
        prior_day, prior_score = numeric(before["date_submitted"]), numeric(before["score"])
        if before["is_banked"] != "0":
            exclusions["selected_prior_banked_or_unknown_status"] += 1; continue
        if prior_day is None or prior_day >= start:
            exclusions["selected_prior_not_submitted_before_window"] += 1; continue
        if prior_score is None or not 0 <= prior_score <= 100:
            exclusions["selected_prior_missing_or_invalid_score"] += 1; continue
        flow["valid_prior_before_activity_window"] += 1
        if after is not None:
            if after["is_banked"] != "0":
                exclusions["target_banked_or_unknown_status"] += 1; continue
            target_day = numeric(after["date_submitted"])
            if target_day is None:
                exclusions["target_submission_date_unknown"] += 1; continue
            if target_day < cutoff:
                exclusions["target_already_submitted_before_cutoff"] += 1; continue
            target_score = numeric(after["score"])
            if target_score is not None and not 0 <= target_score <= 100:
                raise ValueError("Target score outside the documented range")
        else:
            target_day = target_score = None
        flow["eligible_cohort"] += 1
        flow["target_submission_observed"] += int(after is not None)
        flow["target_score_observed"] += int(target_score is not None)
        key = (*offering, registered["id_student"])
        cohort[key] = dict(
            code_module=offering[0], code_presentation=offering[1], id_student=registered["id_student"],
            course_offering="_".join(offering), prior_id=prior["id_assessment"],
            prior_deadline=numeric(prior["date"]), prior_weight=numeric(prior["weight"]),
            prior_submission_day=prior_day, prior_score=prior_score,
            target_id=target["id_assessment"], target_deadline=numeric(target["date"]),
            target_weight=numeric(target["weight"]), target_submission_day=target_day,
            target_submitted=int(after is not None), target_score_observed=int(target_score is not None),
            target_score=target_score, withdrawal_day=withdrawal_day,
            partition=partition(registered["id_student"], config["partition_salt"]),
        )
    if not cohort:
        raise ValueError("No eligible cohort under configured definitions")
    assert flow["all_registration_records"] == len(cohort) + sum(exclusions.values())
    totals = Counter()
    unique_totals = Counter()
    active_days = defaultdict(set)
    seen_full_rows = set()
    resource_day_values = defaultdict(set)
    resource_day_n = Counter()
    offering_record_counts = defaultdict(Counter)
    selected_activity_rows = 0
    all_activity_rows = 0
    print("Preparing activity records within the fixed window...", flush=True)
    for record in rows(args.raw_dir / "studentVle.csv"):
        all_activity_rows += 1
        day = numeric(record["date"])
        if day is None:
            raise ValueError("Unknown activity date prevents temporal allocation")
        if not start <= day < cutoff:
            continue
        key = (record["code_module"], record["code_presentation"], record["id_student"])
        if key not in cohort:
            continue
        clicks = numeric(record["sum_click"])
        if clicks is None or clicks < 0 or int(clicks) != clicks:
            raise ValueError("Invalid recorded interaction count")
        clicks, day = int(clicks), int(day)
        selected_activity_rows += 1
        totals[key] += clicks
        if clicks > 0:
            active_days[key].add(day)
        resource_day = (*key, record["id_site"], day)
        complete_row = (*resource_day, clicks)
        resource_day_n[resource_day] += 1
        resource_day_values[resource_day].add(clicks)
        offering_record_counts[key[:2]]["source_rows"] += 1
        if complete_row not in seen_full_rows:
            seen_full_rows.add(complete_row)
            unique_totals[key] += clicks
        else:
            offering_record_counts[key[:2]]["exact_repeated_rows_beyond_first"] += 1
    offering_counts = defaultdict(Counter)
    for key, record in cohort.items():
        record["total_clicks"] = totals[key]
        record["active_days"] = len(active_days[key])
        record["total_clicks_exact_row_unique_sensitivity"] = unique_totals[key]
        assert 0 <= record["active_days"] <= cutoff - start
        assert record["prior_submission_day"] < start
        assert record["target_submission_day"] is None or record["target_submission_day"] >= cutoff
        counter = offering_counts[key[:2]]
        counter["eligible"] += 1
        counter["observed_submission"] += record["target_submitted"]
        counter["observed_score"] += record["target_score_observed"]
        counter["no_recorded_window_activity"] += int(record["active_days"] == 0)
        counter[f"{record['partition']}_eligible"] += 1
        counter[f"{record['partition']}_observed_score"] += record["target_score_observed"]
    learner_partitions = defaultdict(set)
    for record in cohort.values():
        learner_partitions[record["id_student"]].add(record["partition"])
    assert all(len(values) == 1 for values in learner_partitions.values())
    # Keep evaluation marks separate from feature records to reduce accidental inspection.
    records = list(cohort.values())
    development = [record for record in records if record["partition"] == "development"]
    evaluation = [record for record in records if record["partition"] == "evaluation"]
    target_only = {"target_score", "target_submission_day", "target_submitted", "target_score_observed", "withdrawal_day"}
    evaluation_features = [{key: value for key, value in record.items() if key not in target_only} for record in evaluation]
    evaluation_outcomes = [{key: record[key] for key in ["code_module", "code_presentation", "id_student",
                             "target_score", "target_submission_day", "target_submitted", "target_score_observed", "withdrawal_day"]}
                           for record in evaluation]
    feature_keys = {(row["code_module"], row["code_presentation"], row["id_student"]) for row in evaluation_features}
    outcome_keys = {(row["code_module"], row["code_presentation"], row["id_student"]) for row in evaluation_outcomes}
    assert feature_keys == outcome_keys and len(feature_keys) == len(evaluation)
    assert {row["course_offering"] for row in evaluation}.issubset({row["course_offering"] for row in development})
    assert selected_activity_rows == len(seen_full_rows) + sum(
        count["exact_repeated_rows_beyond_first"] for count in offering_record_counts.values())
    save_csv(args.derived_dir / "development.csv", development)
    save_csv(args.derived_dir / "evaluation-features.csv", evaluation_features)
    save_csv(args.derived_dir / "evaluation-outcomes.csv", evaluation_outcomes)
    coverage = []
    for offering in sorted(offering_counts):
        prior, target = pairs[offering]
        coverage.append(dict(code_module=offering[0], code_presentation=offering[1],
                             prior_id=prior["id_assessment"], prior_deadline=numeric(prior["date"]),
                             target_id=target["id_assessment"], target_deadline=numeric(target["date"]),
                             **offering_counts[offering]))
    save_csv(args.audit_dir / "primary-offering-coverage.csv", coverage)
    save_csv(args.audit_dir / "primary-cohort-flow.csv",
             [dict(stage=stage, count=count) for stage, count in flow.items()])
    save_csv(args.audit_dir / "primary-exclusion-reasons.csv",
             [dict(reason=reason, count=count) for reason, count in exclusions.items()])
    save_csv(args.audit_dir / "primary-activity-record-structure.csv",
             [dict(code_module=offering[0], code_presentation=offering[1], **offering_record_counts[offering])
              for offering in sorted(offering_record_counts)])
    missing_targets = flow["eligible_cohort"] - flow["target_score_observed"]
    checks = dict(
        config_sha256=hashlib.sha256(args.config.read_bytes()).hexdigest(),
        all_activity_rows_scanned=all_activity_rows,
        cohort_records=len(cohort), unique_learners=len(learner_partitions),
        supported_modules=len({key[0] for key in cohort}), supported_offerings=len(offering_counts),
        observed_target_marks=flow["target_score_observed"], missing_target_marks=missing_targets,
        development_eligible=len(development), evaluation_eligible=len(evaluation),
        development_observed_marks=sum(record["target_score_observed"] for record in development),
        evaluation_observed_marks=sum(record["target_score_observed"] for record in evaluation),
        learner_overlap_between_partitions=0,
        prior_temporal_violations=0, target_temporal_violations=0, activity_temporal_violations=0,
        eligible_window_source_rows=selected_activity_rows,
        eligible_window_unique_complete_rows=len(seen_full_rows),
        eligible_window_exact_repeated_rows_beyond_first=selected_activity_rows-len(seen_full_rows),
        eligible_window_repeated_resource_day_keys=sum(count > 1 for count in resource_day_n.values()),
        eligible_window_resource_day_keys_with_differing_counts=sum(len(values) > 1 for values in resource_day_values.values()),
        duplicate_interpretation="Global counts within the eligible window only. Repeated keys or full rows are not proved erroneous; all official rows retained for primary activity volume.",
        no_associations_estimated=True, no_models_fit=True, evaluation_outcome_values_not_summarized=True,
    )
    (args.audit_dir / "preparation-checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    print(json.dumps({key: checks[key] for key in ["cohort_records", "unique_learners", "supported_modules",
                       "supported_offerings", "observed_target_marks", "missing_target_marks",
                       "development_observed_marks", "evaluation_observed_marks",
                       "eligible_window_exact_repeated_rows_beyond_first"]}, indent=2), flush=True)
    print("Derived records prepared; no activity-mark associations or models computed.", flush=True)

if __name__ == "__main__":
    main()
