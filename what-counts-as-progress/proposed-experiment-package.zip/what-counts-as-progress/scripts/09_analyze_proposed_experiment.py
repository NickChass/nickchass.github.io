#!/usr/bin/env python3
"""Analysis readiness for a proposed experiment, using labeled technical records.

No participant data are collected by this package. Current inputs must be
synthetic or local development demonstrations. This script's estimates verify
software and illustrate precision assumptions; they are not study findings.
Uses Python's standard library only.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

BASE = Path(__file__).resolve().parents[1]
ARMS = ('all_correct', 'distinct_item')
Z = 1.959963984540054
EVENTS = {'session_started', 'demo_acknowledged', 'baseline_response', 'baseline_completed',
          'lesson_viewed', 'warmup_response', 'warmup_completed', 'condition_assigned',
          'rule_comprehension_response', 'practice_started', 'practice_menu_choice',
          'practice_response', 'explanation_viewed', 'development_clock_advanced',
          'practice_window_completed', 'transfer_response', 'transfer_completed',
          'motivation_response', 'session_completed', 'session_withdrawn',
          'development_export_requested'}

class InvalidRecord(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise InvalidRecord(message)

def config_load(path):
    config = json.loads(path.read_text())
    require(config['participant_collection_enabled'] is False,
            'This development analyzer has no enabled participant-data mode.')
    return config

def item_lookup(config):
    return {item['id']: item for group in ('pretest_items', 'practice_items', 'transfer_items') for item in config[group]}

def is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)

def reconstruct(record, config):
    """Recompute outcomes and points from events; never trust exported scores."""
    lookup = item_lookup(config)
    require(isinstance(record, dict), 'Session must be an object.')
    for name in ('study_id', 'protocol_version', 'item_bank_version', 'schema_version'):
        require(record.get(name) == config[name], f'Unknown {name}.')
    require(record.get('session_kind') in config['allowed_current_session_kinds'],
            'Participant records are disabled; only synthetic/development_demo records are accepted.')
    require(record.get('participant_collection_enabled') is False, 'Collection gate must be disabled.')
    require(record.get('status') in ('completed', 'incomplete', 'withdrawn'), 'Unknown run status.')
    events = record.get('events')
    require(isinstance(events, list) and len(events) > 0, 'Missing event history.')
    require(isinstance(record.get('state_snapshot'), dict), 'Missing full-state snapshot.')
    baseline, transfer, motivation = {}, {}, {}
    successful, encountered, attempted = set(), set(), set()
    points = 0
    assigned = None
    practice_start = None
    window_complete = False
    first_choice = None
    active_item = None
    active_answered = False
    warmup_complete = False
    comprehension = None
    withdrawals = 0
    practice_selections = repeat_selections = reviews = 0
    previous_elapsed = -1
    lesson_seen = False
    baseline_completed = False
    transfer_completed = False
    session_completed = False
    time_advance_used = False
    acknowledged = False
    option_ids = {key: {option['id'] for option in item['options']} for key, item in lookup.items()}

    def response(payload, group):
        item_id = payload.get('item_id')
        require(item_id in {item['id'] for item in config[group]}, f'Wrong item group: {item_id}.')
        option = payload.get('response_option')
        require(option in option_ids[item_id], f'Unknown response option for {item_id}.')
        correct = option == lookup[item_id]['correct_option']
        require(isinstance(payload.get('correct'), bool) and payload['correct'] == correct,
                f'Incorrect answer-key label for {item_id}.')
        return item_id, correct

    for index, event in enumerate(events, 1):
        require(isinstance(event, dict) and event.get('sequence') == index, 'Event sequence is not consecutive.')
        elapsed = event.get('elapsed_ms')
        require(is_number(elapsed) and elapsed >= previous_elapsed and elapsed >= 0, 'Elapsed times must be finite and monotonic.')
        previous_elapsed = elapsed
        kind, payload = event.get('type'), event.get('payload')
        require(kind in EVENTS and isinstance(payload, dict), 'Unknown event type or missing payload.')
        require(not session_completed or kind == 'development_export_requested', 'Unexpected action after session completion.')
        require(not withdrawals or kind == 'development_export_requested', 'Unexpected action after withdrawal.')
        if index == 1:
            require(kind == 'session_started' and payload.get('session_kind') == record['session_kind'], 'Missing first session-start marker.')
        elif kind == 'session_started':
            require(False, 'Duplicate session-start marker.')
        if kind == 'demo_acknowledged':
            require(not acknowledged and not baseline and payload.get('research_consent') is False,
                    'Development acknowledgment must precede responses and is not research consent.')
            acknowledged = True
        elif kind == 'baseline_response':
            require(acknowledged, 'Baseline requires development acknowledgment.')
            require(assigned is None and not baseline_completed, 'Baseline response after assignment/completion.')
            item_id, correct = response(payload, 'pretest_items')
            require(item_id not in baseline, 'Duplicate baseline response.')
            baseline[item_id] = int(correct)
        elif kind == 'baseline_completed':
            require(len(baseline) == 4 and assigned is None and not baseline_completed, 'Baseline must be complete before allocation.')
            require(payload.get('score') == sum(baseline.values()) and payload.get('answered') == 4, 'Baseline total is inconsistent.')
            baseline_completed = True
        elif kind == 'lesson_viewed':
            require(baseline_completed and assigned is None, 'Lesson must follow baseline before allocation.')
            lesson_seen = True
        elif kind == 'warmup_response':
            require(assigned is None and lesson_seen and not warmup_complete, 'Warmup must precede allocation.')
            item_id, correct = response(payload, 'practice_items')
            require(item_id == 'P1', 'Warmup must use exact P1.')
            if correct:
                successful.add('P1'); encountered.add('P1'); attempted.add('P1')
        elif kind == 'warmup_completed':
            require('P1' in successful and assigned is None and not warmup_complete, 'Warmup completion lacks a correct preallocation P1.')
            warmup_complete = True
        elif kind == 'condition_assigned':
            require(assigned is None and warmup_complete and baseline_completed, 'Allocation is duplicated or precedes the common warmup.')
            assigned = payload.get('arm')
            require(assigned in ARMS and record.get('arm') == assigned, 'Assigned arm mismatch.')
            require(payload.get('initial_points') == 1 and payload.get('eligible_correct_repeat_item_id') == 'P1', 'Shared initial point/repeat is inconsistent.')
            require(record.get('assignment_method') == payload.get('assignment_method'), 'Allocation method mismatch.')
            method = payload.get('assignment_method')
            require(method in ('cryptographic_random_bit_development', 'seeded_equal_probability_development', 'independent_equal_probability', 'development_override', 'synthetic_fixture_fixed'), 'Unknown allocation method.')
            if method == 'cryptographic_random_bit_development':
                raw = payload.get('assignment_draw_raw')
                require(isinstance(raw, int) and not isinstance(raw, bool) and 0 <= raw < 2**32, 'Invalid raw cryptographic draw.')
                require(payload.get('assignment_draw') == raw / 2**32, 'Normalized draw mismatch.')
                require(assigned == ARMS[int(raw >= 2**31)], 'Arm does not match the recorded cryptographic bit.')
            points = 1
        elif kind == 'rule_comprehension_response':
            require(assigned is not None and practice_start is None, 'Rule question outside assigned prepractice stage.')
            expected = int(assigned == 'all_correct')
            value = payload.get('response_points')
            require(value in (0, 1) and payload.get('expected_points') == expected,
                    'Comprehension expected points disagree with the arm.')
            require(payload.get('correct') == (value == expected) and payload.get('exclusion') is False,
                    'Comprehension label/exclusion is inconsistent.')
            option = payload.get('response_option')
            if option is not None:
                require(option in ('A', 'B') and value == int(option == 'A'), 'Rule option and point response disagree.')
            comprehension = int(value == expected)
        elif kind == 'practice_started':
            require(assigned is not None and practice_start is None and comprehension is not None, 'Practice lacks fixed assignment/rule check.')
            require(payload.get('duration_ms') == config['practice_window_ms'] and payload.get('initial_points') == 1 and payload.get('successful_item_ids') == ['P1'], 'Practice-start contract mismatch.')
            practice_start = elapsed
        elif kind in ('practice_menu_choice', 'practice_response', 'explanation_viewed'):
            require(practice_start is not None and not window_complete and elapsed - practice_start < config['practice_window_ms'], 'Practice action outside the fixed window.')
            item_id = payload.get('item_id')
            require(item_id in {item['id'] for item in config['practice_items']}, 'Unknown practice item.')
            if kind == 'practice_menu_choice':
                category = payload.get('choice')
                require(category in ('repeat', 'new', 'review', 'retry'), 'Unknown practice selection.')
                require(payload.get('previously_correct') == (item_id in successful) and payload.get('previously_encountered') == (item_id in encountered), 'Selection eligibility flags disagree with history.')
                if first_choice is None:
                    require(category in ('repeat', 'new', 'review') and item_id == config['initial_menu'][category], 'First-menu content is not the shared contract.')
                    first_choice = category
                if category == 'repeat':
                    require(item_id in successful, 'Repeat was not previously correct.')
                    repeat_selections += 1
                elif category == 'retry':
                    require(item_id in attempted and item_id not in successful, 'Retry was not a previously incorrect attempt.')
                elif category == 'new':
                    unseen = [item['id'] for item in config['practice_items'] if item['id'] not in encountered]
                    require(unseen and item_id == unseen[0], 'New-item order changed or item was already encountered.')
                else:
                    require(item_id in encountered, 'Review was not an encountered explanation.')
                    reviews += 1
                if category != 'review':
                    practice_selections += 1
                encountered.add(item_id)
                active_item = None if category == 'review' else item_id
                active_answered = False
            elif kind == 'practice_response':
                require(active_item == item_id and not active_answered, 'Response lacks a fresh matching voluntary selection.')
                _, correct = response(payload, 'practice_items')
                previously_correct = item_id in successful
                award = int(correct and (assigned == 'all_correct' or not previously_correct))
                points += award
                require(payload.get('previously_correct') == previously_correct and payload.get('points_awarded') == award and payload.get('total_points_after') == points, 'Point rule/counter mismatch.')
                attempted.add(item_id)
                if correct:
                    successful.add(item_id)
                active_answered = True
            else:
                require(payload.get('points_awarded') == 0 and item_id in encountered, 'Explanation view changes points or lacks a known item.')
        elif kind == 'development_clock_advanced':
            require(record['session_kind'] == 'development_demo' and practice_start is not None and not window_complete, 'Clock shortcut is development-only.')
            require(is_number(payload.get('added_ms')) and payload['added_ms'] >= 0, 'Invalid development advance.')
            time_advance_used = True
        elif kind == 'practice_window_completed':
            require(practice_start is not None and not window_complete and elapsed - practice_start >= config['practice_window_ms'], 'No-choice confirmation requires the full window.')
            require(payload.get('duration_ms') == config['practice_window_ms'] and payload.get('final_points') == points, 'Practice completion duration/points mismatch.')
            require(payload.get('first_choice_category') == (first_choice or 'none'), 'Completed-window first category mismatch.')
            window_complete = True
        elif kind == 'transfer_response':
            require(window_complete and not transfer_completed, 'Transfer must follow practice and precede transfer completion.')
            item_id, correct = response(payload, 'transfer_items')
            require(item_id not in transfer and payload.get('points_awarded') == 0, 'Transfer answer is duplicated or changes practice points.')
            transfer[item_id] = int(correct)
        elif kind == 'transfer_completed':
            require(window_complete and not transfer_completed, 'Duplicate/out-of-order transfer completion.')
            score = sum(transfer.values()) if len(transfer) == 6 else None
            require(payload.get('answered') == len(transfer) and payload.get('score') == score and payload.get('complete') == (len(transfer) == 6), 'Incomplete transfer was zero-filled or total is inconsistent.')
            transfer_completed = True
        elif kind == 'motivation_response':
            require(transfer_completed, 'Reflection precedes transfer.')
            item_id, value = payload.get('item_id'), payload.get('value')
            require(item_id in {item['id'] for item in config['motivation_items']} and item_id not in motivation, 'Unknown/duplicate reflection item.')
            require(value is None or isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= 7, 'Reflection must be 1–7 or missing.')
            require(payload.get('validated_scale') is False, 'Custom reflection item mislabeled validated.')
            motivation[item_id] = value
        elif kind == 'session_completed':
            require(transfer_completed and record['status'] == 'completed', 'Session completion lacks transfer-stage closure.')
            session_completed = True
        elif kind == 'session_withdrawn':
            require(record['status'] == 'withdrawn' and payload.get('analytic_use') is False, 'Withdrawal status/use mismatch.')
            withdrawals += 1
        elif kind == 'development_export_requested':
            require(payload.get('opt_in') is True and payload.get('no_remote_upload') is True, 'Export must be local and opt-in.')

    require((record['status'] == 'withdrawn') == bool(withdrawals), 'Withdrawal marker/status mismatch.')
    require((record['status'] == 'completed') == session_completed, 'Completed status/marker mismatch.')
    require(record.get('arm') == assigned, 'Envelope arm disagrees with event allocation.')
    snapshot = record['state_snapshot']
    require(snapshot.get('arm') == assigned and snapshot.get('points') == points and snapshot.get('status') == record['status'], 'Snapshot arm/points/status mismatch.')
    require(snapshot.get('first_choice_category') == (first_choice or 'none') and snapshot.get('practice_window_completed') == window_complete, 'Snapshot practice outcome mismatch.')
    require(snapshot.get('baseline_score') == (sum(baseline.values()) if baseline_completed else None), 'Snapshot baseline total mismatch.')
    require(set(snapshot.get('successful_item_ids', [])) == successful, 'Snapshot successful-item history mismatch.')
    withdrawn = bool(withdrawals)
    observed_no_choice = window_complete and not time_advance_used
    primary = None if assigned is None or withdrawn else (int(first_choice == 'repeat') if first_choice else (0 if observed_no_choice else None))
    category = 'withdrawn' if withdrawn else (first_choice or ('none' if observed_no_choice else 'unavailable'))
    return {
        'session_label': record.get('session_label', ''), 'session_kind': record['session_kind'],
        'valid': True, 'invalid_reason': '', 'arm': assigned, 'status': record['status'],
        'primary_repeat': primary, 'first_choice_category': category,
        'primary_missing_reason': 'withdrawn' if withdrawn else ('not_assigned' if assigned is None else ('unobserved_window_without_choice' if primary is None else '')),
        'baseline_total': None if withdrawn or not baseline_completed else sum(baseline.values()),
        'transfer_total': None if withdrawn or len(transfer) != 6 else sum(transfer.values()),
        'transfer_answered': None if withdrawn else len(transfer),
        'transfer_missing_reason': 'withdrawn' if withdrawn else ('incomplete_transfer' if len(transfer) != 6 else ''),
        'rule_comprehension_correct': None if withdrawn else comprehension,
        'practice_question_selections': None if withdrawn else practice_selections,
        'successful_repeat_selections': None if withdrawn else repeat_selections,
        'repeat_selection_proportion': None if withdrawn or practice_selections == 0 else repeat_selections / practice_selections,
        'explanation_selections': None if withdrawn else reviews,
        'final_practice_points': None if withdrawn or assigned is None else points,
        'full_practice_window': observed_no_choice, 'development_time_advance_used': time_advance_used,
        **{item['id']: None if withdrawn else motivation.get(item['id']) for item in config['motivation_items']}
    }

def safe_reconstruct(record, config):
    try:
        return reconstruct(record, config)
    except (InvalidRecord, KeyError, TypeError, ValueError) as error:
        # Preserve an assigned arm only if envelope and one allocation marker agree.
        event_list = record.get('events', []) if isinstance(record, dict) else []
        assignments = [event['payload'].get('arm') for event in event_list
                       if isinstance(event, dict) and event.get('type') == 'condition_assigned' and isinstance(event.get('payload'), dict)] if isinstance(event_list, list) else []
        known_arm = assignments[0] if len(assignments) == 1 and assignments[0] in ARMS and record.get('arm') == assignments[0] else None
        return {'session_label': record.get('session_label', '') if isinstance(record, dict) else '',
                'session_kind': record.get('session_kind', 'unknown') if isinstance(record, dict) else 'unknown',
                'valid': False, 'invalid_reason': str(error), 'arm': known_arm,
                'status': 'invalid', 'primary_repeat': None, 'first_choice_category': 'invalid',
                'primary_missing_reason': 'invalid_export', 'baseline_total': None,
                'transfer_total': None, 'transfer_answered': None, 'transfer_missing_reason': 'invalid_export'}

def wilson(successes, total):
    if total <= 0:
        return None
    proportion = successes / total
    denominator = 1 + Z**2 / total
    center = (proportion + Z**2 / (2 * total)) / denominator
    radius = Z * math.sqrt(proportion * (1 - proportion) / total + Z**2 / (4 * total**2)) / denominator
    return center - radius, center + radius

def newcombe(s1, n1, s0, n0):
    if n1 <= 0 or n0 <= 0:
        return None
    p1, p0 = s1 / n1, s0 / n0
    l1, u1 = wilson(s1, n1); l0, u0 = wilson(s0, n0)
    difference = p1 - p0
    return difference, max(-1, difference - math.sqrt((p1 - l1)**2 + (u0 - p0)**2)), min(1, difference + math.sqrt((u1 - p1)**2 + (p0 - l0)**2))

def invert(matrix):
    n = len(matrix)
    augmented = [list(row) + [int(i == j) for j in range(n)] for i, row in enumerate(matrix)]
    for column in range(n):
        pivot = max(range(column, n), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) < 1e-11:
            raise ValueError('Rank-deficient adjusted transfer model.')
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        divisor = augmented[column][column]
        augmented[column] = [value / divisor for value in augmented[column]]
        for row in range(n):
            if row != column:
                multiplier = augmented[row][column]
                augmented[row] = [a - multiplier * b for a, b in zip(augmented[row], augmented[column])]
    return [row[n:] for row in augmented]

def matmul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]

def adjusted_transfer(rows):
    observed = [row for row in rows if row.get('arm') in ARMS and row.get('baseline_total') is not None and row.get('transfer_total') is not None and row.get('valid')]
    if len(observed) <= 3 or {row['arm'] for row in observed} != set(ARMS):
        return {'status': 'not_estimable', 'reason': 'Need complete outcomes in both assigned arms and more than three sessions.', 'n_complete': len(observed)}
    x = [[1., float(row['arm'] == 'all_correct'), float(row['baseline_total'])] for row in observed]
    y = [float(row['transfer_total']) for row in observed]
    xtx = [[sum(row[i] * row[j] for row in x) for j in range(3)] for i in range(3)]
    try:
        inverse = invert(xtx)
    except ValueError as error:
        return {'status': 'not_estimable', 'reason': str(error), 'n_complete': len(observed)}
    xty = [sum(row[j] * value for row, value in zip(x, y)) for j in range(3)]
    coefficients = [sum(inverse[i][j] * xty[j] for j in range(3)) for i in range(3)]
    meat = [[0. for _ in range(3)] for _ in range(3)]
    predictions = []
    for row, value in zip(x, y):
        prediction = sum(a * b for a, b in zip(row, coefficients)); predictions.append(prediction)
        residual = value - prediction
        leverage = sum(row[i] * inverse[i][j] * row[j] for i in range(3) for j in range(3))
        if leverage >= 1 - 1e-12:
            return {'status': 'not_estimable', 'reason': 'HC2 is undefined at leverage one.', 'n_complete': len(observed)}
        weight = residual**2 / (1 - leverage)
        for i in range(3):
            for j in range(3):
                meat[i][j] += weight * row[i] * row[j]
    covariance = matmul(matmul(inverse, meat), inverse)
    se = math.sqrt(max(0, covariance[1][1]))
    return {'status': 'estimated', 'n_complete': len(observed),
            'formula': 'transfer_total ~ intercept + I(arm == all_correct) + baseline_total',
            'arm_difference_points': coefficients[1], 'hc2_standard_error': se,
            'ci_low': coefficients[1] - Z * se, 'ci_high': coefficients[1] + Z * se,
            'baseline_coefficient': coefficients[2], 'intercept': coefficients[0],
            'unit': 'transfer correct-item points, 0–6', 'uncertainty': 'HC2 heteroskedasticity-robust, normal 95% approximation',
            'predictions_outside_0_6': sum(value < 0 or value > 6 for value in predictions),
            'scope': 'Complete transfer and baseline outcomes only; missingness is not assumed ignorable; not learning gain.'}

def summarize(rows, config):
    arms = {}
    categories = []
    for arm in ARMS:
        group = [row for row in rows if row.get('arm') == arm]
        observed = [row for row in group if row.get('primary_repeat') is not None]
        transfer = [row['transfer_total'] for row in group if row.get('transfer_total') is not None]
        successes = sum(row['primary_repeat'] for row in observed)
        arms[arm] = {'known_assigned_sessions': len(group), 'valid_sessions': sum(bool(row['valid']) for row in group),
                     'withdrawn_sessions': sum(row['status'] == 'withdrawn' for row in group),
                     'invalid_exports': sum(not row['valid'] for row in group),
                     'primary_observed': len(observed), 'primary_missing': len(group) - len(observed),
                     'repeat_first': successes, 'repeat_risk_available': successes / len(observed) if observed else None,
                     'transfer_complete': len(transfer), 'transfer_missing': len(group) - len(transfer),
                     'transfer_mean_available': statistics.mean(transfer) if transfer else None}
        for category in ('repeat', 'new', 'review', 'none', 'unavailable', 'withdrawn', 'invalid'):
            categories.append({'arm': arm, 'first_choice_category': category, 'n_sessions': sum(row.get('first_choice_category') == category for row in group)})
    a1, a0 = arms['all_correct'], arms['distinct_item']
    interval = newcombe(a1['repeat_first'], a1['primary_observed'], a0['repeat_first'], a0['primary_observed'])
    primary = {'estimand': 'Probability difference all_correct minus distinct_item; participant/session is the unit',
               'estimator_scope': 'available-outcome estimate' if a1['primary_missing'] or a0['primary_missing'] else 'all known assigned sessions have observed primary outcomes',
               'status': 'estimated' if interval else 'not_estimable', 'risk_difference': interval[0] if interval else None,
               'ci_low': interval[1] if interval else None, 'ci_high': interval[2] if interval else None,
               'uncertainty': 'Newcombe-Wilson 95% interval; no continuity correction; no event-level pseudo-replication',
               'unassigned_or_unknown_arm': sum(row.get('arm') not in ARMS for row in rows)}
    if a1['known_assigned_sessions'] and a0['known_assigned_sessions']:
        n1, n0 = a1['known_assigned_sessions'], a0['known_assigned_sessions']
        primary['worst_case_all_assigned_low'] = a1['repeat_first'] / n1 - (a0['repeat_first'] + a0['primary_missing']) / n0
        primary['worst_case_all_assigned_high'] = (a1['repeat_first'] + a1['primary_missing']) / n1 - a0['repeat_first'] / n0
    bounded = {}
    for arm in ARMS:
        group = [row for row in rows if row.get('arm') == arm]
        total = sum(row['transfer_total'] for row in group if row.get('transfer_total') is not None)
        missing = sum(row.get('transfer_total') is None for row in group)
        bounded[arm] = (total / len(group), (total + 6 * missing) / len(group)) if group else None
    transfer_bounds = {'scope': 'Unadjusted mean-difference bounds using 0–6 for unavailable scores; these do not bound the adjusted coefficient.'}
    if all(bounded.values()):
        transfer_bounds.update(low=bounded['all_correct'][0] - bounded['distinct_item'][1], high=bounded['all_correct'][1] - bounded['distinct_item'][0])
    reflection = []
    for item in config['motivation_items']:
        for arm in ARMS:
            values = [row[item['id']] for row in rows if row.get('arm') == arm and row.get(item['id']) is not None]
            reflection.append({'arm': arm, 'item_id': item['id'], 'n_available': len(values), 'mean': statistics.mean(values) if values else None,
                               'interpretation': 'Individual custom unvalidated item; descriptive only; no combined scale or mediation'})
    return {'notice': 'TECHNICAL ANALYSIS ONLY. Synthetic/development records are not participant observations or empirical findings.',
            'arms': arms, 'primary': primary, 'adjusted_transfer': adjusted_transfer(rows), 'unadjusted_transfer_missingness_bounds': transfer_bounds,
            'reflection_items': reflection, 'first_choice_categories': categories,
            'input_session_kinds': sorted({row.get('session_kind', 'unknown') for row in rows}),
            'n_records': len(rows), 'n_valid': sum(row['valid'] for row in rows), 'n_invalid': sum(not row['valid'] for row in rows)}

def write_csv(path, rows):
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, lineterminator='\n'); writer.writeheader(); writer.writerows(rows)

def analyze(records, config, output):
    # Fail closed on participant inputs; they cannot be sneaked in as invalid synthetic rows.
    for record in records:
        require(isinstance(record, dict) and record.get('session_kind') in ('synthetic', 'development_demo'), 'Current package accepts no participant records.')
    labels = [record.get('session_label') for record in records]
    require(all(isinstance(label, str) and label for label in labels) and len(set(labels)) == len(labels), 'Session labels must be present and unique; duplicate exports are not independent people.')
    rows = [safe_reconstruct(record, config) for record in records]
    summary = summarize(rows, config)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / 'session-outcomes.csv', rows)
    write_csv(output / 'arm-availability.csv', [{'arm': arm, **value} for arm, value in summary['arms'].items()])
    write_csv(output / 'first-choice-categories.csv', summary['first_choice_categories'])
    write_csv(output / 'reflection-items.csv', summary['reflection_items'])
    (output / 'analysis-readiness-summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
    return rows, summary

def generate_synthetic(config, count, seed):
    """Seeded artificial traces exercise software; injected patterns are assumptions."""
    require(count >= 20 and count % 2 == 0, 'Use an even synthetic count of at least twenty.')
    rng = random.Random(seed); lookup = item_lookup(config)
    arms = ['all_correct'] * (count // 2) + ['distinct_item'] * (count // 2); rng.shuffle(arms)
    records = []
    for number, arm in enumerate(arms):
        elapsed = 0; events = []; successful = set(); encountered = set(); attempted = set(); points = 0
        baseline_responses = {}; transfer_responses = {}; baseline_score = 0; first = None
        def emit(kind, payload=None, increment=1000):
            nonlocal elapsed
            elapsed += increment
            events.append({'sequence': len(events) + 1, 'type': kind, 'elapsed_ms': elapsed, 'payload': payload or {}})
        emit('session_started', {'session_kind': 'synthetic', 'participant_mode_enabled': False}, 0)
        emit('demo_acknowledged', {'research_consent': False})
        for item in config['pretest_items']:
            response = item['correct_option'] if rng.random() < .60 else next(option['id'] for option in item['options'] if option['id'] != item['correct_option'])
            correct = response == item['correct_option']; baseline_score += int(correct); baseline_responses[item['id']] = response
            emit('baseline_response', {'item_id': item['id'], 'response_option': response, 'correct': correct})
        emit('baseline_completed', {'answered': 4, 'score': baseline_score, 'possible': 4})
        emit('lesson_viewed', {'lesson_version': config['protocol_version']})
        if number % 7 == 0:
            wrong = next(option['id'] for option in lookup['P1']['options'] if option['id'] != lookup['P1']['correct_option'])
            emit('warmup_response', {'item_id': 'P1', 'response_option': wrong, 'correct': False})
        emit('warmup_response', {'item_id': 'P1', 'response_option': lookup['P1']['correct_option'], 'correct': True})
        successful.add('P1'); encountered.add('P1'); attempted.add('P1')
        emit('warmup_completed', {'item_id': 'P1', 'correct': True})
        emit('condition_assigned', {'arm': arm, 'assignment_method': 'synthetic_fixture_fixed', 'assignment_seed': seed + number,
                                   'assignment_draw_raw': None, 'assignment_draw': None, 'initial_points': 1, 'eligible_correct_repeat_item_id': 'P1'})
        points = 1
        expected = int(arm == 'all_correct'); rule_answer = 1 - expected if number % 9 == 0 else expected
        emit('rule_comprehension_response', {'response_option': 'A' if rule_answer else 'B', 'response_points': rule_answer,
                                             'expected_points': expected, 'correct': rule_answer == expected, 'exclusion': False})
        emit('practice_started', {'duration_ms': config['practice_window_ms'], 'initial_points': 1, 'successful_item_ids': ['P1']})
        practice_start = elapsed
        no_choice = number % 13 == 0
        withdrawn = number % 19 == 0
        early_no_choice = number % 23 == 0 and not no_choice and not withdrawn
        later_incomplete = number % 29 == 0 and not withdrawn and not early_no_choice
        missing_transfer = number % 11 == 0

        def choose(category, item_id):
            nonlocal first
            emit('practice_menu_choice', {'choice': category, 'item_id': item_id, 'previously_correct': item_id in successful, 'previously_encountered': item_id in encountered}, 8000)
            if first is None: first = category
            encountered.add(item_id)
            if category == 'review': emit('explanation_viewed', {'item_id': item_id, 'points_awarded': 0})
        def answer(item_id, correct):
            nonlocal points
            response = lookup[item_id]['correct_option'] if correct else next(option['id'] for option in lookup[item_id]['options'] if option['id'] != lookup[item_id]['correct_option'])
            was_correct = item_id in successful
            award = int(correct and (arm == 'all_correct' or not was_correct)); points += award
            emit('practice_response', {'item_id': item_id, 'response_option': response, 'correct': correct, 'previously_correct': was_correct, 'points_awarded': award, 'total_points_after': points})
            attempted.add(item_id)
            if correct: successful.add(item_id)
        if not no_choice and not early_no_choice:
            repeat_probability = .55 if arm == 'all_correct' else .40
            draw = rng.random()
            first_category = 'repeat' if draw < repeat_probability else ('new' if draw < repeat_probability + .30 else 'review')
            choose(first_category, 'P2' if first_category == 'new' else 'P1')
            if first_category != 'review': answer('P2' if first_category == 'new' else 'P1', True)
            choose('repeat', 'P1'); answer('P1', True)
            if 'P2' not in encountered:
                choose('new', 'P2'); answer('P2', False)
                choose('retry', 'P2'); answer('P2', True)
            choose('review', 'P1')
        status = 'incomplete'; stage = 'practice'; full_window = False; transfer_score = None; motivation = {}
        if withdrawn:
            emit('session_withdrawn', {'stage_at_stop': 'practice', 'analytic_use': False}); status = 'withdrawn'; stage = 'withdrawn'
        elif early_no_choice or later_incomplete:
            elapsed = max(elapsed, practice_start + 100000)
        else:
            elapsed = practice_start + config['practice_window_ms']
            emit('practice_window_completed', {'duration_ms': config['practice_window_ms'], 'observed_elapsed_ms': config['practice_window_ms'],
                                               'reason': 'elapsed_window', 'first_choice_category': first or 'none', 'final_points': points}, 0)
            full_window = True
            for item in config['transfer_items'][:3 if missing_transfer else 6]:
                probability = min(.95, max(.15, .30 + .10 * baseline_score + (.02 if arm == 'all_correct' else 0)))
                correct = rng.random() < probability
                response = item['correct_option'] if correct else next(option['id'] for option in item['options'] if option['id'] != item['correct_option'])
                transfer_responses[item['id']] = response
                emit('transfer_response', {'item_id': item['id'], 'response_option': response, 'correct': correct, 'points_awarded': 0})
            transfer_score = sum(transfer_responses.get(item['id']) == item['correct_option'] for item in config['transfer_items']) if len(transfer_responses) == 6 else None
            emit('transfer_completed', {'answered': len(transfer_responses), 'possible': 6, 'score': transfer_score, 'complete': len(transfer_responses) == 6, 'missing_not_zero': len(transfer_responses) != 6})
            for item in config['motivation_items']:
                value = None if number % 17 == 0 else rng.randint(1, 7); motivation[item['id']] = value
                emit('motivation_response', {'item_id': item['id'], 'value': value, 'validated_scale': False})
            emit('session_completed', {'transfer_complete': transfer_score is not None}); status = 'completed'; stage = 'complete'
        emit('development_export_requested', {'opt_in': True, 'no_remote_upload': True}, 0)
        snapshot = {'stage': stage, 'status': status, 'elapsed_ms': elapsed, 'arm': arm, 'assignment_method': 'synthetic_fixture_fixed',
                    'assignment_seed': seed + number, 'assignment_draw_raw': None, 'assignment_draw': None,
                    'points': points, 'successful_item_ids': sorted(successful), 'encountered_item_ids': sorted(encountered), 'attempted_item_ids': sorted(attempted),
                    'baseline_score': baseline_score, 'baseline_responses': baseline_responses, 'warmup_correct': True, 'rule_checked': True,
                    'practice_elapsed_ms': min(config['practice_window_ms'], elapsed - practice_start), 'practice_started_at_ms': practice_start,
                    'practice_window_completed': full_window, 'first_choice_category': first or 'none', 'active_item_id': None,
                    'active_answered': False, 'transfer_responses': transfer_responses, 'transfer_score': transfer_score,
                    'motivation_responses': motivation, 'development_time_advance_used': False}
        records.append({'study_id': config['study_id'], 'protocol_version': config['protocol_version'], 'item_bank_version': config['item_bank_version'],
                        'schema_version': config['schema_version'], 'session_kind': 'synthetic', 'session_label': f'synthetic-{number+1:04d}',
                        'participant_collection_enabled': False, 'arm': arm, 'assignment_method': 'synthetic_fixture_fixed',
                        'assignment_seed': seed + number, 'assignment_draw_raw': None, 'status': status, 'events': events, 'state_snapshot': snapshot,
                        'notice': 'Seeded synthetic software-test record. Injected choice/score patterns are generation assumptions, not participant findings.'})
    return records

def precision_simulation(output, seed, replicates=2000):
    rows = []
    for total in (100, 200, 400):
        for retention in (1., .9, .8):
            rng = random.Random(seed + total + int(1000 * retention))
            widths, coverage, observed_counts = [], [], []
            for _ in range(replicates):
                outcomes = [[rng.random() < .5 for _ in range(total // 2) if rng.random() < retention] for _ in ARMS]
                interval = newcombe(sum(outcomes[0]), len(outcomes[0]), sum(outcomes[1]), len(outcomes[1]))
                if interval:
                    widths.append((interval[2] - interval[1]) / 2); coverage.append(interval[1] <= 0 <= interval[2]); observed_counts.append(sum(map(len, outcomes)))
            rows.append({'randomized_total_assumed': total, 'balanced_assigned_per_arm': total // 2, 'outcome_retention_assumed': retention,
                         'repeat_probability_both_arms_assumed': .5, 'true_risk_difference_assumed': 0,
                         'replicates': replicates, 'seed': seed + total + int(1000 * retention),
                         'mean_observed_total': statistics.mean(observed_counts), 'mean_ci_half_width': statistics.mean(widths),
                         'simulated_coverage': statistics.mean(coverage),
                         'balanced_worst_case_normal_half_width_no_attrition': Z * math.sqrt(1 / total),
                         'notice': 'Precision illustration with independent sessions and MCAR missingness; assumptions, not pilot estimates or power calculation'})
    write_csv(output / 'precision-scenarios.csv', rows)
    (output / 'generation-assumptions.json').write_text(json.dumps({
        'notice': 'NO PARTICIPANT FINDINGS. All traces and simulation inputs are invented software-verification assumptions.',
        'generation_seed': seed, 'example_repeat_probability': {'all_correct': .55, 'distinct_item': .40},
        'baseline_correct_probability': .60, 'transfer_correct_probability': '.30 + .10*baseline_total + .02*I(all_correct), bounded [.15,.95]',
        'example_missingness': 'Deterministic indices exercise withdrawal, complete no-choice windows, early no-choice stops, later incompletion, missing transfer, and missing custom reflections.',
        'precision_design': 'N100/200/400 balanced allocation; each repeat outcome Bernoulli(.5) in both arms; retention1/.9/.8 independently of arm and outcome (MCAR).',
        'candidate400': 'About0.098 worst-case normal95% half-width before attrition. Provisional precision candidate only; not approved recruitment or a power calculation.',
        'feasibility40to60': 'A separate possible materials/operations pilot, not an adequately powered confirmatory effect test.',
        'limitations': 'Real variation, meaningful difference, dependence/repeat participation, nonrandom attrition and piloted item properties are unknown.'
    }, indent=2) + '\n')

def verification(config):
    records = generate_synthetic(config, 80, 20261003)
    rows = [reconstruct(record, config) for record in records]
    checks = []
    def check(name, condition):
        if not condition: raise AssertionError(name)
        checks.append({'check': name, 'passed': True})
    check('all artificial traces satisfy chronology, keys, eligibility and both point rules', len(rows) == 80)
    check('complete no-choice is observed zero', any(row['first_choice_category'] == 'none' and row['primary_repeat'] == 0 for row in rows))
    check('shortened no-choice is missing', any(row['first_choice_category'] == 'unavailable' and row['primary_repeat'] is None for row in rows))
    check('first choice survives later incomplete run', any(row['status'] == 'incomplete' and row['primary_repeat'] is not None for row in rows))
    check('withdrawn outcomes all omitted', all(row['primary_repeat'] is None and row['baseline_total'] is None and row['transfer_total'] is None for row in rows if row['status'] == 'withdrawn'))
    check('incomplete transfer is not assigned zero', any(row['status'] == 'completed' and row['transfer_answered'] == 3 and row['transfer_total'] is None for row in rows))
    check('rule error retains assigned outcome', any(row['rule_comprehension_correct'] == 0 and row['primary_repeat'] is not None for row in rows))
    sample = next(record for record in records if any(event['type'] == 'practice_response' for event in record['events']))
    corrupt = copy.deepcopy(sample)
    next(event['payload'] for event in corrupt['events'] if event['type'] == 'practice_response')['points_awarded'] += 1
    rejected = safe_reconstruct(corrupt, config)
    check('corrupt counter is invalid, never no-choice', not rejected['valid'] and rejected['primary_repeat'] is None and rejected['first_choice_category'] == 'invalid')
    bad = copy.deepcopy(sample)
    next(event['payload'] for event in bad['events'] if event['type'] == 'baseline_response')['correct'] = not next(event['payload'] for event in bad['events'] if event['type'] == 'baseline_response')['correct']
    check('incorrect answer-key metadata is rejected', not safe_reconstruct(bad, config)['valid'])
    reordered = copy.deepcopy(sample); reordered['events'][2]['elapsed_ms'] = -1
    check('invalid chronology is rejected', not safe_reconstruct(reordered, config)['valid'])
    d, low, high = newcombe(5, 10, 5, 10)
    check('equal arm risks yield centered interval', d == 0 and math.isclose(-low, high, abs_tol=1e-12))
    d0, l0, u0 = newcombe(0, 10, 10, 10)
    check('boundary proportions produce bounded finite interval', d0 == -1 and -1 <= l0 <= u0 <= 1)
    original = summarize(rows, config)['primary']
    event_rich = copy.deepcopy(records)
    # Extra opt-in export metadata is not another independent outcome unit.
    for record in event_rich:
        last = record['events'][-1]
        record['events'].append(dict(sequence=last['sequence'] + 1, type='development_export_requested', elapsed_ms=last['elapsed_ms'], payload={'opt_in': True, 'no_remote_upload': True}))
    repeated = summarize([reconstruct(record, config) for record in event_rich], config)['primary']
    check('more events do not increase analysis sample size or alter interval', original == repeated)
    perfect = [{'arm': arm, 'baseline_total': baseline, 'transfer_total': 1 + .5 * (arm == 'all_correct') + .8 * baseline,
                'valid': True} for arm in ARMS for baseline in range(4) for _ in range(2)]
    fitted = adjusted_transfer(perfect)
    check('ANCOVA recovers known arm coefficient', fitted['status'] == 'estimated' and math.isclose(fitted['arm_difference_points'], .5, abs_tol=1e-10))
    check('rank-deficient ANCOVA is explicit', adjusted_transfer([dict(row, baseline_total=1) for row in perfect])['status'] == 'not_estimable')
    return {'status': 'passed', 'n_checks': len(checks), 'checks': checks,
            'scope': 'Software verification with artificial records; no hypothesis, scale-validity, accessibility or participant-effect validation.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=BASE / 'config/proposed-experiment.json')
    parser.add_argument('--input', type=Path, help='One local development JSON export or an array of labeled synthetic records')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--generate-synthetic', action='store_true')
    parser.add_argument('--n', type=int, default=240)
    parser.add_argument('--seed', type=int, default=20261003)
    parser.add_argument('--precision-replicates', type=int, default=2000)
    args = parser.parse_args(); config = config_load(args.config)
    require(args.generate_synthetic != bool(args.input), 'Choose exactly one input export or explicit synthetic generation.')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.generate_synthetic:
        records = generate_synthetic(config, args.n, args.seed)
        input_path = args.output_dir / 'synthetic-sessions.json'
        # One artificial session per line keeps the inspectable example compact.
        input_path.write_text('[\n' + ',\n'.join(json.dumps(record, separators=(',', ':'), allow_nan=False) for record in records) + '\n]\n')
        precision_simulation(args.output_dir, args.seed, args.precision_replicates)
    else:
        input_path = args.input; loaded = json.loads(input_path.read_text()); records = loaded if isinstance(loaded, list) else [loaded]
    rows, summary = analyze(records, config, args.output_dir)
    verified = verification(config)
    (args.output_dir / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
    fingerprints = {'config_sha256': hashlib.sha256(args.config.read_bytes()).hexdigest(),
                    'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
                    'analyzer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (args.output_dir / 'source-fingerprints.json').write_text(json.dumps(fingerprints, indent=2) + '\n')
    print(json.dumps({'notice': summary['notice'], 'records': len(rows), 'valid': summary['n_valid'], 'invalid': summary['n_invalid'],
                      'verification_checks': verified['n_checks'], 'output_dir': str(args.output_dir)}, indent=2))
    if summary['n_invalid']:
        raise SystemExit('Invalid records were quarantined with missing outcomes; inspect session-outcomes.csv.')

if __name__ == '__main__':
    main()
