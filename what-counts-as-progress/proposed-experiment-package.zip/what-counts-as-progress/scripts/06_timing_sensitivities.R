#!/usr/bin/env Rscript
# Fixed, prespecified timing comparisons. Never selects a preferred cutoff.
suppressPackageStartupMessages(library(readr))
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("Usage: Rscript scripts/06_timing_sensitivities.R PRIVATE_DATA_DIR RESULTS_DIR PRIVATE_MODEL_DIR")
data_dir <- args[1]; results_dir <- args[2]; model_dir <- args[3]
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)
scenarios <- c(window28 = "sensitivity-window28", cutoff70 = "sensitivity-cutoff70")
specs <- list(
  reference = target_score ~ prior_score + course_offering,
  volume = target_score ~ prior_score + course_offering + log1p(total_clicks),
  consistency = target_score ~ prior_score + course_offering + active_days,
  combined = target_score ~ prior_score + course_offering + log1p(total_clicks) + active_days
)
keys <- c("code_module", "code_presentation", "id_student")
pred_cols <- c(keys, "course_offering", "prior_score", "total_clicks", "active_days")
read_csv_quiet <- function(path) {
  parsed <- read_csv(path, show_col_types = FALSE, progress = FALSE)
  if (nrow(problems(parsed))) stop("Parser failures: ", path)
  as.data.frame(parsed)
}
make_key <- function(d) do.call(paste, c(d[keys], sep = ":"))
prepared <- list(); fitted <- list()
# Both sets of models are fitted and persisted before either evaluation outcome file is read.
for (scenario in names(scenarios)) {
  folder <- file.path(data_dir, scenarios[[scenario]])
  dev_all <- read_csv_quiet(file.path(folder, "development.csv"))
  dev <- dev_all[!is.na(dev_all$target_score), c(pred_cols, "target_score")]
  features <- read_csv_quiet(file.path(folder, "evaluation-features.csv"))
  start <- if (scenario == "window28") 28 else 56
  cutoff <- if (scenario == "window28") 56 else 70
  for (data in list(dev_all, features)) {
    stopifnot(!anyNA(data[pred_cols]), all(data$prior_submission_day < start),
      all(data$target_deadline > cutoff), all(data$prior_score >= 0 & data$prior_score <= 100),
      all(data$total_clicks >= 0), all(data$active_days >= 0 & data$active_days <= cutoff - start))
  }
  stopifnot(all(is.na(dev_all$target_score) | (dev_all$target_score >= 0 & dev_all$target_score <= 100)),
    all(is.na(dev_all$target_submission_day) | dev_all$target_submission_day >= cutoff))
  stopifnot(!anyDuplicated(make_key(dev_all)), !anyDuplicated(make_key(features)))
  stopifnot(length(intersect(unique(dev_all$id_student), unique(features$id_student))) == 0L)
  stopifnot(!any(c("target_score", "target_submission_day", "withdrawal_day") %in% names(features)))
  levels_offering <- sort(unique(dev$course_offering))
  stopifnot(all(features$course_offering %in% levels_offering))
  dev$course_offering <- factor(dev$course_offering, levels = levels_offering)
  evaluation <- features[pred_cols]
  evaluation$course_offering <- factor(evaluation$course_offering, levels = levels_offering)
  fitted[[scenario]] <- lapply(specs, function(spec) lm(spec, data = dev, na.action = na.fail))
  stopifnot(!any(vapply(fitted[[scenario]], function(model) anyNA(coef(model)), logical(1))))
  prepared[[scenario]] <- list(folder = folder, features = evaluation,
    eligible_dev = nrow(dev_all), eligible_eval = nrow(features), observed_dev = nrow(dev))
}
saveRDS(fitted, file.path(model_dir, "fixed-timing-models-before-evaluation.rds"))
writeLines(c(paste("Models persisted at", format(Sys.time(), tz = "UTC", usetz = TRUE)),
  "All timing model fits precede evaluation-outcomes.csv reads in this script."),
  file.path(results_dir, "timing-fit-order.txt"))
cluster_interval <- function(id, differences, seed) {
  sums <- rowsum(differences, as.character(id), reorder = TRUE)
  counts <- rowsum(rep(1, length(id)), as.character(id), reorder = TRUE)[, 1]
  stopifnot(identical(rownames(sums), names(counts)))
  set.seed(seed)
  draws <- matrix(NA_real_, nrow = 2000, ncol = ncol(sums))
  for (b in seq_len(nrow(draws))) {
    selection <- sample.int(nrow(sums), nrow(sums), replace = TRUE)
    draws[b, ] <- colSums(sums[selection, , drop = FALSE]) / sum(counts[selection])
  }
  apply(draws, 2, quantile, probs = c(.025, .975), names = FALSE)
}
rows <- list(); coverage <- list(); course_rows <- list()
for (scenario in names(scenarios)) {
  prep <- prepared[[scenario]]
  outcomes <- read_csv_quiet(file.path(prep$folder, "evaluation-outcomes.csv"))
  cutoff <- if (scenario == "window28") 56 else 70
  stopifnot(all(is.na(outcomes$target_score) | (outcomes$target_score >= 0 & outcomes$target_score <= 100)),
    all(is.na(outcomes$target_submission_day) | outcomes$target_submission_day >= cutoff),
    all(outcomes$target_score_observed == as.integer(!is.na(outcomes$target_score))),
    all(outcomes$target_submitted == as.integer(!is.na(outcomes$target_submission_day))))
  stopifnot(!anyDuplicated(make_key(outcomes)), setequal(make_key(outcomes), make_key(prep$features)))
  outcomes <- outcomes[match(make_key(prep$features), make_key(outcomes)), ]
  keep <- !is.na(outcomes$target_score)
  evaluation <- prep$features[keep, ]
  observed <- outcomes$target_score[keep]
  predictions <- sapply(fitted[[scenario]], predict, newdata = evaluation)
  stopifnot(all(is.finite(predictions)))
  errors <- abs(predictions - observed)
  differences <- errors[, "reference"] - errors[, c("volume", "consistency", "combined"), drop = FALSE]
  interval <- cluster_interval(evaluation$id_student, differences, 20261003)
  for (model in names(specs)) {
    index <- match(model, c("volume", "consistency", "combined"))
    rows[[length(rows) + 1L]] <- data.frame(scenario = scenario, model = model,
      observed_development = prep$observed_dev, observed_evaluation = nrow(evaluation),
      evaluation_learners = length(unique(evaluation$id_student)), mae = mean(errors[, model]),
      mae_reduction = if (model == "reference") 0 else mean(differences[, model]),
      ci_lower = if (model == "reference") NA_real_ else interval[1, index],
      ci_upper = if (model == "reference") NA_real_ else interval[2, index],
      predictions_outside_0_100 = sum(predictions[, model] < 0 | predictions[, model] > 100))
  }
  coverage[[scenario]] <- data.frame(scenario = scenario,
    eligible_development = prep$eligible_dev, eligible_evaluation = prep$eligible_eval,
    observed_development = prep$observed_dev, observed_evaluation = nrow(evaluation),
    target_submissions_evaluation = sum(outcomes$target_submitted == 1),
    missing_mark_evaluation = sum(!keep))
  for (course in sort(unique(as.character(evaluation$course_offering)))) {
    mask <- as.character(evaluation$course_offering) == course
    course_rows[[length(course_rows) + 1L]] <- data.frame(scenario = scenario,
      course_offering = course, observed_evaluation = sum(mask),
      reference_mae = mean(errors[mask, "reference"]), volume_mae = mean(errors[mask, "volume"]),
      volume_mae_reduction = mean(differences[mask, "volume"]))
  }
}
write_csv(do.call(rbind, rows), file.path(results_dir, "timing-model-comparison.csv"))
write_csv(do.call(rbind, coverage), file.path(results_dir, "timing-coverage.csv"))
write_csv(do.call(rbind, course_rows), file.path(results_dir, "timing-course-comparison.csv"))
capture.output(sessionInfo(), file = file.path(results_dir, "timing-session-info.txt"))
print(do.call(rbind, rows))
