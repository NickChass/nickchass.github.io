#!/usr/bin/env Rscript
# Additional secondary check. Exact 2014J implementation fixed after main-result
# inspection; never replaces the frozen primary evaluation or selects a cutoff.
# Usage: Rscript 08_latest_offering_check.R PRIVATE_DERIVED_DIR RESULTS_DIR PRIVATE_MODEL_DIR

suppressPackageStartupMessages(library(readr))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("Usage: Rscript 08_latest_offering_check.R PRIVATE_DERIVED_DIR RESULTS_DIR PRIVATE_MODEL_DIR", call. = FALSE)
derived_dir <- normalizePath(args[[1L]], mustWork = TRUE)
results_dir <- args[[2L]]
model_dir <- args[[3L]]
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)
results_dir <- normalizePath(results_dir, mustWork = TRUE)
model_dir <- normalizePath(model_dir, mustWork = TRUE)
script_argument <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
stopifnot(length(script_argument) == 1L)
script_path <- normalizePath(sub("^--file=", "", script_argument), mustWork = TRUE)

decision_date_client <- "2026-10-03"
earlier_presentations <- c("2013B", "2013J", "2014B")
latest_presentation <- "2014J"
presentation_order <- c("2013B" = 1L, "2013J" = 2L, "2014B" = 3L, "2014J" = 4L)
expected_modules <- c("AAA", "BBB", "CCC", "DDD", "EEE", "FFF")
cutoff_day <- 56
activity_start_day <- 42
bootstrap_replicates <- 2000L
bootstrap_seed <- 20261003L
keys <- c("code_module", "code_presentation", "id_student")
predictor_names <- c("prior_score", "code_module", "total_clicks", "active_days")
future_columns <- c("target_score", "target_submission_day", "target_submitted", "target_score_observed", "withdrawal_day")
formula_text <- c(
  reference = "target_score ~ prior_score + code_module",
  volume = "target_score ~ prior_score + code_module + log1p(total_clicks)",
  consistency = "target_score ~ prior_score + code_module + active_days",
  combined_secondary = "target_score ~ prior_score + code_module + log1p(total_clicks) + active_days"
)
formulas <- lapply(formula_text, as.formula)
numeric_columns <- c("prior_deadline", "prior_weight", "prior_submission_day", "prior_score",
                     "target_deadline", "target_weight", "target_submission_day", "target_submitted",
                     "target_score_observed", "target_score", "withdrawal_day", "total_clicks",
                     "active_days", "total_clicks_exact_row_unique_sensitivity")

read_strict <- function(path) {
  header <- read_csv(path, n_max = 0L, col_types = cols(.default = col_character()),
                     show_col_types = FALSE, progress = FALSE)
  types <- setNames(lapply(intersect(numeric_columns, names(header)), function(name) col_double()),
                    intersect(numeric_columns, names(header)))
  specification <- do.call(cols, c(types, list(.default = col_character())))
  data <- read_csv(path, col_types = specification, na = c("", "NA", "?"),
                   show_col_types = FALSE, progress = FALSE)
  if (nrow(problems(data)) > 0L) stop("Parser problems in ", path)
  as.data.frame(data)
}
key_values <- function(data) do.call(paste, c(data[keys], sep = "\u001f"))
check_features <- function(data, partition) {
  required <- unique(c(keys, predictor_names, "partition", "course_offering", "prior_deadline",
                       "prior_submission_day", "target_deadline", "target_weight"))
  stopifnot(all(required %in% names(data)), nrow(data) > 0L,
            !anyNA(data[required]), !anyDuplicated(key_values(data)),
            all(data$partition == partition), all(data$code_module %in% expected_modules),
            all(data$code_presentation %in% names(presentation_order)),
            all(data$course_offering == paste(data$code_module, data$code_presentation, sep = "_")),
            all(is.finite(data$prior_score)), all(data$prior_score >= 0 & data$prior_score <= 100),
            all(is.finite(data$prior_deadline)), all(data$prior_deadline < activity_start_day),
            all(is.finite(data$prior_submission_day)), all(data$prior_submission_day < activity_start_day),
            all(is.finite(data$target_deadline)), all(data$target_deadline > cutoff_day),
            all(is.finite(data$target_weight)), all(data$target_weight > 0),
            all(is.finite(data$total_clicks)), all(data$total_clicks >= 0),
            all(is.finite(data$active_days)), all(data$active_days == floor(data$active_days)),
            all(data$active_days >= 0 & data$active_days <= cutoff_day - activity_start_day))
}
check_outcomes <- function(data) {
  required <- c(keys, future_columns)
  stopifnot(all(required %in% names(data)), !anyDuplicated(key_values(data)),
            !anyNA(data[c(keys, "target_submitted", "target_score_observed")]),
            all(is.na(data$target_submission_day) | data$target_submission_day >= cutoff_day),
            all(is.na(data$target_score) | (is.finite(data$target_score) & data$target_score >= 0 & data$target_score <= 100)),
            all(data$target_submitted %in% c(0, 1)), all(data$target_score_observed %in% c(0, 1)),
            all(data$target_score_observed == as.integer(!is.na(data$target_score))),
            all(data$target_submitted == as.integer(!is.na(data$target_submission_day))),
            all(data$target_score_observed <= data$target_submitted))
}

development <- read_strict(file.path(derived_dir, "development.csv"))
evaluation_features <- read_strict(file.path(derived_dir, "evaluation-features.csv"))
check_features(development, "development")
check_features(evaluation_features, "evaluation")
check_outcomes(development)
stopifnot(!any(future_columns %in% names(evaluation_features)),
          length(intersect(unique(development$id_student), unique(evaluation_features$id_student))) == 0L)

training_eligible <- development[development$code_presentation %in% earlier_presentations, ]
training_observed <- training_eligible[!is.na(training_eligible$target_score), ]
latest_features <- evaluation_features[evaluation_features$code_presentation == latest_presentation, ]
stopifnot(nrow(training_observed) >= 50L, nrow(latest_features) >= 50L,
          setequal(unique(training_observed$code_module), expected_modules),
          setequal(unique(latest_features$code_module), expected_modules),
          all(presentation_order[training_eligible$code_presentation] < presentation_order[latest_presentation]),
          length(intersect(unique(training_eligible$id_student), unique(latest_features$id_student))) == 0L)
module_levels <- expected_modules
training_observed$code_module <- factor(training_observed$code_module, levels = module_levels)
latest_features$code_module <- factor(latest_features$code_module, levels = module_levels)

# Select only the formula's explicitly named inputs; future submission/withdrawal
# fields remain outside every model frame. Never use offering-specific effects.
fitted_models <- lapply(formulas, function(formula) {
  variables <- all.vars(formula)
  stopifnot(setequal(setdiff(variables, predictor_names), "target_score"))
  frame <- training_observed[variables]
  stopifnot(!anyNA(frame))
  model <- lm(formula, data = frame, na.action = na.fail)
  stopifnot(!anyNA(coef(model)), all(is.finite(coef(model))),
            nobs(model) == nrow(training_observed),
            setequal(model$xlevels$code_module, module_levels))
  model
})
models_fixed_at_utc <- format(Sys.time(), format = "%Y-%m-%d %H:%M:%OS6 UTC", tz = "UTC")
private_model_path <- file.path(model_dir, "latest-offering-secondary-models.rds")
saveRDS(list(models = fitted_models, formulas = formula_text,
             training_presentations = earlier_presentations, evaluation_presentation = latest_presentation,
             status = "Additional secondary check; exact implementation fixed after main-results inspection",
             decision_date_client = decision_date_client, models_fixed_at_utc = models_fixed_at_utc,
             bootstrap_replicates = bootstrap_replicates, bootstrap_seed = bootstrap_seed), private_model_path)
stopifnot(file.exists(private_model_path))

# Reserved outcomes may already have been inspected for the primary comparison.
# This script nevertheless fixes and saves every secondary model before reading
# its evaluation outcomes, and performs no selection or tuning afterward.
evaluation_outcomes_opened_at_utc <- format(Sys.time(), format = "%Y-%m-%d %H:%M:%OS6 UTC", tz = "UTC")
evaluation_outcomes <- read_strict(file.path(derived_dir, "evaluation-outcomes.csv"))
check_outcomes(evaluation_outcomes)
stopifnot(setequal(key_values(evaluation_features), key_values(evaluation_outcomes)))
latest_outcomes <- evaluation_outcomes[match(key_values(latest_features), key_values(evaluation_outcomes)), ]
stopifnot(identical(key_values(latest_features), key_values(latest_outcomes)))
has_mark <- !is.na(latest_outcomes$target_score)
evaluation_observed <- latest_features[has_mark, ]
observed_scores <- latest_outcomes$target_score[has_mark]
stopifnot(nrow(evaluation_observed) >= 50L, setequal(unique(as.character(evaluation_observed$code_module)), expected_modules))
predictions <- vapply(fitted_models, function(model) {
  variables <- setdiff(all.vars(formula(model)), "target_score")
  stopifnot(all(variables %in% predictor_names), !anyNA(evaluation_observed[variables]))
  as.numeric(predict(model, newdata = evaluation_observed[variables]))
}, numeric(nrow(evaluation_observed)))
stopifnot(all(is.finite(predictions)), identical(colnames(predictions), names(formula_text)))
absolute_errors <- abs(sweep(predictions, 1L, observed_scores, "-"))
comparison_models <- setdiff(names(formula_text), "reference")
paired_differences <- vapply(comparison_models, function(name) {
  absolute_errors[, "reference"] - absolute_errors[, name]
}, numeric(nrow(evaluation_observed)))
colnames(paired_differences) <- comparison_models

cluster_intervals <- function(values, learners) {
  values <- as.matrix(values)
  stopifnot(nrow(values) == length(learners), !anyNA(learners), all(is.finite(values)))
  cluster_sums <- rowsum(values, learners, reorder = FALSE)
  cluster_counts <- rowsum(matrix(1, nrow(values), 1L), learners, reorder = FALSE)
  stopifnot(identical(rownames(cluster_sums), rownames(cluster_counts)), nrow(cluster_sums) >= 2L)
  cluster_counts <- cluster_counts[, 1L]
  set.seed(bootstrap_seed)
  draws <- matrix(NA_real_, bootstrap_replicates, ncol(values))
  for (replicate in seq_len(bootstrap_replicates)) {
    sampled <- sample.int(nrow(cluster_sums), nrow(cluster_sums), replace = TRUE)
    draws[replicate, ] <- colSums(cluster_sums[sampled, , drop = FALSE]) / sum(cluster_counts[sampled])
  }
  apply(draws, 2L, quantile, probs = c(.025, .975), names = FALSE)
}
intervals <- cluster_intervals(paired_differences, evaluation_observed$id_student)
metrics <- data.frame(model = names(formula_text), n_enrollments = nrow(evaluation_observed),
                      n_learners = length(unique(evaluation_observed$id_student)),
                      mae = colMeans(absolute_errors),
                      rmse = sqrt(colMeans(sweep(predictions, 1L, observed_scores, "-")^2)),
                      below_zero = colSums(predictions < 0), above_100 = colSums(predictions > 100),
                      minimum_prediction = apply(predictions, 2L, min),
                      maximum_prediction = apply(predictions, 2L, max), row.names = NULL)
comparisons <- data.frame(model = comparison_models, reference_model = "reference",
                          n_enrollments = nrow(evaluation_observed),
                          n_learners = length(unique(evaluation_observed$id_student)),
                          mae_reduction = colMeans(paired_differences),
                          ci_low = intervals[1L, ], ci_high = intervals[2L, ],
                          bootstrap_replicates = bootstrap_replicates, bootstrap_seed = bootstrap_seed,
                          unit = "assessment-mark points; enrollment-weighted",
                          uncertainty = "95% percentile learner-cluster bootstrap; fixed trained models",
                          status = "Additional secondary check; exact implementation fixed after main-results inspection",
                          row.names = NULL)
module_comparisons <- do.call(rbind, lapply(expected_modules, function(module) {
  selected <- as.character(evaluation_observed$code_module) == module
  differences <- paired_differences[selected, , drop = FALSE]
  module_interval <- cluster_intervals(differences, evaluation_observed$id_student[selected])
  data.frame(code_module = module, model = comparison_models, reference_model = "reference",
             n_enrollments = sum(selected), n_learners = length(unique(evaluation_observed$id_student[selected])),
             reference_mae = mean(absolute_errors[selected, "reference"]),
             model_mae = colMeans(absolute_errors[selected, comparison_models, drop = FALSE]),
             mae_reduction = colMeans(differences), ci_low = module_interval[1L, ], ci_high = module_interval[2L, ],
             interpretation = "Secondary descriptive module comparison; no multiplicity correction or causal claim",
             row.names = NULL)
}))

coverage_rows <- lapply(expected_modules, function(module) {
  training_mask <- training_eligible$code_module == module
  evaluation_mask <- as.character(latest_features$code_module) == module
  data.frame(code_module = module,
             training_presentations = paste(sort(unique(training_eligible$code_presentation[training_mask])), collapse = ";"),
             evaluation_presentation = latest_presentation,
             training_eligible_enrollments = sum(training_mask),
             training_observed_marks = sum(!is.na(training_eligible$target_score[training_mask])),
             training_eligible_learners = length(unique(training_eligible$id_student[training_mask])),
             evaluation_eligible_enrollments = sum(evaluation_mask),
             evaluation_eligible_learners = length(unique(latest_features$id_student[evaluation_mask])),
             evaluation_target_submissions = sum(latest_outcomes$target_submitted[evaluation_mask]),
             evaluation_observed_marks = sum(has_mark[evaluation_mask]),
             evaluation_missing_marks = sum(!has_mark[evaluation_mask]),
             row.names = NULL)
})
coverage <- do.call(rbind, coverage_rows)

write_csv(metrics, file.path(results_dir, "latest-offering-model-metrics.csv"))
write_csv(comparisons, file.path(results_dir, "latest-offering-comparisons.csv"))
write_csv(module_comparisons, file.path(results_dir, "latest-offering-module-comparisons.csv"))
write_csv(coverage, file.path(results_dir, "latest-offering-coverage.csv"))
write_csv(data.frame(model = names(formula_text), formula = unname(formula_text)),
          file.path(results_dir, "latest-offering-model-specification.csv"))
record <- data.frame(field = c(
  "status", "decision_date_client", "broad_check_anticipated", "exact_implementation_fixed_after_main_results",
  "training_partition", "training_presentation_rule", "evaluation_partition", "evaluation_presentation",
  "module_count", "training_eligible", "training_observed_marks", "training_observed_learners",
  "evaluation_eligible", "evaluation_observed_marks", "evaluation_observed_learners", "learner_overlap",
  "models_fixed_at_utc", "evaluation_outcomes_opened_at_utc", "models_saved_before_outcome_read",
  "model_tuning_after_evaluation", "offering_effects_used", "grade_release_availability_established",
  "bootstrap_replicates", "bootstrap_seed", "prediction_handling", "uncertainty_scope"),
  value = c(
    "Additional secondary check; never a replacement primary result", decision_date_client, "TRUE", "TRUE",
    "Development only", "All represented earlier offerings: 2013B,2013J,2014B", "Reserved evaluation learners only", latest_presentation,
    as.character(length(expected_modules)), as.character(nrow(training_eligible)), as.character(nrow(training_observed)),
    as.character(length(unique(training_observed$id_student))), as.character(nrow(latest_features)),
    as.character(nrow(evaluation_observed)), as.character(length(unique(evaluation_observed$id_student))), "0",
    models_fixed_at_utc, evaluation_outcomes_opened_at_utc, "TRUE", "NONE", "FALSE; transferable module effects only",
    "FALSE; offering-label ordering is not evidence of grade-release availability",
    as.character(bootstrap_replicates), as.character(bootstrap_seed), "Raw unclipped OLS predictions",
    "Paired learner-cluster percentile intervals conditional on fixed fitted earlier-development models"))
write_csv(record, file.path(results_dir, "latest-offering-run-record.csv"))
hash_paths <- c(script = script_path, development = file.path(derived_dir, "development.csv"),
                evaluation_features = file.path(derived_dir, "evaluation-features.csv"),
                evaluation_outcomes = file.path(derived_dir, "evaluation-outcomes.csv"), private_models = private_model_path)
# Public fingerprints identify source roles without exposing machine-specific
# paths. Hashes still use the actual local files supplied to this execution.
hash_labels <- c(script = "scripts/08_latest_offering_check.R",
                 development = "PRIVATE_DERIVED_DIR/development.csv",
                 evaluation_features = "PRIVATE_DERIVED_DIR/evaluation-features.csv",
                 evaluation_outcomes = "PRIVATE_DERIVED_DIR/evaluation-outcomes.csv",
                 private_models = "PRIVATE_MODEL_DIR/latest-offering-secondary-models.rds")
stopifnot(identical(names(hash_paths), names(hash_labels)))
write_csv(data.frame(source = names(hash_paths), path = unname(hash_labels), hash_algorithm = "MD5",
                     hash = unname(tools::md5sum(hash_paths))), file.path(results_dir, "latest-offering-source-fingerprints.csv"))
writeLines(capture.output(sessionInfo()), file.path(results_dir, "latest-offering-session-info.txt"))
writeLines(c(
  "Status: additional secondary check, not the primary analysis and not a new externally preregistered result.",
  "The frozen v0.2 plan anticipated compatible offering holdouts with transferable module-level effects.",
  "The precise latest-2014J implementation was fixed after inspection of the main primary results and is reported transparently as an additional secondary check.",
  "All six represented modules are retained. Training uses observed marks from DEVELOPMENT learners in all represented 2013B/2013J/2014B offerings only.",
  "Evaluation uses RESERVED learners in 2014J offerings only. Learners remain disjoint between training and evaluation.",
  "Every model was fitted and persisted in private working storage before this script read evaluation outcomes. There is no outcome-driven model selection, tuning, clipping, or refitting.",
  "Reference predictors are prior score and module code. Volume adds log1p(total_clicks); consistency adds active days; the combined model adds both.",
  "No latest-offering fixed effect is estimated or transferred: only module-level effects are used.",
  "The cohort, target assessment, days42-55 activity window, and day56 cutoff retain the primary prepared definitions.",
  "The chronology rule orders offering labels. Grade-release timestamps are absent, so this is not a certified simulation of live training-data availability.",
  "This check mixes changes in evaluation cohort and model context; it does not isolate a causal temporal effect or imply generalization to every future course.",
  "MAE is enrollment-weighted and evaluated only among observed marks. Missing marks are retained in coverage outputs and never assigned zero.",
  "Positive MAE reduction indicates better prediction of this assessment criterion; it does not establish learning improvement or a causal dashboard effect.",
  "All paired differences use the same observations. Uncertainty resamples learner clusters with all their selected enrollment records, 2000 replicates and seed20261003, conditional on fixed trained models.",
  "Per-module comparisons and intervals are descriptive secondary outputs with no multiplicity correction; small modules can have imprecise estimates.",
  "All public outputs are aggregate. Learner-level source rows and fitted models remain in private working storage; individual predictions are not published."
), file.path(results_dir, "latest-offering-notes.txt"))
print(metrics)
print(comparisons)
message("Additional secondary latest-offering check complete. Aggregate results: ", results_dir)
