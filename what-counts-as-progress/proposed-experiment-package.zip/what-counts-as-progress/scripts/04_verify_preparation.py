#!/usr/bin/env python3
"""Independent accounting, temporal, evaluation and provenance checks; no modeling."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

def read(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))

def key(row):
    return row["code_module"], row["code_presentation"], row["id_student"]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-dir", type=Path, required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    args = parser.parse_args()
    project, data = args.project_dir, args.data_dir
    checks = {}
    manifest = json.loads((project / "audit/data-provenance.json").read_text())
    for entry in manifest["files"]:
        path = data / "raw" / entry["name"]
        with path.open("rb") as handle:
            actual = hashlib.file_digest(handle, "sha256").hexdigest()
        assert actual == entry["sha256"] and path.stat().st_size == entry["bytes"]
    checks["raw_tables_match_acquisition_checksums"] = True
    config = json.loads((project / "config/analysis-config.json").read_text())
    lock = json.loads((project / "config/analysis-plan-lock.json").read_text())
    prepared = json.loads((project / "audit/preparation-checks.json").read_text())
    config_hash = hashlib.sha256((project / "config/analysis-config.json").read_bytes()).hexdigest()
    assert config_hash == lock["config_sha256"] == prepared["config_sha256"]
    checks["prepared_cohort_matches_current_plan_checksum"] = True
    development = read(data / "derived/development.csv")
    evaluation = read(data / "derived/evaluation-features.csv")
    outcomes = read(data / "derived/evaluation-outcomes.csv")
    assert len({key(row) for row in development}) == len(development)
    assert len({key(row) for row in evaluation}) == len(evaluation)
    assert {key(row) for row in evaluation} == {key(row) for row in outcomes}
    checks["unique_cohort_keys_and_matching_evaluation_outcomes"] = True
    assert not ({row["id_student"] for row in development} & {row["id_student"] for row in evaluation})
    assert {row["course_offering"] for row in evaluation}.issubset({row["course_offering"] for row in development})
    checks["no_learner_overlap_and_all_evaluation_contexts_supported"] = True
    forbidden = {"target_score", "target_submission_day", "target_submitted", "target_score_observed", "withdrawal_day"}
    assert not forbidden.intersection(evaluation[0])
    checks["future_outcome_fields_absent_from_evaluation_features"] = True
    for record in development + evaluation:
        assert float(record["prior_submission_day"]) < config["activity_start_day"]
        assert 0 <= int(record["active_days"]) <= config["cutoff_day"] - config["activity_start_day"]
        assert 0 <= int(record["total_clicks_exact_row_unique_sensitivity"]) <= int(record["total_clicks"])
        assert (int(record["active_days"]) == 0) == (int(record["total_clicks"]) == 0)
    for record in development + outcomes:
        if record["target_submission_day"]:
            assert float(record["target_submission_day"]) >= config["cutoff_day"]
        if record["target_score"]:
            assert 0 <= float(record["target_score"]) <= 100
    checks["chronology_activity_bounds_and_sensitivity_encoding"] = True
    flow = {row["stage"]: int(row["count"]) for row in read(project / "audit/primary-cohort-flow.csv")}
    exclusions = read(project / "audit/primary-exclusion-reasons.csv")
    assert flow["all_registration_records"] == len(development) + len(evaluation) + sum(int(row["count"]) for row in exclusions)
    assert flow["eligible_cohort"] == len(development) + len(evaluation) == prepared["cohort_records"]
    assert prepared["eligible_window_source_rows"] == prepared["eligible_window_unique_complete_rows"] + prepared["eligible_window_exact_repeated_rows_beyond_first"]
    checks["cohort_and_source_row_accounting"] = True
    independent = {(row["code_module"], row["code_presentation"]): row
                   for row in read(project / "audit/landmark_window_candidate_coverage.csv")
                   if int(row["landmark_day"]) == config["cutoff_day"]}
    for row in read(project / "audit/primary-offering-coverage.csv"):
        other = independent[(row["code_module"], row["code_presentation"])]
        assert int(row["eligible"]) == int(other["n_provisional_temporally_eligible"])
        assert int(row["observed_score"]) == int(other["n_target_valid_score_among_future_submissions"])
        assert int(row["prior_id"]) == int(other["prior_tma_id"])
        assert int(row["target_id"]) == int(other["target_tma_id"])
    checks["each_offering_matches_independent_R_availability_audit"] = True
    result = dict(checks=checks, all_passed=True, associations_computed=False, models_fit=False)
    (project / "audit/verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"Passed {len(checks)} verification groups. No activity-mark associations computed.")

if __name__ == "__main__":
    main()
