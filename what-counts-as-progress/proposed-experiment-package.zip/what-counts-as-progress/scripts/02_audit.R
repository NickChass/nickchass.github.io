#!/usr/bin/env Rscript
# Audit the public OULAD release without fitting models or summarising grade values.
# Usage: Rscript 02_audit.R RAW_DIRECTORY OUTPUT_DIRECTORY
# Only aggregate audit records are written. No student identifiers are exported.

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) {
  stop("Usage: Rscript 02_audit.R RAW_DIRECTORY OUTPUT_DIRECTORY", call. = FALSE)
}
raw_dir <- normalizePath(args[[1L]], mustWork = TRUE)
out_dir <- args[[2L]]
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
out_dir <- normalizePath(out_dir, mustWork = TRUE)

specs <- list(
  assessments = cols(
    code_module = col_character(), code_presentation = col_character(),
    id_assessment = col_integer(), assessment_type = col_character(),
    date = col_integer(), weight = col_double()
  ),
  courses = cols(
    code_module = col_character(), code_presentation = col_character(),
    module_presentation_length = col_integer()
  ),
  studentAssessment = cols(
    id_assessment = col_integer(), id_student = col_integer(),
    date_submitted = col_integer(), is_banked = col_integer(), score = col_double()
  ),
  studentInfo = cols(
    code_module = col_character(), code_presentation = col_character(),
    id_student = col_integer(), gender = col_character(), region = col_character(),
    highest_education = col_character(), imd_band = col_character(),
    age_band = col_character(), num_of_prev_attempts = col_integer(),
    studied_credits = col_integer(), disability = col_character(),
    final_result = col_character()
  ),
  studentRegistration = cols(
    code_module = col_character(), code_presentation = col_character(),
    id_student = col_integer(), date_registration = col_integer(),
    date_unregistration = col_integer()
  ),
  studentVle = cols(
    code_module = col_character(), code_presentation = col_character(),
    id_student = col_integer(), id_site = col_integer(),
    date = col_integer(), sum_click = col_integer()
  ),
  vle = cols(
    id_site = col_integer(), code_module = col_character(),
    code_presentation = col_character(), activity_type = col_character(),
    week_from = col_integer(), week_to = col_integer()
  )
)

required_files <- paste0(names(specs), ".csv")
missing_files <- required_files[!file.exists(file.path(raw_dir, required_files))]
if (length(missing_files)) {
  stop("Missing tables: ", paste(missing_files, collapse = ", "), call. = FALSE)
}

key_values <- function(data, columns) {
  if (!nrow(data)) return(character())
  missing <- rowSums(is.na(data[, columns, drop = FALSE])) > 0L
  values <- do.call(paste, c(as.list(data[, columns, drop = FALSE]), sep = "\u001f"))
  values[missing] <- NA_character_
  values
}

audit <- new.env(parent = emptyenv())
audit$checks <- tibble(
  table = character(), check = character(), rows_checked = double(),
  failures = double(), status = character(), note = character()
)
audit$schema <- tibble(
  table = character(), column = character(), parsed_type = character(),
  rows = double(), missing = double(), missing_fraction = double()
)
audit$counts <- tibble(
  table = character(), rows = double(), columns = integer(),
  parser_problems = double(), bytes = double()
)
audit$parser <- tibble(table = character(), column = character(), problems = double())

add_check <- function(table, check, rows_checked, failures,
                      note = "", status = NULL) {
  if (is.null(status)) status <- if (is.na(failures)) "not_checked" else
    if (failures == 0) "pass" else "review"
  audit$checks <- bind_rows(audit$checks, tibble(
    table = table, check = check, rows_checked = as.double(rows_checked),
    failures = as.double(failures), status = status, note = note
  ))
}

add_duplicates <- function(table, data, columns) {
  keys <- key_values(data, columns)
  valid <- keys[!is.na(keys)]
  repeated <- duplicated(valid)
  label <- paste(columns, collapse = " + ")
  add_check(table, paste0("missing key: ", label), nrow(data), sum(is.na(keys)))
  add_check(table, paste0("duplicate rows beyond first: ", label), length(valid),
            sum(repeated), "No records are silently removed.")
  add_check(table, paste0("duplicate key groups: ", label), length(valid),
            length(unique(valid[repeated])), "No records are silently removed.")
  sum(repeated)
}

add_fk <- function(table, check, keys, dictionary) {
  valid <- !is.na(keys)
  add_check(table, check, sum(valid),
            sum(!keys[valid] %in% dictionary[!is.na(dictionary)]),
            "Missing key fields are counted separately from unmatched non-missing keys.")
}

add_schema <- function(table, data, missing_counts = NULL, n_rows = nrow(data)) {
  if (is.null(missing_counts)) missing_counts <- vapply(data, function(x) sum(is.na(x)), 0)
  types <- vapply(data, function(x) paste(class(x), collapse = "/"), "")
  audit$schema <- bind_rows(audit$schema, tibble(
    table = table, column = names(data), parsed_type = types,
    rows = as.double(n_rows), missing = as.double(missing_counts),
    missing_fraction = if (n_rows) as.double(missing_counts) / n_rows else NA_real_
  ))
}

add_parser_counts <- function(table, data) {
  p <- problems(data)
  if (!nrow(p)) return(0)
  column <- as.character(p$col)
  numeric_column <- suppressWarnings(as.integer(column))
  known <- !is.na(numeric_column) & numeric_column >= 1L & numeric_column <= ncol(data)
  column[known] <- names(data)[numeric_column[known]]
  counts <- as.data.frame(table(column), stringsAsFactors = FALSE)
  audit$parser <- bind_rows(audit$parser, tibble(
    table = table, column = as.character(counts$column),
    problems = as.double(counts$Freq)
  ))
  nrow(p)
}

# Check all headers before reading any complete table. Unexpected columns are
# retained and reported; missing required columns prevent an ambiguous audit.
headers <- list()
for (table_name in names(specs)) {
  header <- read_csv(file.path(raw_dir, paste0(table_name, ".csv")), n_max = 0,
                     col_types = cols(.default = col_character()),
                     progress = FALSE, show_col_types = FALSE)
  required <- names(specs[[table_name]]$cols)
  absent <- setdiff(required, names(header))
  if (length(absent)) {
    stop(table_name, " is missing columns: ", paste(absent, collapse = ", "), call. = FALSE)
  }
  headers[[table_name]] <- header
  add_check(table_name, "unexpected columns", ncol(header),
            length(setdiff(names(header), required)),
            paste(setdiff(names(header), required), collapse = "; "))
}

tables <- list()
for (table_name in setdiff(names(specs), "studentVle")) {
  data <- read_csv(file.path(raw_dir, paste0(table_name, ".csv")),
                   col_types = specs[[table_name]], na = c("", "NA", "?"),
                   progress = FALSE, show_col_types = FALSE)
  tables[[table_name]] <- data
  parser_n <- add_parser_counts(table_name, data)
  add_schema(table_name, data)
  audit$counts <- bind_rows(audit$counts, tibble(
    table = table_name, rows = as.double(nrow(data)), columns = ncol(data),
    parser_problems = as.double(parser_n),
    bytes = as.double(file.info(file.path(raw_dir, paste0(table_name, ".csv")))$size)
  ))
}

course <- tables$courses
assess <- tables$assessments
sa <- tables$studentAssessment
info <- tables$studentInfo
reg <- tables$studentRegistration
resource <- tables$vle
module_columns <- c("code_module", "code_presentation")
student_columns <- c(module_columns, "id_student")
resource_columns <- c(module_columns, "id_site")

duplicate_n <- c(
  courses = add_duplicates("courses", course, module_columns),
  assessments = add_duplicates("assessments", assess, "id_assessment"),
  studentAssessment = add_duplicates("studentAssessment", sa, c("id_assessment", "id_student")),
  studentInfo = add_duplicates("studentInfo", info, student_columns),
  studentRegistration = add_duplicates("studentRegistration", reg, student_columns),
  vle = add_duplicates("vle", resource, resource_columns)
)
invisible(add_duplicates("vle", resource, "id_site"))

course_keys <- key_values(course, module_columns)
info_keys <- key_values(info, student_columns)
reg_keys <- key_values(reg, student_columns)
resource_keys <- key_values(resource, resource_columns)
for (table_name in c("assessments", "studentInfo", "studentRegistration", "vle")) {
  add_fk(table_name, "module-presentation exists in courses",
         key_values(tables[[table_name]], module_columns), course_keys)
}
add_fk("studentRegistration", "student-course exists in studentInfo", reg_keys, info_keys)
add_fk("studentInfo", "student-course exists in studentRegistration", info_keys, reg_keys)
add_fk("studentAssessment", "assessment exists in assessments", sa$id_assessment, assess$id_assessment)
add_fk("studentAssessment", "student exists in studentInfo", sa$id_student, info$id_student)
if (duplicate_n[["assessments"]] == 0) {
  matched <- match(sa$id_assessment, assess$id_assessment)
  mapped <- tibble(
    code_module = assess$code_module[matched],
    code_presentation = assess$code_presentation[matched], id_student = sa$id_student
  )
  add_fk("studentAssessment", "student-assessment course exists in studentRegistration",
         key_values(mapped, student_columns), reg_keys)
} else {
  add_check("studentAssessment", "student-assessment course exists in studentRegistration",
            nrow(sa), NA_real_, "Ambiguous assessment identifiers prevent this check.")
}
add_check("studentAssessment", "scores outside 0 to 100", sum(!is.na(sa$score)),
          sum(sa$score < 0 | sa$score > 100, na.rm = TRUE),
          "Only validity is checked; no score means, distributions or associations are computed.")
add_check("studentAssessment", "is_banked outside 0 or 1", sum(!is.na(sa$is_banked)),
          sum(!sa$is_banked %in% c(0L, 1L) & !is.na(sa$is_banked)))
add_check("assessments", "unknown assessment_type", sum(!is.na(assess$assessment_type)),
          sum(!assess$assessment_type %in% c("TMA", "CMA", "Exam") & !is.na(assess$assessment_type)))
add_check("studentRegistration", "withdrawal before registration", nrow(reg),
          sum(reg$date_unregistration < reg$date_registration, na.rm = TRUE))
add_check("courses", "nonpositive presentation length", nrow(course),
          sum(course$module_presentation_length <= 0, na.rm = TRUE))
add_check("studentInfo", "negative previous attempts", nrow(info),
          sum(info$num_of_prev_attempts < 0, na.rm = TRUE))

# The 10-million-row activity file is streamed. The callback retains counters,
# membership dictionaries from the small tables and one chunk, not full logs.
activity <- new.env(parent = emptyenv())
activity$rows <- 0
activity$missing <- setNames(rep(0, ncol(headers$studentVle)), names(headers$studentVle))
activity$parser <- 0
activity$bad_course <- 0
activity$bad_student <- 0
activity$bad_resource <- 0
activity$course_checked <- 0
activity$student_checked <- 0
activity$resource_checked <- 0
activity$negative_clicks <- 0
activity$missing_key <- 0
activity$within_chunk_duplicates <- 0
activity$within_chunk_exact_duplicates <- 0
activity$prototype <- NULL
callback <- SideEffectChunkCallback$new(function(chunk, pos) {
  activity$rows <- activity$rows + nrow(chunk)
  activity$missing <- activity$missing + vapply(chunk, function(x) sum(is.na(x)), 0)
  activity$parser <- activity$parser + add_parser_counts("studentVle", chunk)
  if (is.null(activity$prototype)) activity$prototype <- chunk[0, ]
  ck <- key_values(chunk, module_columns)
  sk <- key_values(chunk, student_columns)
  rk <- key_values(chunk, resource_columns)
  activity$course_checked <- activity$course_checked + sum(!is.na(ck))
  activity$student_checked <- activity$student_checked + sum(!is.na(sk))
  activity$resource_checked <- activity$resource_checked + sum(!is.na(rk))
  activity$bad_course <- activity$bad_course + sum(!ck[!is.na(ck)] %in% course_keys)
  activity$bad_student <- activity$bad_student + sum(!sk[!is.na(sk)] %in% reg_keys)
  activity$bad_resource <- activity$bad_resource + sum(!rk[!is.na(rk)] %in% resource_keys)
  activity$negative_clicks <- activity$negative_clicks + sum(chunk$sum_click < 0, na.rm = TRUE)
  keys <- key_values(chunk, c(student_columns, "id_site", "date"))
  activity$missing_key <- activity$missing_key + sum(is.na(keys))
  activity$within_chunk_duplicates <- activity$within_chunk_duplicates + sum(duplicated(keys[!is.na(keys)]))
  exact_keys <- key_values(chunk, names(chunk))
  activity$within_chunk_exact_duplicates <- activity$within_chunk_exact_duplicates +
    sum(duplicated(exact_keys[!is.na(exact_keys)]))
  invisible(NULL)
})
message("Streaming studentVle.csv in chunks of 100,000 rows...")
invisible(read_csv_chunked(
  file.path(raw_dir, "studentVle.csv"), callback = callback, chunk_size = 100000L,
  col_types = specs$studentVle, na = c("", "NA", "?"),
  progress = FALSE, show_col_types = FALSE
))
if (is.null(activity$prototype)) activity$prototype <- headers$studentVle
add_schema("studentVle", activity$prototype, activity$missing, activity$rows)
audit$counts <- bind_rows(audit$counts, tibble(
  table = "studentVle", rows = as.double(activity$rows),
  columns = ncol(headers$studentVle), parser_problems = as.double(activity$parser),
  bytes = as.double(file.info(file.path(raw_dir, "studentVle.csv"))$size)
))
add_check("studentVle", "module-presentation exists in courses", activity$course_checked,
          activity$bad_course)
add_check("studentVle", "student-course exists in studentRegistration", activity$student_checked,
          activity$bad_student)
add_check("studentVle", "resource-course exists in vle", activity$resource_checked,
          activity$bad_resource)
add_check("studentVle", "negative sum_click", activity$rows, activity$negative_clicks)
add_check("studentVle", "missing student-course-resource-day key", activity$rows,
          activity$missing_key)
add_check("studentVle", "repeated student-course-resource-day keys beyond first within chunks", activity$rows,
          activity$within_chunk_duplicates,
          "A lower bound. Repeated keys do not prove duplicated records; multiple source rows are retained, including rows with different click counts.")
add_check("studentVle", "exact complete rows repeated beyond first within chunks", activity$rows,
          activity$within_chunk_exact_duplicates,
          "A lower bound for non-missing complete rows. Exact matches are flagged, not silently removed; their provenance cannot be inferred from this audit.")
add_check("studentVle", "global student-course-resource-day duplicate certification",
          activity$rows, NA_real_,
          "Not performed in this memory-bounded audit; within-chunk checks cannot certify global uniqueness.")

schedule <- assess %>%
  left_join(course, by = module_columns) %>%
  arrange(code_module, code_presentation, date, id_assessment)
write_csv(schedule, file.path(out_dir, "assessment_schedule.csv"), na = "")
write_csv(arrange(audit$counts, table), file.path(out_dir, "table_counts.csv"), na = "")
write_csv(arrange(audit$schema, table, column), file.path(out_dir, "schema_missingness.csv"), na = "")
write_csv(audit$checks, file.path(out_dir, "integrity_checks.csv"), na = "")
parser_counts <- audit$parser %>% group_by(table, column) %>%
  summarise(problems = sum(problems), .groups = "drop")
write_csv(parser_counts, file.path(out_dir, "parser_problem_counts.csv"), na = "")
writeLines(capture.output(sessionInfo()), file.path(out_dir, "session_info.txt"))

notes <- c(
  "SCOPE: Aggregate data availability, schema, integrity and schedule audit only.",
  "No grade averages, grade distributions, indicator-outcome associations, models or activity metrics are computed.",
  "No student identifiers, row-level score values or parser examples are exported.",
  "No duplicates are silently dropped. Any duplicate small-table key blocks candidate coverage.",
  "studentVle is read in 100,000-row chunks; repeated-key and exact-row counts are within-chunk lower bounds, not global certification.",
  "Repeated student-course-resource-day keys can have different click counts. Key repetition alone is not proof of duplicated records.",
  "Missingness includes blank, NA and ? tokens. Parser failures are reported separately.",
  "SCHEDULE: Prior assessment = latest scheduled TMA strictly before landmark; target = earliest scheduled TMA strictly after it.",
  "Tied scheduled TMAs are flagged as ambiguous; an arbitrary assessment is never selected.",
  "SNAPSHOT: Registration date <= landmark; withdrawal absent or strictly > landmark.",
  "PRIOR VALIDITY: Chosen prior TMA has a non-banked record, submission date strictly < landmark and a valid non-missing score.",
  "TARGET TEMPORAL RULE: A chosen target already submitted on or before landmark is excluded conservatively because dates have day-level resolution.",
  "A recorded target with unknown submission date or banked status, or banked = 1, is excluded from provisional temporal eligibility.",
  "An absent target record is retained in provisional eligibility; target submission and score availability are counted separately.",
  "Future withdrawals are counted but not used to restrict the snapshot cohort.",
  "Missing prior reasons can overlap; target missing-score counts apply to recorded future submissions, not absent submissions.",
  "Scores have submission dates, not grading timestamps; prior score adjustment is retrospective, not a claim of live availability.",
  "Candidate coverage is not a final cohort definition. Freeze a window using schedules, temporal validity and availability before analysing relationships.",
  "Raw directory is supplied at runtime; file provenance is recorded by the separate download script."
)

blocking_tables <- c("courses", "assessments", "studentAssessment", "studentInfo", "studentRegistration", "vle")
blocking_parser <- sum(audit$counts$parser_problems[audit$counts$table %in% blocking_tables])
blocking_missing <- audit$checks %>%
  filter(table %in% blocking_tables, grepl("^missing key:", check), failures > 0)
if (any(duplicate_n > 0) || blocking_parser > 0 || nrow(blocking_missing) > 0) {
  writeLines(c(notes, "COVERAGE NOT COMPUTED: Resolve duplicate keys, missing keys or parser problems in the small tables first."),
             file.path(out_dir, "audit_notes.txt"))
  stop("Aggregate audit written. Small-table integrity problems block unambiguous coverage counts.", call. = FALSE)
}

landmarks <- c(28L, 42L, 56L, 70L)
coverage <- list()
index <- 0L
for (course_row in seq_len(nrow(course))) {
  module <- course$code_module[[course_row]]
  presentation <- course$code_presentation[[course_row]]
  scheduled <- assess %>% filter(code_module == module, code_presentation == presentation,
                                 assessment_type == "TMA", !is.na(date))
  registered <- reg %>% filter(code_module == module, code_presentation == presentation)
  for (landmark in landmarks) {
    prior_options <- scheduled %>% filter(date < landmark)
    future_options <- scheduled %>% filter(date > landmark)
    prior <- if (nrow(prior_options)) prior_options %>% filter(date == max(date)) else prior_options
    target <- if (nrow(future_options)) future_options %>% filter(date == min(date)) else future_options
    snapshot <- registered %>% filter(!is.na(date_registration), date_registration <= landmark,
                                      is.na(date_unregistration) | date_unregistration > landmark)
    row <- list(
      code_module = module, code_presentation = presentation, landmark_day = landmark,
      module_presentation_length = course$module_presentation_length[[course_row]],
      prior_tma_id = if (nrow(prior) == 1L) prior$id_assessment[[1L]] else NA_integer_,
      prior_tma_day = if (nrow(prior)) prior$date[[1L]] else NA_integer_,
      target_tma_id = if (nrow(target) == 1L) target$id_assessment[[1L]] else NA_integer_,
      target_tma_day = if (nrow(target)) target$date[[1L]] else NA_integer_,
      prior_tma_tie_count = nrow(prior), target_tma_tie_count = nrow(target),
      tmas_scheduled_on_landmark = sum(scheduled$date == landmark),
      schedule_status = if (nrow(prior) != 1L || nrow(target) != 1L) "missing_or_ambiguous" else "usable_pair",
      n_registration_records = nrow(registered),
      n_missing_registration_date = sum(is.na(registered$date_registration)),
      n_registered_by_landmark = sum(registered$date_registration <= landmark, na.rm = TRUE),
      n_withdrawn_by_landmark = sum(registered$date_unregistration <= landmark, na.rm = TRUE),
      n_snapshot_eligible = nrow(snapshot)
    )
    stage_columns <- c(
      "n_prior_record_absent", "n_prior_missing_score", "n_prior_invalid_score",
      "n_prior_missing_submission_date", "n_prior_submitted_on_or_after_landmark",
      "n_prior_banked", "n_prior_missing_banked_status", "n_prior_valid",
      "n_target_record_absent_in_prior_valid", "n_target_already_submitted_in_prior_valid",
      "n_target_banked_in_prior_valid", "n_target_missing_banked_status_in_prior_valid",
      "n_target_missing_submission_date_in_prior_valid", "n_provisional_temporally_eligible",
      "n_target_record_absent_in_provisional", "n_target_future_submissions_in_provisional",
      "n_target_missing_score_among_future_submissions", "n_target_invalid_score_among_future_submissions",
      "n_target_valid_score_among_future_submissions", "n_withdrawn_after_landmark_by_target_deadline_in_provisional",
      "n_withdrawn_anytime_after_landmark_in_provisional"
    )
    for (column in stage_columns) row[[column]] <- NA_integer_
    if (nrow(prior) == 1L && nrow(target) == 1L) {
      prior_records <- sa %>% filter(id_assessment == prior$id_assessment[[1L]]) %>%
        transmute(id_student, prior_record_present = TRUE, prior_date = date_submitted,
                  prior_banked = is_banked, prior_score = score)
      target_records <- sa %>% filter(id_assessment == target$id_assessment[[1L]]) %>%
        transmute(id_student, target_record_present = TRUE, target_date = date_submitted,
                  target_banked = is_banked, target_score = score)
      joined <- snapshot %>% left_join(prior_records, by = "id_student") %>%
        left_join(target_records, by = "id_student")
      prior_present <- !is.na(joined$prior_record_present)
      row$n_prior_record_absent <- sum(!prior_present)
      row$n_prior_missing_score <- sum(prior_present & is.na(joined$prior_score))
      row$n_prior_invalid_score <- sum(prior_present &
                                       (joined$prior_score < 0 | joined$prior_score > 100), na.rm = TRUE)
      row$n_prior_missing_submission_date <- sum(prior_present & is.na(joined$prior_date))
      row$n_prior_submitted_on_or_after_landmark <- sum(prior_present & joined$prior_date >= landmark, na.rm = TRUE)
      row$n_prior_banked <- sum(prior_present & joined$prior_banked == 1L, na.rm = TRUE)
      row$n_prior_missing_banked_status <- sum(prior_present & is.na(joined$prior_banked))
      prior_valid <- joined %>% filter(prior_record_present == TRUE, prior_banked == 0L,
                                       prior_date < landmark, !is.na(prior_score),
                                       prior_score >= 0, prior_score <= 100)
      row$n_prior_valid <- nrow(prior_valid)
      target_present <- !is.na(prior_valid$target_record_present)
      already <- target_present & !is.na(prior_valid$target_date) & prior_valid$target_date <= landmark
      banked <- target_present & !is.na(prior_valid$target_banked) & prior_valid$target_banked != 0L
      unknown_bank <- target_present & is.na(prior_valid$target_banked)
      unknown_date <- target_present & is.na(prior_valid$target_date)
      row$n_target_record_absent_in_prior_valid <- sum(!target_present)
      row$n_target_already_submitted_in_prior_valid <- sum(already)
      row$n_target_banked_in_prior_valid <- sum(banked)
      row$n_target_missing_banked_status_in_prior_valid <- sum(unknown_bank)
      row$n_target_missing_submission_date_in_prior_valid <- sum(unknown_date)
      provisional <- prior_valid[!(already | banked | unknown_bank | unknown_date), ]
      row$n_provisional_temporally_eligible <- nrow(provisional)
      present <- !is.na(provisional$target_record_present)
      row$n_target_record_absent_in_provisional <- sum(!present)
      row$n_target_future_submissions_in_provisional <- sum(present)
      row$n_target_missing_score_among_future_submissions <- sum(present & is.na(provisional$target_score))
      row$n_target_invalid_score_among_future_submissions <- sum(present &
        (provisional$target_score < 0 | provisional$target_score > 100), na.rm = TRUE)
      row$n_target_valid_score_among_future_submissions <- sum(present & !is.na(provisional$target_score) &
        provisional$target_score >= 0 & provisional$target_score <= 100)
      row$n_withdrawn_after_landmark_by_target_deadline_in_provisional <- sum(
        provisional$date_unregistration > landmark & provisional$date_unregistration <= target$date[[1L]],
        na.rm = TRUE)
      row$n_withdrawn_anytime_after_landmark_in_provisional <- sum(provisional$date_unregistration > landmark,
                                                               na.rm = TRUE)
    }
    index <- index + 1L
    coverage[[index]] <- as_tibble(row)
  }
}
write_csv(bind_rows(coverage), file.path(out_dir, "landmark_candidate_coverage.csv"), na = "")

# A separate schedule-aware variant provides baseline attainment before the
# activity window, not merely before the landmark. It does not replace the
# original end-of-day snapshot audit above. Here the cutoff begins day L.
window_coverage <- list()
index <- 0L
for (course_row in seq_len(nrow(course))) {
  module <- course$code_module[[course_row]]
  presentation <- course$code_presentation[[course_row]]
  scheduled <- assess %>% filter(code_module == module, code_presentation == presentation,
                                 assessment_type == "TMA", !is.na(date))
  registered <- reg %>% filter(code_module == module, code_presentation == presentation)
  for (landmark in landmarks) {
    window_start <- landmark - 14L
    prior_options <- scheduled %>% filter(date < window_start)
    future_options <- scheduled %>% filter(date > landmark, !is.na(weight), weight > 0)
    prior <- if (nrow(prior_options)) prior_options %>% filter(date == max(date)) else prior_options
    target <- if (nrow(future_options)) future_options %>% filter(date == min(date)) else future_options
    snapshot <- registered %>% filter(!is.na(date_registration), date_registration < landmark,
                                      is.na(date_unregistration) | date_unregistration >= landmark)
    row <- list(
      code_module = module, code_presentation = presentation, landmark_day = landmark,
      activity_window_start_day = window_start, activity_window_end_day = landmark - 1L,
      prior_tma_id = if (nrow(prior) == 1L) prior$id_assessment[[1L]] else NA_integer_,
      prior_tma_day = if (nrow(prior)) prior$date[[1L]] else NA_integer_,
      prior_tma_weight = if (nrow(prior) == 1L) prior$weight[[1L]] else NA_real_,
      target_tma_id = if (nrow(target) == 1L) target$id_assessment[[1L]] else NA_integer_,
      target_tma_day = if (nrow(target)) target$date[[1L]] else NA_integer_,
      target_tma_weight = if (nrow(target) == 1L) target$weight[[1L]] else NA_real_,
      prior_tma_tie_count = nrow(prior), target_tma_tie_count = nrow(target),
      schedule_status = if (nrow(prior) != 1L || nrow(target) != 1L) "missing_or_ambiguous" else "usable_pair",
      n_snapshot_eligible = nrow(snapshot),
      n_registrations_on_landmark = sum(registered$date_registration == landmark, na.rm = TRUE),
      n_withdrawals_on_landmark_in_snapshot = sum(snapshot$date_unregistration == landmark, na.rm = TRUE)
    )
    stage_columns <- c(
      "n_prior_record_absent", "n_prior_missing_score", "n_prior_invalid_score",
      "n_prior_missing_submission_date", "n_prior_submitted_on_or_after_window_start",
      "n_prior_banked", "n_prior_missing_banked_status", "n_prior_valid_before_window",
      "n_target_record_absent_in_prior_valid", "n_target_submitted_before_landmark_in_prior_valid",
      "n_target_banked_in_prior_valid", "n_target_missing_banked_status_in_prior_valid",
      "n_target_missing_submission_date_in_prior_valid", "n_provisional_temporally_eligible",
      "n_target_record_absent_in_provisional", "n_target_submitted_on_or_after_landmark_in_provisional",
      "n_target_missing_score_among_future_submissions", "n_target_invalid_score_among_future_submissions",
      "n_target_valid_score_among_future_submissions", "n_withdrawn_on_or_after_landmark_by_target_deadline_in_provisional",
      "n_withdrawn_anytime_on_or_after_landmark_in_provisional"
    )
    for (column in stage_columns) row[[column]] <- NA_integer_
    if (nrow(prior) == 1L && nrow(target) == 1L) {
      prior_records <- sa %>% filter(id_assessment == prior$id_assessment[[1L]]) %>%
        transmute(id_student, prior_record_present = TRUE, prior_date = date_submitted,
                  prior_banked = is_banked, prior_score = score)
      target_records <- sa %>% filter(id_assessment == target$id_assessment[[1L]]) %>%
        transmute(id_student, target_record_present = TRUE, target_date = date_submitted,
                  target_banked = is_banked, target_score = score)
      joined <- snapshot %>% left_join(prior_records, by = "id_student") %>%
        left_join(target_records, by = "id_student")
      prior_present <- !is.na(joined$prior_record_present)
      row$n_prior_record_absent <- sum(!prior_present)
      row$n_prior_missing_score <- sum(prior_present & is.na(joined$prior_score))
      row$n_prior_invalid_score <- sum(prior_present &
        (joined$prior_score < 0 | joined$prior_score > 100), na.rm = TRUE)
      row$n_prior_missing_submission_date <- sum(prior_present & is.na(joined$prior_date))
      row$n_prior_submitted_on_or_after_window_start <- sum(prior_present & joined$prior_date >= window_start,
                                                           na.rm = TRUE)
      row$n_prior_banked <- sum(prior_present & joined$prior_banked == 1L, na.rm = TRUE)
      row$n_prior_missing_banked_status <- sum(prior_present & is.na(joined$prior_banked))
      prior_valid <- joined %>% filter(prior_record_present == TRUE, prior_banked == 0L,
        prior_date < window_start, !is.na(prior_score), prior_score >= 0, prior_score <= 100)
      row$n_prior_valid_before_window <- nrow(prior_valid)
      present <- !is.na(prior_valid$target_record_present)
      already <- present & !is.na(prior_valid$target_date) & prior_valid$target_date < landmark
      banked <- present & !is.na(prior_valid$target_banked) & prior_valid$target_banked != 0L
      unknown_bank <- present & is.na(prior_valid$target_banked)
      unknown_date <- present & is.na(prior_valid$target_date)
      row$n_target_record_absent_in_prior_valid <- sum(!present)
      row$n_target_submitted_before_landmark_in_prior_valid <- sum(already)
      row$n_target_banked_in_prior_valid <- sum(banked)
      row$n_target_missing_banked_status_in_prior_valid <- sum(unknown_bank)
      row$n_target_missing_submission_date_in_prior_valid <- sum(unknown_date)
      provisional <- prior_valid[!(already | banked | unknown_bank | unknown_date), ]
      row$n_provisional_temporally_eligible <- nrow(provisional)
      present <- !is.na(provisional$target_record_present)
      row$n_target_record_absent_in_provisional <- sum(!present)
      row$n_target_submitted_on_or_after_landmark_in_provisional <- sum(present)
      row$n_target_missing_score_among_future_submissions <- sum(present & is.na(provisional$target_score))
      row$n_target_invalid_score_among_future_submissions <- sum(present &
        (provisional$target_score < 0 | provisional$target_score > 100), na.rm = TRUE)
      row$n_target_valid_score_among_future_submissions <- sum(present & !is.na(provisional$target_score) &
        provisional$target_score >= 0 & provisional$target_score <= 100)
      row$n_withdrawn_on_or_after_landmark_by_target_deadline_in_provisional <- sum(
        provisional$date_unregistration >= landmark & provisional$date_unregistration <= target$date[[1L]],
        na.rm = TRUE)
      row$n_withdrawn_anytime_on_or_after_landmark_in_provisional <- sum(
        provisional$date_unregistration >= landmark, na.rm = TRUE)
    }
    index <- index + 1L
    window_coverage[[index]] <- as_tibble(row)
  }
}
write_csv(bind_rows(window_coverage), file.path(out_dir, "landmark_window_candidate_coverage.csv"), na = "")
notes <- c(notes,
  "WINDOW VARIANT: landmark_window_candidate_coverage.csv is a separate 14-day-window audit, not the original snapshot definition.",
  "Its cutoff begins landmark day L; the activity window is L-14 through L-1 inclusive.",
  "Its prior is the latest scheduled TMA due strictly before the activity window, with actual non-banked scored submission also before that window.",
  "Its target is the first positive-weight scheduled TMA due strictly after L; zero/missing target weights are not eligible.",
  "Its snapshot requires registration before L and no withdrawal before L. Withdrawals on L are counted explicitly.",
  "Its target is excluded if submitted before L; submission on L is allowed, preserving separation from activity through L-1.",
  "Missing/banked target status exclusions and retained absent submissions follow the same availability logic as the original audit."
)
writeLines(notes, file.path(out_dir, "audit_notes.txt"))
message("Audit complete: ", nrow(audit$counts), " tables and ", length(coverage),
        " original plus ", length(window_coverage), " window-separated schedule candidates. Outputs: ", out_dir)
