#!/usr/bin/env python3
"""Acquire the unmodified public OULAD release and record local provenance."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import shutil
import ssl
import subprocess
import urllib.error
import urllib.request
import zipfile

SOURCE = "https://archive.ics.uci.edu/static/public/349/open+university+learning+analytics+dataset.zip"
EXPECTED = {
    "assessments.csv", "courses.csv", "studentAssessment.csv", "studentInfo.csv",
    "studentRegistration.csv", "studentVle.csv", "vle.csv",
}


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    archive = args.data_dir / "oulad-uci.zip"
    if not archive.exists():
        temporary = archive.with_suffix(".zip.part")
        request = urllib.request.Request(SOURCE, headers={"User-Agent": "OULAD-portfolio-research/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=60) as response, temporary.open("wb") as target:
                shutil.copyfileobj(response, target)
        except urllib.error.URLError as error:
            if not isinstance(error.reason, ssl.SSLCertVerificationError):
                raise
            # macOS Python installs may lack a CA bundle. Use the system client's
            # verified trust store; never disable certificate verification.
            print("Using system HTTPS client with certificate verification.", flush=True)
            subprocess.run([
                "curl", "--fail", "--location", "--retry", "2",
                "--connect-timeout", "30", "--max-time", "180",
                "--silent", "--show-error", "--output", str(temporary), SOURCE,
            ], check=True)
        if not zipfile.is_zipfile(temporary):
            raise RuntimeError("The source did not return a ZIP archive; no extraction performed.")
        temporary.replace(archive)
        print(f"Downloaded official release: {archive.stat().st_size:,} bytes", flush=True)
    raw = args.data_dir / "raw"
    raw.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError("Archive CRC validation failed.")
        members = {Path(item.filename).name: item for item in bundle.infolist() if not item.is_dir()}
        if not EXPECTED.issubset(members):
            raise RuntimeError(f"Missing expected tables: {sorted(EXPECTED.difference(members))}")
        for name in sorted(EXPECTED | ({"OULAD.names"} & members.keys())):
            # Extract only known basenames; never trust archive paths.
            destination = raw / name
            with bundle.open(members[name]) as source, destination.open("wb") as target:
                shutil.copyfileobj(source, target)
    files = [{"name": path.name, "bytes": path.stat().st_size, "sha256": digest(path)}
             for path in sorted(raw.iterdir()) if path.is_file()]
    manifest = {
        "dataset": "Open University Learning Analytics Dataset (OULAD)",
        "retrieval_record_utc": datetime.now(timezone.utc).isoformat(),
        "retrieval_record_note": "UTC clock timestamp from execution environment; client project date is 2026-10-03.",
        "source_url": SOURCE,
        "source_page": "https://archive.ics.uci.edu/dataset/349/open+university+learning+analytics+dataset",
        "license": "CC BY 4.0",
        "attribution": "Kuzilek, J., Hlosta, M., & Zdrahal, Z. (2015). Open University Learning Analytics dataset. UCI Machine Learning Repository. https://doi.org/10.24432/C5KK69",
        "archive_sha256": digest(archive),
        "archive_bytes": archive.stat().st_size,
        "files": files,
        "transformations": "None. Known files extracted byte-for-byte from official archive.",
    }
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(f"Verified {len(EXPECTED)} tables; provenance saved to {args.manifest}", flush=True)


if __name__ == "__main__":
    main()
