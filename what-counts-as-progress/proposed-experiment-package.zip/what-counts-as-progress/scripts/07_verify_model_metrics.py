#!/usr/bin/env python3
"""Independent least-squares reconstruction of R-reported errors, not model tuning."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--project-dir", type=Path, required=True)
    args = parser.parse_args()
    results_dir = args.project_dir / "results"
    checks = []
    main_results = pd.read_csv(results_dir / "primary-model-metrics.csv")
    robustness = pd.read_csv(results_dir / "within-cohort-robustness.csv")
    timing = pd.read_csv(results_dir / "timing-model-comparison.csv")
    scenarios = [("primary", args.data_dir / "derived"),
                 ("window28", args.data_dir / "sensitivity-window28"),
                 ("cutoff70", args.data_dir / "sensitivity-cutoff70")]
    keys = ["code_module", "code_presentation", "id_student"]
    for scenario, folder in scenarios:
        development = pd.read_csv(folder / "development.csv")
        features = pd.read_csv(folder / "evaluation-features.csv")
        outcomes = pd.read_csv(folder / "evaluation-outcomes.csv")
        assert not set(development.id_student) & set(features.id_student)
        assert "target_score" not in features
        evaluation = features.merge(outcomes, on=keys, validate="one_to_one")
        variants = ["main"] if scenario != "primary" else ["main", "zero_weight_prior_excluded",
            "cutoff_day_withdrawal_excluded", "quadratic_terms", "exact_full_row_unique_volume"]
        for variant in variants:
            dev = development.copy()
            ev = evaluation.copy()
            if variant == "zero_weight_prior_excluded":
                dev = dev.loc[dev.prior_weight > 0]
                ev = ev.loc[ev.prior_weight > 0]
            if variant == "cutoff_day_withdrawal_excluded":
                dev = dev.loc[dev.withdrawal_day.isna() | dev.withdrawal_day.ne(56)]
                ev = ev.loc[ev.withdrawal_day.isna() | ev.withdrawal_day.ne(56)]
            dev = dev.loc[dev.target_score.notna()]
            ev = ev.loc[ev.target_score.notna()]
            levels = sorted(dev.course_offering.unique())
            assert set(ev.course_offering) <= set(levels)
            maes = {}
            for model in ["reference", "volume", "consistency", "combined_secondary"]:
                def design(frame):
                    columns = [np.ones(len(frame)), frame.prior_score.to_numpy()]
                    if variant == "quadratic_terms":
                        columns.append(frame.prior_score.to_numpy() ** 2)
                    columns += [frame.course_offering.eq(level).to_numpy(dtype=float) for level in levels[1:]]
                    if model in ("volume", "combined_secondary"):
                        name = "total_clicks_exact_row_unique_sensitivity" if variant == "exact_full_row_unique_volume" else "total_clicks"
                        volume = np.log1p(frame[name].to_numpy())
                        columns.append(volume)
                        if variant == "quadratic_terms": columns.append(volume ** 2)
                    if model in ("consistency", "combined_secondary"):
                        days = frame.active_days.to_numpy()
                        columns.append(days)
                        if variant == "quadratic_terms": columns.append(days ** 2)
                    return np.column_stack(columns)
                matrix = design(dev)
                coefficients, _, rank, _ = np.linalg.lstsq(matrix, dev.target_score.to_numpy(), rcond=None)
                assert rank == matrix.shape[1]
                prediction = design(ev) @ coefficients
                mae = float(np.mean(np.abs(prediction - ev.target_score.to_numpy())))
                maes[model] = mae
                if scenario == "primary" and variant == "main":
                    expected_row = main_results.loc[main_results.model.eq(model)].iloc[0]
                    expected = float(expected_row.mae)
                    assert len(ev) == int(expected_row.n_enrollments)
                elif scenario == "primary":
                    match = robustness.loc[robustness.sensitivity.eq(variant)]
                    expected = float(match.reference_mae.iloc[0] if model == "reference" else match.loc[match.model.eq(model), "model_mae"].iloc[0])
                    assert len(dev) == int(match.development_observed.iloc[0])
                    assert len(ev) == int(match.n_enrollments.iloc[0])
                else:
                    r_model = "combined" if model == "combined_secondary" else model
                    expected_row = timing.loc[timing.scenario.eq(scenario) & timing.model.eq(r_model)].iloc[0]
                    expected = float(expected_row.mae)
                    assert len(dev) == int(expected_row.observed_development)
                    assert len(ev) == int(expected_row.observed_evaluation)
                difference = abs(mae - expected)
                assert difference < 1e-8, (scenario, variant, model, difference)
                checks.append({"scenario": scenario, "variant": variant, "model": model,
                               "observed_development": len(dev), "observed_evaluation": len(ev),
                               "independent_mae": mae, "absolute_difference_from_R": difference})
            if variant == "main":
                print(f"{scenario}: independently verified reference MAE {maes['reference']:.6f}, volume MAE {maes['volume']:.6f}")
    # Secondary transport check: independently reconstruct transferable module effects.
    latest_path = results_dir / "latest-offering-model-metrics.csv"
    if latest_path.exists():
        expected_rows = pd.read_csv(latest_path)
        folder = args.data_dir / "derived"
        dev_all = pd.read_csv(folder / "development.csv")
        features = pd.read_csv(folder / "evaluation-features.csv")
        outcomes = pd.read_csv(folder / "evaluation-outcomes.csv")
        dev = dev_all.loc[dev_all.code_presentation.isin(["2013B", "2013J", "2014B"]) & dev_all.target_score.notna()]
        ev = features.merge(outcomes, on=keys, validate="one_to_one")
        ev = ev.loc[ev.code_presentation.eq("2014J") & ev.target_score.notna()]
        assert not set(dev.id_student) & set(ev.id_student)
        assert len(dev) == 8911 and len(ev) == 1189
        levels = sorted(dev.code_module.unique())
        assert set(ev.code_module) == set(levels)
        for model in ["reference", "volume", "consistency", "combined_secondary"]:
            def design_latest(frame):
                columns = [np.ones(len(frame)), frame.prior_score.to_numpy()]
                columns += [frame.code_module.eq(level).to_numpy(dtype=float) for level in levels[1:]]
                if model in ("volume", "combined_secondary"): columns.append(np.log1p(frame.total_clicks.to_numpy()))
                if model in ("consistency", "combined_secondary"): columns.append(frame.active_days.to_numpy())
                return np.column_stack(columns)
            matrix = design_latest(dev)
            coefficients, _, rank, _ = np.linalg.lstsq(matrix, dev.target_score.to_numpy(), rcond=None)
            assert rank == matrix.shape[1]
            mae = float(np.mean(np.abs(design_latest(ev) @ coefficients - ev.target_score.to_numpy())))
            expected = expected_rows.loc[expected_rows.model.eq(model)].iloc[0]
            difference = abs(mae - float(expected.mae))
            assert difference < 1e-8 and len(ev) == int(expected.n_enrollments)
            checks.append({"scenario": "latest_offering_secondary", "variant": "module_effects", "model": model,
                "observed_development": len(dev), "observed_evaluation": len(ev),
                "independent_mae": mae, "absolute_difference_from_R": difference})
        print("latest-offering secondary: independently verified all four MAEs")
    pd.DataFrame(checks).to_csv(results_dir / "independent-metric-verification.csv", index=False)
    config = args.project_dir / "config" / "analysis-config.json"
    lock = json.loads((config.parent / "analysis-plan-lock.json").read_text())
    digest = hashlib.sha256(config.read_bytes()).hexdigest()
    # Keep the frozen-plan checksum separate from execution status.
    assert digest in json.dumps(lock), "Frozen analysis configuration changed."
    (results_dir / "independent-verification.json").write_text(json.dumps({
        "status": "passed", "least_squares_error_comparisons": len(checks),
        "tolerance": 1e-8, "max_absolute_mae_difference": max(c["absolute_difference_from_R"] for c in checks),
        "frozen_config_sha256": digest,
        "scope": "Independent NumPy least-squares reconstruction; checks MAEs, evaluation counts, sensitivity-development counts, full-rank fits and learner separation. Bootstrap reviewed separately; not reproduced by this script."
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
