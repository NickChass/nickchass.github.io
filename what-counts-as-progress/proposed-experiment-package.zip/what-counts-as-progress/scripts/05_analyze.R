#!/usr/bin/env Rscript
# Execute the frozen v0.2 comparison. Evaluation outcomes are read only after
# every main and within-cohort robustness model has been fitted and saved.
# Usage: Rscript 05_analyze.R DERIVED_DIRECTORY RESULTS_DIRECTORY

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(ggplot2)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 05_analyze.R DERIVED_DIRECTORY RESULTS_DIRECTORY", call. = FALSE)
derived_dir <- normalizePath(args[[1L]], mustWork = TRUE)
results_dir <- args[[2L]]
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
results_dir <- normalizePath(results_dir, mustWork = TRUE)
script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (length(script_arg) != 1L) stop("Run this script with Rscript so its frozen configuration can be located.")
script_path <- normalizePath(sub("^--file=", "", script_arg), mustWork = TRUE)
project_dir <- dirname(dirname(script_path))
config_path <- file.path(project_dir, "config", "analysis-config.json")
config_lines <- readLines(config_path, warn = FALSE)

# The project's scalar/formula entries occupy individual JSON lines. This
# deliberately strict reader avoids adding a JSON dependency and rejects
# ambiguous/multiline entries rather than silently interpreting another plan.
config_scalar <- function(name) {
  line <- grep(paste0('^[[:space:]]*"', name, '"[[:space:]]*:'), config_lines, value = TRUE)
  if (length(line) != 1L) stop("Ambiguous or absent frozen configuration field: ", name)
  value <- trimws(sub('^[^:]*:', '', line))
  value <- sub(',[[:space:]]*$', '', value)
  if (grepl('^".*"$', value)) value <- substr(value, 2L, nchar(value) - 1L)
  value
}
stopifnot(config_scalar("version") == "0.2")
cutoff <- as.integer(config_scalar("cutoff_day"))
window_start <- as.integer(config_scalar("activity_start_day"))
window_end <- as.integer(config_scalar("activity_end_day_exclusive"))
stopifnot(cutoff == 56L, window_start == 42L, window_end == cutoff)
replicates <- 2000L
bootstrap_seed <- 20261003L
if (!grepl("2000 replicates,seed20261003", config_scalar("uncertainty"), fixed = TRUE)) {
  stop("Bootstrap specification does not match the frozen plan.")
}

formula_text <- c(
  reference = "target_score ~ prior_score + course_offering",
  volume = "target_score ~ prior_score + course_offering + log1p(total_clicks)",
  consistency = "target_score ~ prior_score + course_offering + active_days",
  combined_secondary = "target_score ~ prior_score + course_offering + log1p(total_clicks) + active_days"
)
for (name in names(formula_text)) stopifnot(config_scalar(name) == formula_text[[name]])
main_formulas <- lapply(formula_text, as.formula)
model_names <- names(main_formulas)
model_labels <- c(reference = "Prior mark + course offering", volume = "+ Activity volume",
                  consistency = "+ Active days", combined_secondary = "+ Both indicators")
allowed_predictors <- c("prior_score", "course_offering", "total_clicks", "active_days",
                        "total_clicks_exact_row_unique_sensitivity")
keys <- c("code_module", "code_presentation", "id_student")
future_columns <- c("target_score", "target_submission_day", "target_submitted",
                    "target_score_observed", "withdrawal_day")
feature_spec <- cols(
  .default = col_character(), code_module = col_character(), code_presentation = col_character(),
  id_student = col_character(), course_offering = col_character(),
  prior_deadline = col_double(), prior_weight = col_double(), prior_submission_day = col_double(),
  prior_score = col_double(), target_deadline = col_double(), target_weight = col_double(),
  total_clicks = col_double(), active_days = col_integer(),
  total_clicks_exact_row_unique_sensitivity = col_double(),
  target_submission_day = col_double(), target_submitted = col_integer(),
  target_score_observed = col_integer(), target_score = col_double(), withdrawal_day = col_double()
)
read_checked <- function(path) {
  header <- read_csv(path, n_max = 0L, col_types = cols(.default = col_character()),
                     show_col_types = FALSE, progress = FALSE)
  present_spec <- do.call(cols, c(feature_spec$cols[intersect(names(feature_spec$cols), names(header))],
                                 list(.default = col_character())))
  data <- read_csv(path, col_types = present_spec, na = c("", "NA", "?"),
                   show_col_types = FALSE, progress = FALSE)
  if (nrow(problems(data))) stop("Parser failures in ", path)
  data
}
key_values <- function(data) do.call(paste, c(as.list(data[, keys]), sep = "\u001f"))
check_features <- function(data, expected_partition) {
  required <- c(keys, allowed_predictors, "partition", "prior_weight", "prior_submission_day")
  if (!all(required %in% names(data))) stop("Required feature columns are absent.")
  stopifnot(!anyNA(data[, required]), !anyDuplicated(key_values(data)),
            all(data$partition == expected_partition),
            all(data$prior_submission_day < window_start),
            all(data$prior_score >= 0 & data$prior_score <= 100),
            all(data$total_clicks >= 0),
            all(data$total_clicks_exact_row_unique_sensitivity >= 0),
            all(data$total_clicks_exact_row_unique_sensitivity <= data$total_clicks),
            all(data$active_days >= 0 & data$active_days <= cutoff - window_start),
            all(data$course_offering == paste(data$code_module, data$code_presentation, sep = "_")))
}
check_outcomes <- function(data) {
  stopifnot(all(is.na(data$target_submission_day) | data$target_submission_day >= cutoff),
            all(is.na(data$target_score) | (data$target_score >= 0 & data$target_score <= 100)),
            all(data$target_score_observed == as.integer(!is.na(data$target_score))),
            all(data$target_submitted %in% c(0L, 1L)),
            all(data$target_score_observed <= data$target_submitted),
            all(data$target_submitted == as.integer(!is.na(data$target_submission_day))))
}

development <- read_checked(file.path(derived_dir, "development.csv"))
evaluation_features <- read_checked(file.path(derived_dir, "evaluation-features.csv"))
check_features(development, "development")
check_features(evaluation_features, "evaluation")
check_outcomes(development)
stopifnot(!any(future_columns %in% names(evaluation_features)),
          !length(intersect(unique(development$id_student), unique(evaluation_features$id_student))),
          all(unique(evaluation_features$course_offering) %in% unique(development$course_offering)))
offering_levels <- sort(unique(development$course_offering))
development$course_offering <- factor(development$course_offering, levels = offering_levels)
evaluation_features$course_offering <- factor(evaluation_features$course_offering, levels = offering_levels)

fit_models <- function(data, formulas) {
  observed <- data %>% filter(!is.na(target_score))
  if (nrow(observed) < 50L) stop("Insufficient observed development marks for a planned fit.")
  fitted <- lapply(formulas, function(formula) {
    columns <- all.vars(formula)
    if (!all(columns %in% c("target_score", allowed_predictors))) stop("A model contains a prohibited predictor.")
    frame <- as.data.frame(observed[, columns, drop = FALSE])
    if (anyNA(frame)) stop("Missing model predictors in development records.")
    lm(formula, data = frame, na.action = na.fail)
  })
  if (any(vapply(fitted, function(fit) anyNA(coef(fit)), FALSE))) stop("Rank-deficient planned model.")
  fitted
}
predict_models <- function(fitted, data) {
  predictions <- vapply(fitted, function(fit) {
    columns <- setdiff(all.vars(formula(fit)), "target_score")
    if (!all(columns %in% allowed_predictors)) stop("A prediction uses a prohibited input.")
    if (!all(as.character(data$course_offering) %in% fit$xlevels$course_offering)) {
      stop("An evaluation offering is absent from the corresponding fitted model.")
    }
    as.numeric(predict(fit, newdata = as.data.frame(data[, columns, drop = FALSE])))
  }, numeric(nrow(data)))
  if (any(!is.finite(predictions))) stop("Non-finite evaluation predictions.")
  predictions
}

quadratic_formulas <- list(
  reference = target_score ~ prior_score + I(prior_score^2) + course_offering,
  volume = target_score ~ prior_score + I(prior_score^2) + course_offering +
    log1p(total_clicks) + I(log1p(total_clicks)^2),
  consistency = target_score ~ prior_score + I(prior_score^2) + course_offering +
    active_days + I(active_days^2),
  combined_secondary = target_score ~ prior_score + I(prior_score^2) + course_offering +
    log1p(total_clicks) + I(log1p(total_clicks)^2) + active_days + I(active_days^2)
)
unique_volume_formulas <- list(
  reference = main_formulas$reference,
  volume = target_score ~ prior_score + course_offering + log1p(total_clicks_exact_row_unique_sensitivity),
  consistency = main_formulas$consistency,
  combined_secondary = target_score ~ prior_score + course_offering +
    log1p(total_clicks_exact_row_unique_sensitivity) + active_days
)
subset_rules <- list(
  zero_weight_prior_excluded = function(data) data$prior_weight > 0,
  cutoff_day_withdrawal_excluded = function(data) is.na(data$withdrawal_day) | data$withdrawal_day != cutoff,
  quadratic_terms = function(data) rep(TRUE, nrow(data)),
  exact_full_row_unique_volume = function(data) rep(TRUE, nrow(data))
)
sensitivity_formulas <- list(
  zero_weight_prior_excluded = main_formulas,
  cutoff_day_withdrawal_excluded = main_formulas,
  quadratic_terms = quadratic_formulas,
  exact_full_row_unique_volume = unique_volume_formulas
)
message("Fitting all frozen main and within-cohort robustness models on development marks...")
main_fits <- fit_models(development, main_formulas)
sensitivity_fits <- lapply(names(subset_rules), function(name) {
  fit_models(development[subset_rules[[name]](development), ], sensitivity_formulas[[name]])
})
names(sensitivity_fits) <- names(subset_rules)
model_dir <- file.path(dirname(derived_dir), "models")
dir.create(model_dir, recursive = TRUE, showWarnings = FALSE)
model_path <- file.path(model_dir, "primary-frozen-models.rds")
saveRDS(list(main = main_fits, sensitivities = sensitivity_fits,
             config_version = "0.2", config_md5 = unname(tools::md5sum(config_path)),
             bootstrap_seed = bootstrap_seed, bootstrap_replicates = replicates), model_path)

# This is the first access to reserved evaluation outcome values. Their use is
# now authorised for the frozen comparison; no model selection or tuning follows.
message("Models fixed and saved. Opening reserved evaluation outcomes for the planned comparison...")
evaluation_outcomes <- read_checked(file.path(derived_dir, "evaluation-outcomes.csv"))
stopifnot(all(c(keys, future_columns) %in% names(evaluation_outcomes)),
          !anyDuplicated(key_values(evaluation_outcomes)),
          setequal(key_values(evaluation_features), key_values(evaluation_outcomes)))
check_outcomes(evaluation_outcomes)
evaluation <- evaluation_features %>% left_join(evaluation_outcomes, by = keys)
stopifnot(nrow(evaluation) == nrow(evaluation_features), !anyNA(evaluation$target_score_observed))
evaluation_observed <- evaluation %>% filter(!is.na(target_score))

# Resample learners, retaining all of each selected learner's enrollments.
# Each replicate's denominator is its enrollment count, not its learner count.
cluster_bootstrap <- function(values, learners, seed = bootstrap_seed) {
  values <- as.matrix(values)
  sums <- rowsum(values, learners, reorder = FALSE)
  counts <- as.numeric(rowsum(matrix(1, nrow(values), 1), learners, reorder = FALSE))
  n_clusters <- nrow(sums)
  if (n_clusters < 2L) stop("Too few learner clusters for bootstrap uncertainty.")
  set.seed(seed)
  draws <- matrix(NA_real_, replicates, ncol(values))
  for (b in seq_len(replicates)) {
    sampled <- sample.int(n_clusters, n_clusters, replace = TRUE)
    draws[b, ] <- colSums(sums[sampled, , drop = FALSE]) / sum(counts[sampled])
  }
  colnames(draws) <- colnames(values)
  draws
}
evaluate_fits <- function(fitted, data, seed = bootstrap_seed) {
  if (anyNA(data$target_score)) stop("Evaluation metrics require observed marks; missing marks are not zero.")
  predictions <- predict_models(fitted, data)
  errors <- sweep(predictions, 1L, data$target_score, "-")
  absolute <- abs(errors)
  reference <- absolute[, "reference"]
  differences <- vapply(setdiff(colnames(absolute), "reference"),
                         function(name) reference - absolute[, name], numeric(nrow(data)))
  colnames(differences) <- setdiff(colnames(absolute), "reference")
  bootstrap <- cluster_bootstrap(differences, data$id_student, seed)
  intervals <- apply(bootstrap, 2L, quantile, probs = c(.025, .975), names = FALSE)
  sst <- sum((data$target_score - mean(data$target_score))^2)
  metrics <- tibble(
    model = colnames(predictions), n_enrollments = nrow(data),
    n_learners = n_distinct(data$id_student), mae = colMeans(absolute),
    rmse = sqrt(colMeans(errors^2)),
    r_squared_secondary = if (sst > 0) 1 - colSums(errors^2) / sst else NA_real_
  )
  comparisons <- tibble(
    model = colnames(differences), reference_model = "reference",
    n_enrollments = nrow(data), n_learners = n_distinct(data$id_student),
    mae_reduction = colMeans(differences), ci_low = intervals[1L, ], ci_high = intervals[2L, ],
    mae_change = -colMeans(differences), bootstrap_replicates = replicates,
    bootstrap_seed = seed, unit = "assessment-mark points; enrollment-weighted",
    uncertainty = "95% percentile learner-cluster bootstrap; fixed trained models"
  )
  ranges <- tibble(
    model = colnames(predictions), n_predictions = nrow(data),
    below_zero = colSums(predictions < 0), above_100 = colSums(predictions > 100),
    out_of_range_fraction = colMeans(predictions < 0 | predictions > 100),
    minimum_prediction = apply(predictions, 2L, min), maximum_prediction = apply(predictions, 2L, max),
    handling = "Raw, unclipped OLS predictions used for primary metrics"
  )
  list(metrics = metrics, comparisons = comparisons, ranges = ranges,
       predictions = predictions, bootstrap = bootstrap)
}

message("Evaluating main models with 2,000 paired learner-cluster bootstrap replicates...")
primary <- evaluate_fits(main_fits, evaluation_observed)
write_csv(primary$metrics, file.path(results_dir, "primary-model-metrics.csv"))
write_csv(primary$comparisons, file.path(results_dir, "primary-comparisons.csv"))
write_csv(primary$ranges, file.path(results_dir, "prediction-range-diagnostics.csv"))
headline <- primary$comparisons %>% filter(model == "volume")
message(sprintf("Primary MAE reduction: %.4f points; 95%% interval %.4f to %.4f.",
                headline$mae_reduction, headline$ci_low, headline$ci_high))

course_comparisons <- lapply(sort(unique(evaluation_observed$code_module)), function(module) {
  data <- evaluation_observed %>% filter(code_module == module)
  result <- evaluate_fits(main_fits, data)
  result$comparisons %>% mutate(code_module = module, n_offerings = n_distinct(data$course_offering),
                               small_group = n_distinct(data$id_student) < 50L,
                               interpretation = "Secondary descriptive comparison; no test of causal heterogeneity")
}) %>% bind_rows()
write_csv(course_comparisons, file.path(results_dir, "course-specific-comparisons.csv"))

robustness <- list()
robustness_ranges <- list()
for (name in names(subset_rules)) {
  dev_subset <- development[subset_rules[[name]](development), ]
  eval_subset <- evaluation[subset_rules[[name]](evaluation), ]
  observed <- eval_subset %>% filter(!is.na(target_score))
  result <- evaluate_fits(sensitivity_fits[[name]], observed)
  robustness[[name]] <- result$comparisons %>%
    left_join(result$metrics %>% select(model, model_mae = mae, model_rmse = rmse), by = "model") %>%
    mutate(sensitivity = name, development_eligible = nrow(dev_subset),
           development_observed = sum(!is.na(dev_subset$target_score)),
           evaluation_eligible = nrow(eval_subset),
           excluded_development_enrollments = nrow(development) - nrow(dev_subset),
           excluded_evaluation_enrollments = nrow(evaluation) - nrow(eval_subset),
           reference_mae = result$metrics$mae[result$metrics$model == "reference"],
           note = if (name == "exact_full_row_unique_volume")
             "Alternative encoding of source rows; not an assertion that repeated rows are erroneous" else
             "Prespecified within-cohort robustness comparison")
  robustness_ranges[[name]] <- result$ranges %>% mutate(sensitivity = name)
}
write_csv(bind_rows(robustness), file.path(results_dir, "within-cohort-robustness.csv"))
write_csv(bind_rows(robustness_ranges), file.path(results_dir, "robustness-prediction-ranges.csv"))

all_eligible <- bind_rows(development, evaluation) %>% mutate(
  outcome_availability = case_when(target_submitted == 0L ~ "No target submission record",
                                   is.na(target_score) ~ "Submission recorded; mark missing",
                                   TRUE ~ "Observed target mark")
)
availability <- all_eligible %>% group_by(partition, outcome_availability) %>% summarise(
  n_enrollments = n(), n_learners = n_distinct(id_student),
  prior_mark_mean = mean(prior_score), prior_mark_median = median(prior_score),
  activity_volume_median = median(total_clicks), active_days_median = median(active_days),
  .groups = "drop"
) %>% mutate(interpretation = "Descriptive selection diagnostic; no correction for nonrandom missing outcomes")
coverage <- all_eligible %>% group_by(partition, code_module, code_presentation) %>% summarise(
  eligible_enrollments = n(), eligible_learners = n_distinct(id_student),
  submitted = sum(target_submitted), observed_marks = sum(target_score_observed),
  missing_marks_after_submission = sum(target_submitted == 1L & is.na(target_score)),
  submission_rate = mean(target_submitted), observed_mark_rate = mean(target_score_observed),
  .groups = "drop"
)
write_csv(availability, file.path(results_dir, "missing-outcome-group-diagnostics.csv"))
write_csv(coverage, file.path(results_dir, "outcome-availability-by-offering.csv"))

# Coefficients are secondary development-set associations, not causal effects.
coefficients <- lapply(names(main_fits), function(name) {
  fit <- main_fits[[name]]
  matrix <- summary(fit)$coefficients
  intervals <- confint(fit)
  keep <- rownames(matrix) %in% c("prior_score", "log1p(total_clicks)", "active_days")
  tibble(model = name, term = rownames(matrix)[keep], estimate = matrix[keep, 1L],
         standard_error = matrix[keep, 2L], ci_low = intervals[keep, 1L], ci_high = intervals[keep, 2L],
         interpretation = "Exploratory development association; conventional model-based interval; not causal")
}) %>% bind_rows()
write_csv(coefficients, file.path(results_dir, "exploratory-development-coefficients.csv"))

palette <- c(reference = "#65758A", volume = "#007F89", consistency = "#7563A6", combined_secondary = "#2477B6")
plot_theme <- theme_minimal(base_size = 12, base_family = "sans") +
  theme(plot.title = element_text(face = "bold", color = "#172B44", size = 17),
        plot.subtitle = element_text(color = "#4B596B", size = 10),
        panel.grid.minor = element_blank(), panel.grid.major.y = element_blank(),
        legend.position = "none", plot.caption = element_text(hjust = 0, color = "#4B596B", size = 9))
save_plot <- function(plot, stem, width = 8.5, height = 5.4) {
  png_device <- if (Sys.info()[["sysname"]] == "Darwin" && capabilities("aqua")) "quartz" else
    if (capabilities("cairo")) "cairo" else getOption("bitmapType")
  grDevices::png(file.path(results_dir, paste0(stem, ".png")), width = width,
                height = height, units = "in", res = 180, type = png_device)
  print(plot)
  grDevices::dev.off()
  path <- file.path(results_dir, paste0(stem, ".png"))
  if (!file.exists(path) || file.info(path)$size < 256) stop("PNG export failed: ", path)
  invisible(NULL)
}

# Native vector companions use the same exported aggregate plotting values.
# Base R's SVG device depends on Cairo, which is unavailable in some macOS R
# installations. These simple chart primitives need neither Cairo nor an extra
# package. PNGs retain the ggplot presentation; SVGs remain editable vectors.
svg_escape <- function(value) {
  value <- gsub("&", "&amp;", as.character(value), fixed = TRUE)
  value <- gsub("<", "&lt;", value, fixed = TRUE)
  value <- gsub(">", "&gt;", value, fixed = TRUE)
  gsub('"', "&quot;", value, fixed = TRUE)
}
svg_text <- function(x, y, label, size = 16, color = "#4B596B", anchor = "start", extra = "") {
  sprintf('<text x="%.2f" y="%.2f" font-size="%s" fill="%s" text-anchor="%s" %s>%s</text>',
          x, y, size, color, anchor, extra, svg_escape(label))
}
svg_line <- function(x1, y1, x2, y2, color = "#E3E8EE", width = 1, extra = "") {
  sprintf('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="%s" stroke-width="%s" %s/>',
          x1, y1, x2, y2, color, width, extra)
}
svg_start <- function(title, subtitle, height) c(
  sprintf('<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="%s" viewBox="0 0 1000 %s" role="img">', height, height),
  paste0("<title>", svg_escape(title), "</title>"),
  '<rect width="100%" height="100%" fill="white"/>',
  '<g font-family="Arial, Helvetica, sans-serif">',
  svg_text(35, 44, title, 27, "#172B44", extra = 'font-weight="700"'),
  svg_text(35, 75, subtitle, 15)
)
svg_finish <- function(elements, stem, caption, height) {
  lines <- strwrap(caption, width = 118)
  for (i in seq_along(lines)) elements <- c(elements, svg_text(35, height - 43 + (i - 1) * 18, lines[[i]], 13))
  elements <- c(elements, "</g>", "</svg>")
  path <- file.path(results_dir, paste0(stem, ".svg"))
  writeLines(elements, path, useBytes = TRUE)
  if (!file.exists(path) || file.info(path)$size < 256) stop("SVG export failed: ", path)
}
horizontal_svg <- function(data, stem, title, subtitle, caption, value = "mae_reduction",
                           bars = FALSE, height = 635) {
  top <- 120; bottom <- height - 135; left <- 300; right <- 940
  values <- data[[value]]
  limits <- if (bars) c(0, max(values) * 1.13) else range(c(0, data$ci_low, data$ci_high))
  if (!bars) {
    padding <- max(diff(limits) * .06, .001)
    limits <- limits + c(-padding, padding)
  }
  project <- function(x) left + (x - limits[[1]]) / diff(limits) * (right - left)
  elements <- svg_start(title, subtitle, height)
  ticks <- pretty(limits, n = 6)
  ticks <- ticks[ticks >= limits[[1]] & ticks <= limits[[2]]]
  for (tick in ticks) {
    elements <- c(elements, svg_line(project(tick), top, project(tick), bottom),
                  svg_text(project(tick), bottom + 26, format(tick, trim = TRUE, digits = 3), 14, anchor = "middle"))
  }
  if (!bars) elements <- c(elements, svg_line(project(0), top, project(0), bottom,
                                             "#8290A3", 1.5, 'stroke-dasharray="6 5"'))
  ys <- top + (seq_len(nrow(data)) - .5) / nrow(data) * (bottom - top)
  for (i in seq_len(nrow(data))) {
    color <- if ("model" %in% names(data)) unname(palette[data$model[[i]]]) else "#007F89"
    elements <- c(elements, svg_text(left - 15, ys[[i]] + 5, as.character(data$label[[i]]), 16, anchor = "end"))
    if (bars) {
      elements <- c(elements, sprintf('<rect x="%.2f" y="%.2f" width="%.2f" height="42" fill="%s"/>',
                                       project(0), ys[[i]] - 21, project(values[[i]]) - project(0), color),
                    svg_text(project(values[[i]]) + 9, ys[[i]] + 5, sprintf("%.2f", values[[i]]), 16, "#172B44"))
    } else {
      elements <- c(elements, svg_line(project(data$ci_low[[i]]), ys[[i]], project(data$ci_high[[i]]), ys[[i]], color, 2),
                    svg_line(project(data$ci_low[[i]]), ys[[i]] - 7, project(data$ci_low[[i]]), ys[[i]] + 7, color, 2),
                    svg_line(project(data$ci_high[[i]]), ys[[i]] - 7, project(data$ci_high[[i]]), ys[[i]] + 7, color, 2),
                    sprintf('<circle cx="%.2f" cy="%.2f" r="5.5" fill="%s"/>', project(values[[i]]), ys[[i]], color))
    }
  }
  x_label <- if (bars) "Mean absolute prediction error (assessment-mark points)" else
    "Mean absolute error reduction (assessment-mark points)"
  elements <- c(elements, svg_text((left + right) / 2, bottom + 61, x_label, 16, anchor = "middle"))
  svg_finish(elements, stem, caption, height)
}
scatter_svg <- function(data, stem, title, subtitle, caption) {
  height <- 635; top <- 120; bottom <- 500; left <- 100; right <- 940
  xs <- data$mean_activity_residual; ys <- data$mean_mark_residual
  x_limits <- range(xs); y_limits <- range(c(0, ys))
  x_limits <- x_limits + c(-1, 1) * diff(x_limits) * .06
  y_limits <- y_limits + c(-1, 1) * diff(y_limits) * .08
  px <- function(x) left + (x - x_limits[[1]]) / diff(x_limits) * (right - left)
  py <- function(y) bottom - (y - y_limits[[1]]) / diff(y_limits) * (bottom - top)
  elements <- svg_start(title, subtitle, height)
  x_ticks <- pretty(x_limits, 6); y_ticks <- pretty(y_limits, 6)
  for (tick in x_ticks[x_ticks >= x_limits[[1]] & x_ticks <= x_limits[[2]]]) {
    elements <- c(elements, svg_line(px(tick), top, px(tick), bottom),
                  svg_text(px(tick), bottom + 25, format(tick, trim = TRUE), 14, anchor = "middle"))
  }
  for (tick in y_ticks[y_ticks >= y_limits[[1]] & y_ticks <= y_limits[[2]]]) {
    elements <- c(elements, svg_line(left, py(tick), right, py(tick)),
                  svg_text(left - 12, py(tick) + 5, format(tick, trim = TRUE), 14, anchor = "end"))
  }
  elements <- c(elements, svg_line(left, py(0), right, py(0), "#8290A3", 1.5, 'stroke-dasharray="6 5"'))
  coordinates <- paste(sprintf("%.2f,%.2f", px(xs), py(ys)), collapse = " ")
  elements <- c(elements, paste0('<polyline points="', coordinates, '" fill="none" stroke="#007F89" stroke-width="2"/>'))
  for (i in seq_along(xs)) elements <- c(elements, sprintf('<circle cx="%.2f" cy="%.2f" r="5" fill="#007F89"/>', px(xs[[i]]), py(ys[[i]])))
  elements <- c(elements,
    svg_text((left + right) / 2, bottom + 60, "Activity relative to prior mark and offering (log-scale residual)", 16, anchor = "middle"),
    svg_text(27, (top + bottom) / 2, "Later mark residual (points)", 16, anchor = "middle",
             extra = sprintf('transform="rotate(-90 27 %.2f)"', (top + bottom) / 2)))
  svg_finish(elements, stem, caption, height)
}
metric_plot_data <- primary$metrics %>% mutate(
  label = factor(unname(model_labels[model]), levels = rev(unname(model_labels[model_names])))
)
write_csv(metric_plot_data, file.path(results_dir, "plot-primary-error-data.csv"))
error_plot <- ggplot(metric_plot_data, aes(x = mae, y = label, fill = model)) +
  geom_col(width = .6) + geom_text(aes(label = sprintf("%.2f", mae)), hjust = -.2, size = 4) +
  scale_fill_manual(values = palette) + scale_x_continuous(expand = expansion(mult = c(0, .15))) +
  labs(title = "Predicting later assessment marks", subtitle = "Reserved evaluation set; observed marks only",
       x = "Mean absolute prediction error (assessment-mark points)", y = NULL,
       caption = "Raw, unclipped predictions. Lower error is better. Models were fixed using development data.") + plot_theme
save_plot(error_plot, "primary-prediction-error")
horizontal_svg(metric_plot_data, "primary-prediction-error", "Predicting later assessment marks",
               "Reserved evaluation set; observed marks only",
               "Raw, unclipped predictions. Lower error is better. Models were fixed using development data.",
               value = "mae", bars = TRUE)

improvement_data <- primary$comparisons %>% mutate(
  label = factor(unname(model_labels[model]), levels = rev(unname(model_labels[setdiff(model_names, "reference")])))
)
write_csv(improvement_data, file.path(results_dir, "plot-primary-improvement-data.csv"))
improvement_plot <- ggplot(improvement_data, aes(x = mae_reduction, y = label, color = model)) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "#8290A3") +
  geom_errorbar(aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = .12, linewidth = .8) +
  geom_point(size = 3.5) + scale_color_manual(values = palette) +
  labs(title = "Information added by activity indicators", subtitle = "Reduction in error relative to prior mark + course offering",
       x = "Mean absolute error reduction (assessment-mark points)", y = NULL,
       caption = "Positive values mean improvement. 95% learner-cluster bootstrap intervals; conditional on fixed trained models.") + plot_theme
save_plot(improvement_plot, "primary-error-improvement")
horizontal_svg(improvement_data, "primary-error-improvement", "Information added by activity indicators",
               "Reduction in error relative to prior mark + course offering",
               "Positive values mean improvement. 95% learner-cluster bootstrap intervals; conditional on fixed trained models.")

course_plot_data <- course_comparisons %>% filter(model == "volume") %>%
  mutate(label = paste0(code_module, "  (", n_enrollments, " enrollments)"))
write_csv(course_plot_data, file.path(results_dir, "plot-course-improvement-data.csv"))
course_plot <- ggplot(course_plot_data, aes(x = mae_reduction, y = reorder(label, mae_reduction))) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "#8290A3") +
  geom_errorbar(aes(xmin = ci_low, xmax = ci_high), orientation = "y", width = .13, color = "#007F89") +
  geom_point(size = 3, color = "#007F89") +
  labs(title = "Activity volume across course contexts", subtitle = "Secondary evaluation comparisons; anonymized module codes",
       x = "Mean absolute error reduction (assessment-mark points)", y = NULL,
       caption = "Smaller groups have less precise estimates. Intervals are descriptive; no causal or subgroup-effect claim.") + plot_theme
save_plot(course_plot, "course-error-improvement", height = 6)
horizontal_svg(arrange(course_plot_data, desc(mae_reduction)), "course-error-improvement",
               "Activity volume across course contexts", "Secondary evaluation comparisons; anonymized module codes",
               "Smaller groups have less precise estimates. Intervals are descriptive; no causal or subgroup-effect claim.", height = 700)

# An explicitly exploratory plot, using development records only. Both axes
# are residualized against prior score and course offering, so the display does
# not mix their mean differences with an unadjusted activity-mark scatterplot.
dev_observed <- development %>% filter(!is.na(target_score))
activity_adjustment <- lm(log1p(total_clicks) ~ prior_score + course_offering,
                          data = as.data.frame(dev_observed[, c("total_clicks", "prior_score", "course_offering")]))
residual_data <- tibble(activity_residual = residuals(activity_adjustment),
                       mark_residual = residuals(main_fits$reference))
breaks <- unique(as.numeric(quantile(residual_data$activity_residual, probs = seq(0, 1, .1))))
residual_data$bin <- cut(residual_data$activity_residual, breaks = breaks, include.lowest = TRUE, labels = FALSE)
activity_plot_data <- residual_data %>% group_by(bin) %>% summarise(
  n_enrollments = n(), mean_activity_residual = mean(activity_residual),
  mean_mark_residual = mean(mark_residual), .groups = "drop"
)
write_csv(activity_plot_data, file.path(results_dir, "plot-exploratory-adjusted-activity-data.csv"))
activity_plot <- ggplot(activity_plot_data, aes(x = mean_activity_residual, y = mean_mark_residual)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "#8290A3") +
  geom_line(color = "#007F89", linewidth = .8) + geom_point(color = "#007F89", size = 3) +
  labs(title = "Activity and later marks in development data",
       subtitle = "Both axes adjusted linearly for prior mark and course offering; ten activity groups",
       x = "Activity relative to prior mark and offering (log-scale residual)",
       y = "Later mark relative to prior mark and offering (points)",
       caption = "Exploratory descriptive association. Activity is not randomized; this plot does not identify an effect of activity or dashboard design.") + plot_theme
save_plot(activity_plot, "exploratory-adjusted-activity")
scatter_svg(activity_plot_data, "exploratory-adjusted-activity", "Activity and later marks in development data",
            "Both axes adjusted for prior mark and course offering; ten activity groups",
            "Exploratory descriptive association. Activity is not randomized; no effect of activity or dashboard design is identified.")

hash_paths <- c(script = script_path, config = config_path,
                development = file.path(derived_dir, "development.csv"),
                evaluation_features = file.path(derived_dir, "evaluation-features.csv"),
                evaluation_outcomes = file.path(derived_dir, "evaluation-outcomes.csv"),
                fixed_models = model_path)
# Public fingerprints identify source roles without exposing machine-specific
# paths. Hashes still use the actual local files supplied to this execution.
hash_labels <- c(script = "scripts/05_analyze.R", config = "config/analysis-config.json",
                 development = "PRIVATE_DERIVED_DIR/development.csv",
                 evaluation_features = "PRIVATE_DERIVED_DIR/evaluation-features.csv",
                 evaluation_outcomes = "PRIVATE_DERIVED_DIR/evaluation-outcomes.csv",
                 fixed_models = "PRIVATE_MODEL_DIR/primary-frozen-models.rds")
stopifnot(identical(names(hash_paths), names(hash_labels)))
hashes <- tibble(source = names(hash_paths), path = unname(hash_labels),
                 hash_algorithm = "MD5", hash = unname(tools::md5sum(hash_paths)))
write_csv(hashes, file.path(results_dir, "run-source-fingerprints.csv"))
writeLines(capture.output(sessionInfo()), file.path(results_dir, "session-info.txt"))
run_record <- tibble(
  field = c("configuration_version", "bootstrap_replicates", "bootstrap_seed", "score_unit",
            "prediction_handling", "development_eligible", "development_observed_marks",
            "evaluation_eligible", "evaluation_observed_marks", "evaluation_observed_learners",
            "learner_overlap", "evaluation_status", "models_fixed_before_evaluation_outcome_access",
            "model_tuning_after_evaluation", "uncertainty_scope", "missing_outcomes",
            "aggregate_outputs_only", "longer_window_and_day70_sensitivities"),
  value = c("0.2", as.character(replicates), as.character(bootstrap_seed),
            "0-100 assessment-mark points; enrollment is the error unit", "Raw, unclipped OLS",
            as.character(nrow(development)), as.character(sum(!is.na(development$target_score))),
            as.character(nrow(evaluation)), as.character(nrow(evaluation_observed)),
            as.character(n_distinct(evaluation_observed$id_student)), "0",
            "Reserved evaluation outcomes now used for the frozen comparison", "TRUE", "NONE",
            "Learner-cluster percentile bootstrap; conditional on fitted development models",
            "Excluded from mark-error evaluation; retained in separate availability diagnostics",
            "TRUE; fitted models saved separately under work/oulad/models",
            "Not executed by this script; separately prepared cohorts required")
)
write_csv(run_record, file.path(results_dir, "run-record.csv"))
writeLines(c(
  "The primary estimate is enrollment-weighted held-out MAE reduction from adding log1p(source-reported total clicks).",
  "Positive MAE reduction means improved prediction, not improved learning or an effect of dashboard design.",
  "All main and within-cohort sensitivity models were fitted and saved before reserved evaluation outcomes were read.",
  "No evaluation-driven model selection, refitting, coefficient adjustment or prediction clipping was performed.",
  "Intervals resample learners and retain all sampled learners' enrollment records; trained models remain fixed.",
  "The intervals are conditional on this development sample and do not include training-sample uncertainty.",
  "MAE, RMSE and R-squared use only observed target marks. R-squared is relative to the evaluation cohort's overall mean.",
  "Missing marks are not assigned zero. Outcome availability is reported separately for the full eligible cohort.",
  "Course comparisons, model coefficients and the adjusted development plot are secondary/exploratory associations.",
  "Exact-row volume is an alternative source-record encoding, not a correction established by provenance evidence.",
  "Longer-window and day70 cohort sensitivities are not included in this script's results.",
  "The configuration's analysis_not_run field records its frozen pre-analysis state; this run record documents that the comparison is now executed.",
  "Run fingerprints use base R MD5 for reproducibility, alongside the project's separately recorded SHA256 acquisition/config locks."
  ,"PNG charts use ggplot2. SVG companions use native editable vector primitives with the same aggregate plotting values; their layout may differ."
), file.path(results_dir, "analysis-notes.txt"))

message("Frozen comparison complete. Aggregate results: ", results_dir)
