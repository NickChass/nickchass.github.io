"""Independent numerical and instrument-contract checks; no participant findings."""
import copy
import importlib.util
import json
import math
from pathlib import Path
import sys

base = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('proposed_analysis', base / 'scripts/09_analyze_proposed_experiment.py')
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)
config = analysis.config_load(base / 'config/proposed-experiment.json')
checks = []
def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

check('built-in synthetic parser and analysis checks pass', analysis.verification(config)['status'] == 'passed')
# Independent reference: NumPy least-squares and direct HC2 sandwich calculation
# for this fixed noisy, balanced design (not a perfect-fit implementation mirror).
scores = [0,1,1,2,2,2,3,4,1,2,2,2,3,4,4,5]
design = [(arm,b) for arm in ('distinct_item','all_correct') for b in range(4) for _ in range(2)]
rows = [dict(arm=arm, baseline_total=b, transfer_total=y, valid=True) for (arm,b),y in zip(design,scores)]
fit = analysis.adjusted_transfer(rows)
check('noisy ANCOVA arm estimate matches independent NumPy reference', math.isclose(fit['arm_difference_points'],1.,abs_tol=1e-12))
check('HC2 standard error matches independent NumPy reference', math.isclose(fit['hc2_standard_error'],.27015456273088295,abs_tol=1e-12))
check('both known-baseline coefficients match reference', math.isclose(fit['baseline_coefficient'],1.,abs_tol=1e-12) and math.isclose(fit['intercept'],.375,abs_tol=1e-12))
check('malformed event list is quarantined without an exception', not analysis.safe_reconstruct({'events':None},config)['valid'])
sample = analysis.generate_synthetic(config,20,20261003)[1]
bad = copy.deepcopy(sample); bad['schema_version'] = 'unknown'
check('unknown schema version is invalid', not analysis.safe_reconstruct(bad,config)['valid'])
bad = copy.deepcopy(sample)
bad['events'] = [e for e in bad['events'] if e['type'] != 'demo_acknowledged']
for i,event in enumerate(bad['events'],1): event['sequence']=i
check('missing development acknowledgment is invalid', not analysis.safe_reconstruct(bad,config)['valid'])
if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 experiment/test_analysis.py /path/to/engine-fixtures.json (first run test_instrument.cjs)')
records = json.loads(Path(sys.argv[1]).read_text())
outcomes = {r['session_label']:analysis.reconstruct(r,config) for r in records}
check('all actual-engine exports reconstruct successfully', len(outcomes)==15 and all(r['valid'] for r in outcomes.values()))
for arm in analysis.ARMS:
    check(arm+' complete no-choice is zero, partial transfer is missing', outcomes[arm+'-none']['primary_repeat']==0 and outcomes[arm+'-none']['transfer_total'] is None)
    check(arm+' technical loss without choice is missing', outcomes[arm+'-no-choice-incomplete']['primary_repeat'] is None)
    check(arm+' observed choice survives later technical loss', outcomes[arm+'-choice-incomplete']['primary_repeat']==0)
    check(arm+' withdrawal omits all measured outcomes', all(outcomes[arm+'-withdrawn'][field] is None for field in ('primary_repeat','baseline_total','transfer_total')))
check('simulated clock cannot establish no-choice', outcomes['development-fast-forward-none']['primary_repeat'] is None and outcomes['development-fast-forward-none']['first_choice_category']=='unavailable')
check('clock shortcut does not erase an observed choice', outcomes['development-fast-forward-repeat']['primary_repeat']==1)
bad = copy.deepcopy(next(r for r in records if r['session_label']=='crypto-0'))
next(e for e in bad['events'] if e['type']=='condition_assigned')['payload']['assignment_draw_raw']=2147483648
check('inconsistent cryptographic allocation provenance is rejected', not analysis.safe_reconstruct(bad,config)['valid'])
print(json.dumps(dict(status='passed',n_checks=len(checks),checks=checks,notice='Technical verification only; no participant findings.'),indent=2))
