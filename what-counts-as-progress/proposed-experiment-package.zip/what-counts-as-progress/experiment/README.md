# Proposed study instrument and analysis

**Development draft 0.1.0 · 3 October 2026. Participant collection is disabled.**

The browser instrument implements the [proposed protocol](../docs/Proposed-Experiment-Protocol.md) and the [original materials](../docs/Study-Materials.md). It is a software walkthrough, not recruitment or a completed participant pilot. Assessment and six individual reflection items are unpiloted and unvalidated.

Open [the live walkthrough](https://nickchass.github.io/what-counts-as-progress/experiment/) or serve the repository with `python3 -m http.server 8765 --bind 127.0.0.1` and visit `http://127.0.0.1:8765/experiment/`. No package installation or build is required. The instrument keeps the current run in memory; it has no response server, analytics, automatic storage, or sign-in. Optional export downloads a development JSON file locally. The public hosting provider's ordinary access processing is separate from instrument event collection.

The initial allocation menu permits forced arms for inspection. The random option uses a browser cryptographic 32-bit draw, assigns all-correct for the lower half and distinct-item for the upper half, and records the raw and normalized draws. Allocation occurs once after correct completion of the common warmup. Unsupported cryptographic allocation fails clearly. Both arms start with one point and the same first menu. The development clock shortcut is explicitly marked; it does not supply observed practice time.

Stop marks the run withdrawn, retaining in-memory history for technical inspection; analytic outcomes are omitted. Reset or refresh clears memory. Previously downloaded files remain on the device until deleted. The current interface does not implement an approved future consent, recruitment, return, retention, or deletion process. The [consent/debrief drafts](../docs/Consent-and-Debrief-Drafts.md) identify what a real reviewed study must resolve.

## Version and event contract

- Protocol and item bank: `0.1.0-draft`; event schema: `1.0.0-draft`.
- `items.js` is generated verbatim from [the configuration](../config/proposed-experiment.json) by `python3 experiment/build_item_bank.py`; revise the configuration and regenerate together.
- [event-schema.json](event-schema.json) describes the export envelope and event structure. The protocol documents exact payloads. The analyzer enforces event order, keys, scoring transitions, eligibility and availability beyond the structural schema.
- Current session kinds are `development_demo` and `synthetic`. Neither is a participant observation. Labels describe provenance, not authentication or protection against arbitrary relabeling.

Events use consecutive sequence numbers and nondecreasing relative milliseconds. Baseline responses precede teaching and the correct P1 warmup; allocation precedes comprehension and practice. Practice uses `practice_menu_choice`, `practice_response`, `explanation_viewed` and `practice_window_completed`. Transfer never earns points. Optional `motivation_response` events keep six custom items separate. Completion, withdrawal, development timing and opt-in export have explicit markers.

The primary outcome uses the first valid menu selection of a previously correct item for repetition. It does not depend on answering the repeat correctly. An observed new or review choice is zero. A confirmed full window without a choice is a distinct `none` category and zero. An incomplete window without a choice, including a development time shortcut, is unavailable. A first observed choice survives later incompletion; withdrawal overrides availability. Incomplete transfer totals remain missing, and event rows never substitute for independent people.

## Reproduce the technical checks

Use Node.js 18+ and Python 3.11+; the analysis and tests use only their standard libraries. Run from the repository root and keep generated manual/development exports outside the public repository:

```sh
node experiment/test_instrument.cjs ../wcap-technical-checks/engine-fixtures.json
python3 experiment/test_analysis.py ../wcap-technical-checks/engine-fixtures.json
python3 scripts/09_analyze_proposed_experiment.py \
  --input ../wcap-technical-checks/engine-fixtures.json \
  --output-dir ../wcap-technical-checks/engine-analysis
```

The engine checks cover both point rules, repeat/retry/review eligibility, duplicate-submit and deadline guards, fixed allocation, withdrawal, incomplete outcomes and the disabled participant mode. The cross-language checks reconstruct exports from that engine and compare a noisy baseline-adjusted model's coefficient and HC2 standard error with an independently calculated NumPy reference. NumPy is not required to run the published reference checks.

## Synthetic analysis demonstration

The [synthetic-example](synthetic-example/) folder contains **240 invented sessions**, not people. It intentionally includes complete no-choice windows, early loss, later incompletion, withdrawn records, incomplete transfer and skipped ratings. The generation assumptions explicitly inject different choice probabilities and small assessment-score differences. Any resulting estimate illustrates those assumptions; it tests no psychological hypothesis.

Reproduce that example in a separate folder:

```sh
python3 scripts/09_analyze_proposed_experiment.py \
  --generate-synthetic --n 240 --seed 20261003 \
  --precision-replicates 2000 \
  --output-dir ../wcap-technical-checks/synthetic-example
```

Outputs contain session outcomes, arm availability, distinct first-choice categories, individual reflection summaries, a technical analysis summary, generation assumptions, source hashes and verification results. The primary comparison uses a Newcombe-Wilson 95% risk-difference interval. Transfer uses baseline-adjusted OLS with HC2 uncertainty and a declared normal approximation. Missingness bounds remain separate from sampling intervals. Unknown versions and corrupt histories are quarantined as missing; participant inputs and duplicate session labels fail closed. The analyzer cannot recover sessions that were never exported or establish unique people.

Precision scenarios assume balanced allocation, independent binary outcomes with probability .5 in both arms, and independent retention of 100%, 90% or 80%. Totals 100/200/400 are planning scenarios, not power calculations or recruitment promises. The provisional 400-person precision candidate in the protocol needs a justified target, actual recruitment route and attrition plan.

## Before participant use

Author and methods review, appropriate research review, permitted piloting, recruitment/data-management arrangements and prospective specification are still required. Remove the forced-arm menu, clock shortcut, answer/state inspector and other development controls from a future reviewed participant interface. Preserve correct no-choice and missingness handling and review timer/background behavior, accessibility, item difficulty and floor/ceiling effects. Technical tests do not validate measures, establish novelty, or demonstrate a learning or motivational effect.

AI assistance supported drafting, implementation and checking. The applicant must independently understand the materials, sources, estimand and analysis decisions before presenting the work in applications.
