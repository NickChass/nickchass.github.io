"""Generate the browser bank verbatim from the proposed-study configuration."""
import json
from pathlib import Path

base = Path(__file__).resolve().parents[1]
config = json.loads((base / 'config/proposed-experiment.json').read_text())
assert config['participant_collection_enabled'] is False

def normalize(items):
    return [dict(id=item['id'], prompt=item['prompt'],
                 options={option['id']: option['text'] for option in item['options']},
                 answer=item['correct_option'], explanation=item['explanation'], objective=item['objective'])
            for item in items]

bank = dict(version=config['item_bank_version'], baseline=normalize(config['pretest_items']),
            practice=normalize(config['practice_items']), transfer=normalize(config['transfer_items']),
            motivation=config['motivation_items'], lesson_sections=config['lesson_sections'],
            warmup_hint=config['warmup_hint'], comprehension=config['comprehension'])
script = ('// Generated verbatim from config/proposed-experiment.json. Do not edit individual items here.\n'
          '(function(root){const bank=' + json.dumps(bank, ensure_ascii=True, separators=(',', ':'))
          + ";if(typeof module==='object'&&module.exports)module.exports=bank;else root.WCAPItems=bank;})(typeof globalThis!=='undefined'?globalThis:this);\n")
(base / 'experiment/items.js').write_text(script)
print('Generated browser bank with', len(bank['motivation']), 'separate reflection items.')
