'use strict';
// Artificial engine traces verify the instrument/analyzer contract, not psychology.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const bank = require('./items.js');
const api = require('./instrument.js');
const records = [];
const checks = [];
function check(name, action) { action(); checks.push({check:name, passed:true}); }
function create(arm, label, kind='synthetic', allocation={}) {
  const session = api.createSession({items:bank, sessionKind:kind, sessionLabel:label, armOverride:arm, ...allocation});
  session.acknowledge();
  session.answerBaseline(Object.fromEntries(bank.baseline.map(item=>[item.id,item.answer])));
  session.finishLesson();
  assert.equal(session.answerWarmup('A').correct,false);
  assert.throws(()=>session.assign());
  session.answerWarmup(bank.practice[0].answer);
  session.assign();
  session.answerRule(1); // Deliberately wrong in distinct_item; no exclusion or reassignment.
  session.startPractice();
  return session;
}
function finish(session, transferCount=6) {
  if (session.snapshot().stage==='practice') session.advance(api.DURATION_MS);
  for(const item of bank.transfer.slice(0,transferCount)) session.answerTransfer(item.id,item.answer);
  session.finishTransfer(); session.answerMotivation({}); session.complete();
  const record=session.exportRecord(); records.push(record); return record;
}
for(const arm of api.ARMS) {
  check(`${arm}: scoring, eligibility, duplicate submission and transfer`,()=>{
    const s=create(arm,`${arm}-scoring`);
    assert.equal(s.snapshot().points,1);
    s.menuChoice('repeat','P1');
    assert.equal(s.answerPractice(bank.practice[0].answer).points_awarded,Number(arm==='all_correct'));
    assert.throws(()=>s.answerPractice(bank.practice[0].answer));
    s.menuChoice('review','P1'); const afterReview=s.snapshot().points;
    s.menuChoice('new'); assert.equal(s.snapshot().active_item_id,'P2');
    assert.equal(s.answerPractice('A').points_awarded,0);
    assert.throws(()=>s.menuChoice('repeat','P2'));
    s.menuChoice('retry','P2'); assert.equal(s.answerPractice(bank.practice[1].answer).points_awarded,1);
    s.menuChoice('repeat','P2'); assert.equal(s.answerPractice(bank.practice[1].answer).points_awarded,Number(arm==='all_correct'));
    assert.equal(s.snapshot().points,afterReview+1+Number(arm==='all_correct'));
    const points=s.snapshot().points; const r=finish(s);
    assert.equal(r.state_snapshot.points,points); assert.equal(r.state_snapshot.transfer_score,6);
    assert.equal(Object.keys(r.state_snapshot.motivation_responses).length,6);
    assert.ok(Object.values(r.state_snapshot.motivation_responses).every(v=>v===null));
  });
  check(`${arm}: complete no-choice and partial assessment`,()=>{
    const s=create(arm,`${arm}-none`); const r=finish(s,3);
    assert.equal(r.state_snapshot.first_choice_category,'none'); assert.equal(r.state_snapshot.transfer_score,null);
  });
  check(`${arm}: first choice remains observed after later technical loss`,()=>{
    const s=create(arm,`${arm}-choice-incomplete`); s.menuChoice('new'); s.advance(2000); records.push(s.exportRecord());
  });
  check(`${arm}: early no-choice stays unobserved`,()=>{
    const s=create(arm,`${arm}-no-choice-incomplete`); s.advance(2000); records.push(s.exportRecord());
  });
  check(`${arm}: withdrawal overrides an observed choice`,()=>{
    const s=create(arm,`${arm}-withdrawn`); s.menuChoice('repeat','P1'); s.withdraw(); records.push(s.exportRecord());
    assert.throws(()=>s.menuChoice('new'));
  });
}
check('development clock shortcut is marked and cannot confirm observed no-choice',()=>{
  const s=create('distinct_item','development-fast-forward-none','development_demo');
  s.advanceDevelopmentWindow(); const r=finish(s); assert.equal(r.state_snapshot.development_time_advance_used,true);
});
check('real first selection survives development clock shortcut',()=>{
  const s=create('all_correct','development-fast-forward-repeat','development_demo');
  s.menuChoice('repeat','P1'); s.advanceDevelopmentWindow(); finish(s);
});
for (const raw of [0,2147483648,4294967295]) check(`recorded cryptographic draw ${raw} selects the matching arm`,()=>{
  const s=create(null,`crypto-${raw}`,'development_demo',{allocationDraw:raw,random:()=>raw/4294967296,assignmentMethod:'cryptographic_random_bit_development'});
  assert.equal(s.snapshot().arm,raw<2147483648?'all_correct':'distinct_item'); finish(s);
});
check('participant mode is disabled',()=>assert.throws(()=>api.createSession({items:bank,sessionKind:'participant'})));
check('answers cannot be submitted at the deadline',()=>{
  const s=create('all_correct','deadline-guard'); s.menuChoice('repeat','P1'); s.advance(api.DURATION_MS); assert.throws(()=>s.answerPractice(bank.practice[0].answer));
});
if(process.argv[2]) {
  const output=path.resolve(process.argv[2]); fs.mkdirSync(path.dirname(output),{recursive:true});
  fs.writeFileSync(output,JSON.stringify(records,null,2)+'\n');
}
console.log(JSON.stringify({status:'passed',checks:checks.length,engine_records:records.length,notice:'Artificial technical traces; no participant findings.'},null,2));
