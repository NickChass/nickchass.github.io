# What Counts as Progress?

**Nicholai Chasseau · Independent research portfolio · October 2026**

[Read the portfolio case study](https://nickchass.github.io/case-studies/what-counts-as-progress.html) · [Try the live dashboard demonstration](https://nickchass.github.io/what-counts-as-progress/) · [Walk through the proposed experiment](https://nickchass.github.io/what-counts-as-progress/experiment/)

A completed first version of an independent research portfolio project examining how recorded learning-platform activity relates to later assessed performance, with a fictional dashboard and scoring demonstration that motivates a future participant experiment.

The primary OULAD cohort contains **20,441 enrollments across 19 course offerings**, including 17,019 observed target marks. In 3,399 reserved evaluation enrollments, adding activity volume to prior mark and course offering reduced mean absolute prediction error from **11.621 to 11.302 assessment-mark points**: a reduction of **0.319 points**, with a 95% learner-cluster bootstrap interval of **0.207–0.426**. This is modest additional predictive information for the specified assessment criterion. It does not demonstrate learning gains, metric-seeking behavior, or dashboard efficacy.

![Prediction error reduction after adding learning activity indicators](results/primary-error-improvement.png)

Click volume is the primary comparison; active days and the combined model are secondary. Intervals resample learners and are conditional on the fitted models.

The locally dated version-0.2 plan preceded activity–mark analysis. It is not an external preregistration. The frozen configuration retains its historical `analysis_not_run` flag; [Execution Status](docs/Execution-Status.md) and the result run records describe completed execution.

## Output index

| Output | What it contains |
|---|---|
| [Research Report PDF](docs/Research-Report.pdf) and [editable report](docs/Research-Report.md) | Research question, related work, methods, first-version findings, and limits |
| [Dashboard prototype](prototype/index.html) | Working scoring-rule prototype for a future participant experiment; efficacy has not been tested |
| [Execution Status](docs/Execution-Status.md) | Completed work, verification, remaining review, and an accurate CV line |
| [Initial Analysis Plan](docs/Initial-Analysis-Plan.md) and [Plan Amendments](docs/Plan-Amendments.md) | Dated decisions and their relationship to the frozen configuration |
| [Primary model metrics](results/primary-model-metrics.csv) and [primary comparisons](results/primary-comparisons.csv) | Held-out MAE, secondary RMSE/R-squared, and paired error-reduction intervals |
| [Primary chart](results/primary-error-improvement.png) and [vector companion](results/primary-error-improvement.svg) | Aggregate primary and secondary comparisons against the reference model |
| [Within-cohort robustness](results/within-cohort-robustness.csv) and [timing sensitivities](results/timing-model-comparison.csv) | Six planned sensitivity comparisons; altered timing can change the population and assessments |
| [Outcome availability](results/outcome-availability-by-offering.csv) | Submission and score availability for the full eligible cohort; missing scores are not converted to zero |
| [Independent verification](results/independent-verification.json) | Independent reconstruction of 32 reported model MAEs; this check does not reproduce bootstrap intervals |
| [Additional latest-offering check](results/latest-offering-run-record.csv) | Secondary execution record; exact implementation was fixed after primary-result inspection |
| [Data Guide](docs/Data-Guide.md), `audit/`, and [run record](results/run-record.csv) | Field definitions, provenance, integrity/availability checks, and execution evidence |

## Psychological argument and proposed experiment

The extension asks whether credit for exact correct repetitions changes the first practice choice, compared with credit only for distinct correctly answered items. It distinguishes choices, stated goals, enjoyment and perceived competence, and performance on unfamiliar application items. A policy effect would not by itself identify a psychological mechanism.

- [Psychological argument](docs/Psychological-Argument.md) and [primary-source literature map](docs/Literature-Map.md).
- [Proposed protocol](docs/Proposed-Experiment-Protocol.md), [original study materials](docs/Study-Materials.md), and [consent/debrief drafts](docs/Consent-and-Debrief-Drafts.md).
- [Experimental package guide](docs/Experiment-Package-Guide.md), [development instrument](experiment/index.html), and [analysis script](scripts/09_analyze_proposed_experiment.py).

This is a complete development draft for review and piloting. Participant collection is disabled. The event and analysis examples are development or explicitly synthetic records, not participant findings. The custom measures are unvalidated, and the proposed experiment has not been externally preregistered.

## Provenance and data handling

Source: [Open University Learning Analytics Dataset, official UCI repository](https://archive.ics.uci.edu/dataset/349/open+university+learning+analytics+dataset), licensed [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

Kuzilek, J., Hlosta, M., & Zdrahal, Z. (2015). *Open University Learning Analytics dataset*. UCI Machine Learning Repository. https://doi.org/10.24432/C5KK69

Kuzilek, J., Hlosta, M., & Zdrahal, Z. (2017). *Open University Learning Analytics dataset*. Scientific Data, 4, 170171. https://doi.org/10.1038/sdata.2017.171

Raw archive and table bytes remain unchanged. `audit/data-provenance.json` records acquisition URLs, byte sizes, and SHA-256 checksums; archive integrity was also checked. The public project contains code, documentation, aggregate audit/results files, and the prototype. **Raw learner records, derived enrollment records, evaluation outcomes, and fitted model objects are excluded from this project package.** Keep them in a separate local data directory. Model objects remain under that directory's `models/` folder, not in public outputs.

Repeated source activity rows are retained in the primary click count. An exact-full-row uniqueness sensitivity is an alternative encoding, not a claim that the source rows are erroneous. No attempt is made to identify learners.

## Reproduce the project

Run from this project directory. The acquisition/preparation code requires Python 3.11 or later. The R code requires `readr`, `dplyr`, and `ggplot2`; tested runtime versions are recorded in `results/session-info.txt`. The optional independent metric reconstruction additionally requires NumPy and pandas. Scripts do not install packages.

Use a local data directory outside the public project. The example keeps learner records in a sibling directory outside this repository.

```sh
PROGRESS_DATA_DIR="../what-counts-as-progress-data"

python3 scripts/01_download.py --data-dir "$PROGRESS_DATA_DIR" --manifest audit/data-provenance.json
Rscript scripts/02_audit.R "$PROGRESS_DATA_DIR/raw" audit
python3 scripts/03_prepare_cohort.py --raw-dir "$PROGRESS_DATA_DIR/raw" --config config/analysis-config.json --derived-dir "$PROGRESS_DATA_DIR/derived" --audit-dir audit
python3 scripts/04_verify_preparation.py --project-dir . --data-dir "$PROGRESS_DATA_DIR"
Rscript scripts/05_analyze.R "$PROGRESS_DATA_DIR/derived" results

python3 scripts/03_prepare_cohort.py --raw-dir "$PROGRESS_DATA_DIR/raw" --config config/window28-sensitivity.json --derived-dir "$PROGRESS_DATA_DIR/sensitivity-window28" --audit-dir audit/sensitivity-window28
python3 scripts/03_prepare_cohort.py --raw-dir "$PROGRESS_DATA_DIR/raw" --config config/cutoff70-sensitivity.json --derived-dir "$PROGRESS_DATA_DIR/sensitivity-cutoff70" --audit-dir audit/sensitivity-cutoff70
Rscript scripts/06_timing_sensitivities.R "$PROGRESS_DATA_DIR" results "$PROGRESS_DATA_DIR/models"
```

The timing configurations are prepared separately. `window28-sensitivity.json` observes days 28–55 at the day-56 cutoff, preserves the primary prior/target selection, and requires that selected prior to have been submitted before day 28. `cutoff70-sensitivity.json` observes days 56–69 and reapplies the assessment-selection rules at day 70. Both can change eligibility; day 70 can also change the selected assessments. Their numeric settings and sensitivity notes define these overrides.

The additional latest-offering check can be reproduced separately:

```sh
Rscript scripts/08_latest_offering_check.R "$PROGRESS_DATA_DIR/derived" results "$PROGRESS_DATA_DIR/models"
```

After those results exist, independently reconstruct all 32 MAEs using an environment containing NumPy and pandas:

```sh
python3 scripts/07_verify_model_metrics.py --data-dir "$PROGRESS_DATA_DIR" --project-dir .
```

Script 08 uses earlier development offerings and reserved learners in the latest represented offering, with transferable module effects. The broad check was anticipated, but its exact implementation was fixed after inspecting the primary results. It is additional secondary analysis and does not replace the frozen primary comparison or provide a fresh evaluation cohort.

Scripts 05 and 06 fit and save their planned models before opening the corresponding evaluation outcomes. The evaluation outcomes have now been used for these fixed comparisons. **Rerunning these commands re-evaluates the same reserved set; it is not new validation.** Do not use its results to select new models or preferred cutoffs while continuing to describe it as untouched.

Model predictors are explicitly selected. Later submission and withdrawal fields in development records support missingness reporting or planned subset rules; they do not enter prediction models automatically. Error intervals resample learners and retain their enrollment records, conditional on the fitted development models.

PNG export uses Quartz on macOS when available, or the available Cairo/configured bitmap device elsewhere. SVG companions use editable vector primitives drawn from the same aggregate plotting values and do not require Cairo. A working native bitmap device is required for PNGs; no graphics dependencies are installed automatically.

## Scientific status

The first-version analysis and six planned sensitivity comparisons are complete. Independent least-squares reconstruction matched 32 reported MAEs within the stated tolerance. The latest-offering secondary check has produced results and retains its separate post-primary implementation label. Author and methods review remain necessary before using the work in applications. A participant experiment is a future study requiring participant access, piloting, and appropriate review; the current prototype has no efficacy evidence.

The nine-page [research PDF](docs/Research-Report.pdf) presents the findings, charts, methods, limitations and source links. The Markdown report remains the full editable research document.

## Inspect the demonstration

Download or clone the repository and open `prototype/index.html` in a browser. It is self-contained and collects no data. The [walkthrough](prototype/README.md) explains the synchronized fictional records and scoring rules. This repository does not deploy a live prediction system.

## Research scope and attribution

The [future study brief](docs/Future-Study-Brief.md) is a proposal, not an executed experiment. The dataset has no dashboard exposure or independent transfer assessment. AI assistance supported literature research, drafting, implementation and checks; the report documents that assistance. The analysis is an independent portfolio report and has not been peer-reviewed.

Data attribution and CC BY 4.0 apply to the OULAD source release. No additional license grant is asserted for the applicant's original project materials.
